import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { installAuthFetch } from './lib/auth';
import { initTheme } from './lib/theme';
import './index.css';

initTheme();            // restore the chosen colour theme (Halloween by default)
installAuthFetch();   // sends the login token with every /api request

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
