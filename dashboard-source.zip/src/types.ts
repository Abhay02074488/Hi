export interface TranscriptFile {
  filename: string;
  size: number;
  createdAt: string;
  modifiedAt: string;
}

export interface ParsedTranscriptMessage {
  id?: string;
  timestamp: string;
  author: string;
  avatar?: string;
  isBot?: boolean;
  roleColor?: string;
  badge?: string;
  content: string;
  embeds?: Array<{
    title?: string;
    description?: string;
    color?: string;
    fields?: Array<{ name: string; value: string; inline?: boolean }>;
    footer?: string;
  }>;
  attachments?: Array<{
    filename: string;
    url: string;
    size?: string;
  }>;
}

export interface ParsedTranscript {
  channelName: string;
  guildName: string;
  openerUser: string;
  claimedBy?: string;
  category: string;
  exportedAt: string;
  serverIp?: string;
  messages: ParsedTranscriptMessage[];
}

export interface TicketPanelData {
  guild_id: number | string;
  channel_id: number | string;
  message_id: number | string;
  title: string;
  created_at: string;
}

export interface OpenTicketData {
  user_id: number | string;
  guild_id: number | string;
  claimed_by: number | string | null;
  category: string;
  created_at?: string;
}

export interface TicketSystemState {
  ticket_db: Record<string, any>;
  open_tickets: Record<string, any>;
  panels_log: TicketPanelData[];
}

export interface AuthUser {
  email: string;
  role: 'admin' | 'user';
  isAdmin: boolean;
  verifiedAt: string;
}

export interface SystemMetrics {
  timestamp: string;
  memory: {
    rssMB: number;
    heapUsedMB: number;
    heapTotalMB: number;
    usedSystemMB: number;
    totalSystemMB: number;
    freeSystemMB: number;
    percentage: number;
    status: 'HEALTHY' | 'WARNING' | 'CRITICAL';
  };
  cpu: {
    model: string;
    cores: number;
    loadAverage: number[];
    estimatedUsage: number;
  };
  system: {
    osType: string;
    platform: string;
    arch: string;
    nodeVersion: string;
    uptime: string;
    uptimeSeconds: number;
    hostname: string;
  };
  bot: {
    status: string;
    gatewayLatency: number;
    activeShards: number;
    guildsCount: number;
    channelsCount: number;
    cogsLoaded: number;
    memoryFootprint: string;
  };
}

export interface MinecraftRealtimeStatus {
  domain: string;
  java_ip: string;
  java_port: number;
  bedrock_ip: string;
  bedrock_port: number;
  online: boolean;
  players: {
    online: number;
    max: number;
    list?: Array<{ name: string; uuid?: string }>;
  };
  motd: string;
  version: string;
  ping: number;
  icon?: string | null;
  gamemodes: Array<{ name: string; badge: string; color: string; desc: string }>;
  discord_url: string;
  store_url: string;
}

export interface CommunityStats {
  minecraft: {
    java_ip: string;
    java_port: number;
    bedrock_ip: string;
    bedrock_port: number;
    online: boolean;
    online_players: number;
    max_players: number;
    latency_ms: number;
    version: string;
    motd: string;
    gamemodes: Array<{ name: string; badge: string; color: string; desc: string }>;
  };
  discord: {
    server_name: string;
    server_link: string;
    total_members: number;
    online_members: number;
    bot_name: string;
    bot_status: string;
    activity: string;
    verified_members: number;
    channels_count: number;
  };
  links: {
    store: string;
    vote: string;
    discord: string;
  };
}

export interface LevelUser {
  id: string;
  username: string;
  discriminator: string;
  avatar: string;
  xp: number;
  level: number;
  messages: number;
  vc_minutes: number;
  role: string;
  badge: string;
  last_active: string;
}

export interface GameStats {
  tictactoe: { played: number; wins: number; losses: number; draws: number };
  chess: { played: number; wins: number; losses: number; draws: number };
  blackjack: { played: number; wins: number; losses: number; pushes: number; chips_won: number };
}

export interface StaffApplicationQuestionAnswer {
  question: string;
  answer: string;
}

export interface StaffApplicationSubmission {
  id: string;
  user_id: string;
  user_name: string;
  guild_id: string;
  status: 'pending' | 'accepted' | 'denied';
  submitted_at: string;
  answers: StaffApplicationQuestionAnswer[];
  reviewed_by: string | null;
  reviewed_at: string | null;
  review_reason: string | null;
  ticket_channel_id: string | null;
}

export interface StaffApplicationConfig {
  enabled: boolean;
  review_channel_id: string | null;
  staff_role_id: string | null;
  max_questions: number;
  title: string;
  description: string;
  questions: string[];
  cooldown_days: number;
  // Panel message customization (shared with the Discord bot)
  panel_message?: string;
  panel_image?: string;
  panel_thumbnail?: string;
  panel_footer?: string;
  panel_color?: string;
  button_label?: string;
  show_overview?: boolean;
}
