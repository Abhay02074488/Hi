import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { getToken, postJson, setToken } from '../lib/auth';

export type Role = 'owner' | 'admin' | 'staff' | 'user';
export interface Account {
  id: string; email: string; name: string; role: Role;
  isAdmin: boolean; isStaff: boolean; isOwner: boolean;
}
const RANK: Record<Role, number> = { user: 1, staff: 2, admin: 3, owner: 4 };

interface AuthCtx {
  user: Account | null;
  loading: boolean;
  setupRequired: boolean;
  hasRole: (min: Role) => boolean;
  login: (email: string, password: string) => Promise<string | null>;
  register: (email: string, name: string, password: string) => Promise<string | null>;
  setup: (key: string, email: string, name: string, password: string) => Promise<string | null>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
  applyToken: (token: string, user: Account) => void;
}

const Ctx = createContext<AuthCtx | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<Account | null>(null);
  const [loading, setLoading] = useState(true);
  const [setupRequired, setSetupRequired] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const cfg = await fetch('/api/auth/config').then((r) => r.json()).catch(() => null);
      if (cfg) setSetupRequired(!!cfg.setupRequired);
      if (getToken()) {
        const s = await fetch('/api/auth/session').then((r) => r.json()).catch(() => null);
        if (s?.authenticated) setUser(s.user);
        else { setToken(null); setUser(null); }
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    const expired = () => { setToken(null); setUser(null); };
    window.addEventListener('wm-auth-expired', expired);
    return () => window.removeEventListener('wm-auth-expired', expired);
  }, [refresh]);

  const applyToken = (token: string, u: Account) => { setToken(token); setUser(u); setSetupRequired(false); };

  const run = async (url: string, body: unknown): Promise<string | null> => {
    const { ok, data } = await postJson(url, body);
    if (!ok || !data?.token) return data?.error || 'Something went wrong. Try again.';
    applyToken(data.token, data.user);
    return null;
  };

  const value: AuthCtx = {
    user, loading, setupRequired, applyToken, refresh,
    hasRole: (min) => !!user && RANK[user.role] >= RANK[min],
    login: (email, password) => run('/api/auth/login', { email, password }),
    register: (email, name, password) => run('/api/auth/register', { email, name, password }),
    setup: (key, email, name, password) => run('/api/auth/setup', { key, email, name, password }),
    logout: async () => { await postJson('/api/auth/logout', {}); setToken(null); setUser(null); },
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useAuth = (): AuthCtx => {
  const c = useContext(Ctx);
  if (!c) throw new Error('useAuth must be used inside <AuthProvider>');
  return c;
};
