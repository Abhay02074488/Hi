import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../data/storeData';

export interface CartItem {
  product: Product;
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  playerIgn: string;
  setPlayerIgn: (ign: string) => void;
  discordTag: string;
  setDiscordTag: (tag: string) => void;
  addItem: (product: Product, quantity?: number) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  couponCode: string;
  appliedCoupon: { code: string; discountPercent: number } | null;
  applyCoupon: (code: string) => Promise<{ success: boolean; message: string }>;
  removeCoupon: () => void;
  subtotal: number;
  discountAmount: number;
  finalTotal: number;
  totalItemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('wondermc_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [playerIgn, setPlayerIgn] = useState<string>(() => {
    return localStorage.getItem('wondermc_player_ign') || '';
  });

  const [discordTag, setDiscordTag] = useState<string>(() => {
    return localStorage.getItem('wondermc_discord_tag') || '';
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discountPercent: number } | null>(null);

  useEffect(() => {
    localStorage.setItem('wondermc_cart', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem('wondermc_player_ign', playerIgn);
  }, [playerIgn]);

  useEffect(() => {
    localStorage.setItem('wondermc_discord_tag', discordTag);
  }, [discordTag]);

  const addItem = (product: Product, quantity = 1) => {
    setItems(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    setIsCartOpen(true);
  };

  const removeItem = (productId: string) => {
    setItems(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(productId);
      return;
    }
    setItems(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setItems([]);
    setAppliedCoupon(null);
    setCouponCode('');
  };

  const applyCoupon = async (code: string): Promise<{ success: boolean; message: string }> => {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) {
      return { success: false, message: 'Please enter a coupon code.' };
    }

    try {
      const res = await fetch('/api/store/coupon/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: cleanCode, subtotal })
      });
      const data = await res.json();
      if (data.success) {
        setAppliedCoupon({ code: cleanCode, discountPercent: data.discountPercent });
        setCouponCode(cleanCode);
        return { success: true, message: `✅ Coupon ${cleanCode} applied (${data.discountPercent}% OFF)!` };
      } else {
        return { success: false, message: data.message || 'Invalid coupon code.' };
      }
    } catch {
      // Fallback offline coupon check
      if (cleanCode === 'WONDER20' || cleanCode === 'SUMMER20') {
        setAppliedCoupon({ code: cleanCode, discountPercent: 20 });
        setCouponCode(cleanCode);
        return { success: true, message: `✅ Coupon ${cleanCode} applied (20% OFF)!` };
      } else if (cleanCode === 'BOXPVP10') {
        setAppliedCoupon({ code: cleanCode, discountPercent: 10 });
        setCouponCode(cleanCode);
        return { success: true, message: `✅ Coupon ${cleanCode} applied (10% OFF)!` };
      }
      return { success: false, message: 'Coupon expired or not found.' };
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
  };

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountPercent = appliedCoupon ? appliedCoupon.discountPercent : 0;
  const discountAmount = Math.round((subtotal * discountPercent) / 100);
  const finalTotal = Math.max(0, subtotal - discountAmount);
  const totalItemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        playerIgn,
        setPlayerIgn,
        discordTag,
        setDiscordTag,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        couponCode,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        subtotal,
        discountAmount,
        finalTotal,
        totalItemCount
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    return {
      items: [],
      addToCart: () => {},
      removeFromCart: () => {},
      updateQuantity: () => {},
      clearCart: () => {},
      couponCode: '',
      setCouponCode: () => {},
      appliedCoupon: null,
      applyCoupon: async () => ({ success: false, message: 'Cart not initialized' }),
      removeCoupon: () => {},
      subtotal: 0,
      discountPercent: 0,
      discountAmount: 0,
      finalTotal: 0,
      totalItemCount: 0
    };
  }
  return context;
};
