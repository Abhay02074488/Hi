import React, { createContext, useContext, useState, useEffect } from 'react';

export interface StoreConfig {
  serverName: string;
  javaIp: string;
  javaPort: number;
  bedrockIp: string;
  bedrockPort: number;
  discordUrl: string;
  storeUrl: string;
  upiId: string;
  upiName: string;
  currencySymbol: string;
  currencyCode: string;
  saleActive: boolean;
  salePercent: number;
  saleTitle: string;
}

const DEFAULT_STORE_CONFIG: StoreConfig = {
  serverName: 'WonderMc Network',
  javaIp: 'play.wondermc.fun',
  javaPort: 25565,
  bedrockIp: 'play.wondermc.fun',
  bedrockPort: 19132,
  discordUrl: 'https://dc.gg/wondermc',
  storeUrl: 'https://play.wondermc.fun/store',
  upiId: '9876543210@paytm',
  upiName: 'WonderMc Gaming Network',
  currencySymbol: '₹',
  currencyCode: 'INR',
  saleActive: true,
  salePercent: 20,
  saleTitle: 'SUMMER SEASON SALE • FLAT 20% OFF'
};

interface StoreConfigContextType {
  config: StoreConfig;
  updateConfig: (newConfig: Partial<StoreConfig>) => Promise<void>;
  isLoading: boolean;
}

const StoreConfigContext = createContext<StoreConfigContextType | undefined>(undefined);

export const StoreConfigProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [config, setConfig] = useState<StoreConfig>(() => {
    try {
      const cached = localStorage.getItem('wondermc_store_config');
      return cached ? { ...DEFAULT_STORE_CONFIG, ...JSON.parse(cached) } : DEFAULT_STORE_CONFIG;
    } catch {
      return DEFAULT_STORE_CONFIG;
    }
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/store/config');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.config) {
          const merged = { ...DEFAULT_STORE_CONFIG, ...data.config };
          setConfig(merged);
          localStorage.setItem('wondermc_store_config', JSON.stringify(merged));
        }
      }
    } catch (e) {
      console.log('Using default store config:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const updateConfig = async (newConfig: Partial<StoreConfig>) => {
    const updated = { ...config, ...newConfig };
    setConfig(updated);
    localStorage.setItem('wondermc_store_config', JSON.stringify(updated));

    try {
      await fetch('/api/store/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated)
      });
    } catch (e) {
      console.error('Failed to sync store config with server:', e);
    }
  };

  return (
    <StoreConfigContext.Provider value={{ config, updateConfig, isLoading }}>
      {children}
    </StoreConfigContext.Provider>
  );
};

export const useStoreConfig = () => {
  const context = useContext(StoreConfigContext);
  if (!context) {
    return {
      config: DEFAULT_STORE_CONFIG,
      updateConfig: async () => {},
      isLoading: false
    };
  }
  return context;
};
