// Small helper for the dashboard pages: one call, one result shape, never throws.
export async function api(method: 'GET' | 'POST' | 'DELETE', url: string, body?: unknown): Promise<{ ok: boolean; data: any }> {
  try {
    const res = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : undefined, body: body ? JSON.stringify(body) : undefined });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok && data?.success !== false, data };
  } catch {
    return { ok: false, data: { success: false, error: 'Could not reach the server. Check your connection.' } };
  }
}
export const errText = (d: any, fallback = 'Something went wrong.') => (d && (d.error || d.message)) || fallback;
