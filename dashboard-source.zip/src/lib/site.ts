// Single place for the public facts about the server. Change here, everywhere updates.
export const SITE = {
  name: 'WonderMc',
  tagline: 'Step in. Gear up. Dominate.',
  ip: 'play.wondermc.fun',
  javaPort: 25565,
  bedrockPort: 19132,
  discord: 'https://dc.gg/wondermc',
};
