// Login token storage + a fetch wrapper that automatically sends it to /api/* (so no component has to care).
const KEY = 'wondermc_token';

export const getToken = (): string | null => {
  try { return localStorage.getItem(KEY); } catch { return null; }
};
export const setToken = (token: string | null) => {
  try { token ? localStorage.setItem(KEY, token) : localStorage.removeItem(KEY); } catch { /* private mode */ }
};

export function installAuthFetch() {
  const w = window as any;
  if (w.__wmFetchInstalled) return;
  w.__wmFetchInstalled = true;
  const original = window.fetch.bind(window);
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    const isApi = url.startsWith('/api/') || url.startsWith(window.location.origin + '/api/');
    if (isApi) {
      const token = getToken();
      if (token) {
        const headers = new Headers(init?.headers || (input instanceof Request ? input.headers : undefined));
        if (!headers.has('Authorization')) headers.set('Authorization', `Bearer ${token}`);
        init = { ...init, headers };
      }
    }
    const res = await original(input, init);
    if (isApi && res.status === 401 && !/\/api\/auth\/(login|register|setup|session|config)/.test(url)) {
      window.dispatchEvent(new Event('wm-auth-expired'));
    }
    return res;
  };
}

export async function postJson(url: string, body: unknown): Promise<{ ok: boolean; data: any }> {
  try {
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok && data?.success !== false, data };
  } catch {
    return { ok: false, data: { error: 'Could not reach the server. Check your connection.' } };
  }
}
