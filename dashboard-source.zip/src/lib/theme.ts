import { useEffect, useState } from 'react';

export const THEMES = [
  { id: 'halloween', label: 'Halloween 🎃', swatch: '#f97316' },
  { id: 'emerald', label: 'Emerald', swatch: '#10b981' },
  { id: 'ocean', label: 'Ocean', swatch: '#0ea5e9' },
  { id: 'violet', label: 'Violet', swatch: '#8b5cf6' },
  { id: 'ruby', label: 'Ruby', swatch: '#f43f5e' },
] as const;
export type ThemeId = (typeof THEMES)[number]['id'];
const KEY = 'wondermc_theme';

export function applyTheme(id: string) {
  const ok = THEMES.some((t) => t.id === id) ? id : 'halloween';
  if (ok === 'halloween') document.documentElement.removeAttribute('data-theme');
  else document.documentElement.setAttribute('data-theme', ok);
  try { localStorage.setItem(KEY, ok); } catch { /* private mode */ }
}
export function initTheme() {
  let saved = 'halloween';
  try { saved = localStorage.getItem(KEY) || 'halloween'; } catch { /* ignore */ }
  applyTheme(saved);
}
export function useTheme(): [string, (id: string) => void] {
  const [theme, setTheme] = useState<string>('halloween');
  useEffect(() => {
    try { setTheme(localStorage.getItem(KEY) || 'halloween'); } catch { /* ignore */ }
  }, []);
  return [theme, (id: string) => { applyTheme(id); setTheme(id); }];
}
