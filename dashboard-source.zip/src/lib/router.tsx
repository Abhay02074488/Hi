import React, { useEffect, useState } from 'react';

// Tiny hash router: "#/store", "#/admin/access" ... works on any host without server rewrites.
const current = () => (window.location.hash.replace(/^#/, '') || '/').split('?')[0];

export function useRoute(): string {
  const [route, setRoute] = useState(current());
  useEffect(() => {
    const on = () => { setRoute(current()); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return route;
}

export const navigate = (path: string) => { window.location.hash = path; };

export const Link: React.FC<{ to: string; className?: string; onClick?: () => void; children: React.ReactNode }> = ({ to, className, onClick, children }) => (
  <a href={`#${to}`} className={className} onClick={onClick}>{children}</a>
);
