import { useEffect, useState } from 'react';

export interface McStatus {
  loading: boolean;
  online: boolean;
  players: { online: number; max: number; sample: string[] };
  motdLines: string[];
  version: string | null;
  ping: number | null;
  icon: string | null;
  checkedAt: string | null;
  source: string;
  error?: string;
  gamemodes: Array<{ name: string; badge: string; color: string; desc: string }>;
  failed: boolean;      // the website itself could not reach /api (not the same as "server offline")
}

const EMPTY: McStatus = {
  loading: true, online: false, players: { online: 0, max: 0, sample: [] }, motdLines: [], version: null, ping: null,
  icon: null, checkedAt: null, source: 'none', gamemodes: [], failed: false,
};

/** Live server status. Only real data: if the lookup fails the page shows "offline"/"unavailable", never made-up numbers. */
export function useMcStatus(everyMs = 15000): McStatus {
  const [state, setState] = useState<McStatus>(EMPTY);
  useEffect(() => {
    let stop = false;
    const load = async () => {
      try {
        const res = await fetch('/api/minecraft/realtime');
        const d = await res.json();
        if (stop) return;
        setState({
          loading: false, online: !!d.online, players: { online: d.players?.online ?? 0, max: d.players?.max ?? 0, sample: d.players?.sample ?? [] },
          motdLines: [d.motd_line1, d.motd_line2].filter(Boolean), version: d.version ?? null, ping: typeof d.ping === 'number' ? d.ping : null,
          icon: d.icon ?? null, checkedAt: d.checked_at ?? null, source: d.status_source ?? 'none', error: d.status_error,
          gamemodes: Array.isArray(d.gamemodes) ? d.gamemodes : [], failed: false,
        });
      } catch {
        if (!stop) setState((s) => ({ ...s, loading: false, failed: true }));
      }
    };
    load();
    const t = setInterval(load, everyMs);
    return () => { stop = true; clearInterval(t); };
  }, [everyMs]);
  return state;
}
