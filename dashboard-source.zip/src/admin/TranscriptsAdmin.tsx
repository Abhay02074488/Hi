import React, { useCallback, useEffect, useState } from 'react';
import { TranscriptManager } from '../components/TranscriptManager';

export const TranscriptsAdmin: React.FC = () => {
  const [files, setFiles] = useState<any[]>([]);
  const load = useCallback(async () => {
    try {
      const d = await fetch('/api/transcripts').then((r) => r.json());
      if (d?.transcripts) setFiles(d.transcripts);
    } catch { /* keep the old list */ }
  }, []);
  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-4">
      <div><h1 className="text-2xl font-black text-white">Ticket transcripts</h1><p className="text-sm text-slate-400">Saved copies of closed tickets.</p></div>
      <TranscriptManager
        files={files}
        onRefresh={load}
        onSendDm={async () => { window.alert('Transcripts are sent to players by the Discord bot when a ticket closes. Sending from the website is not connected.'); }}
        onCreateCustomTranscript={async (data) => {
          await fetch('/api/transcripts/create', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
          await load();
        }}
      />
    </div>
  );
};
