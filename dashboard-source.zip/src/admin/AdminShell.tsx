import React from 'react';
import { Coins, FileText, Gift, Key, Layers, Megaphone, MessageSquare, Settings, Shield, ShoppingBag, Sparkles, Tag, Zap, Info, AlertTriangle, Trophy } from 'lucide-react';
import { Link } from '../lib/router';
import { Role, useAuth } from '../context/AuthContext';
import { btnPrimary, card } from '../site/ui';
import { Overview } from './Overview';
import { AccessManager } from './AccessManager';
import { StoreAdmin } from './StoreAdmin';
import { TranscriptsAdmin } from './TranscriptsAdmin';
import { SecurityLimits } from './SecurityLimits';
import { VouchersAdmin } from './VouchersAdmin';
import { EconomyAdmin } from './EconomyAdmin';
import { MessageBuilder } from './MessageBuilder';
import { AiSettings } from './AiSettings';
import { SiteContentAdmin } from './SiteContentAdmin';
import { StaffApplicationsManager } from '../components/StaffApplicationsManager';
import { ReactionRoleManager } from '../components/ReactionRoleManager';
import { MinecraftBridgeManager } from '../components/MinecraftBridgeManager';
import { BotProcessManager } from '../components/BotProcessManager';
import { RamUsageMonitor } from '../components/RamUsageMonitor';
import { MinecraftComplaintsManager } from '../components/MinecraftComplaintsManager';
import { LevelingSystem } from '../components/LevelingSystem';

const GROUPS: Array<{ title: string; items: Array<{ id: string; label: string; min: Role; icon: React.ComponentType<{ className?: string }> }> }> = [
  { title: 'Overview', items: [{ id: 'overview', label: 'Dashboard', min: 'staff', icon: Layers }] },
  { title: 'Moderation', items: [
    { id: 'complaints', label: 'MC Complaints', min: 'staff', icon: AlertTriangle },
    { id: 'transcripts', label: 'Transcripts', min: 'staff', icon: MessageSquare },
  ] },
  { title: 'Community', items: [
    { id: 'applications', label: 'Staff Applications', min: 'staff', icon: FileText },
    { id: 'reaction-roles', label: 'Reaction Roles', min: 'admin', icon: Tag },
    { id: 'leveling', label: 'Leveling & XP', min: 'admin', icon: Trophy },
    { id: 'messages', label: 'Announcements', min: 'admin', icon: Megaphone },
    { id: 'vouchers', label: 'Vouchers', min: 'staff', icon: Gift },
    { id: 'content', label: 'Site Content', min: 'admin', icon: Info },
  ] },
  { title: 'Money', items: [
    { id: 'economy', label: 'Economy', min: 'admin', icon: Coins },
    { id: 'store', label: 'Store & Orders', min: 'admin', icon: ShoppingBag },
  ] },
  { title: 'Bot & Game', items: [
    { id: 'bridge', label: 'Minecraft Bridge', min: 'admin', icon: Zap },
    { id: 'bot', label: 'Bot Control', min: 'admin', icon: Settings },
    { id: 'ai', label: 'AI Assistant', min: 'owner', icon: Sparkles },
    { id: 'limits', label: 'Admin Limits', min: 'owner', icon: Shield },
  ] },
  { title: 'Owner', items: [{ id: 'access', label: 'Access', min: 'owner', icon: Key }] },
];
const ITEMS = GROUPS.flatMap((g) => g.items);

export const AdminShell: React.FC<{ route: string }> = ({ route }) => {
  const { user, hasRole, loading } = useAuth();

  if (loading) return <div className="p-16 text-center text-slate-400">Loading…</div>;
  if (!user) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <div className={`${card} p-8`}>
          <h1 className="text-xl font-black text-white">Admin panel</h1>
          <p className="mt-1 text-sm text-slate-400">Sign in with your staff account to continue.</p>
          <Link to="/login" className={`${btnPrimary} mt-5`}>Sign in</Link>
        </div>
      </div>
    );
  }
  if (!hasRole('staff')) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <div className={`${card} p-8`}>
          <h1 className="text-xl font-black text-white">No admin access</h1>
          <p className="mt-2 text-sm text-slate-400">You're signed in as <b className="text-slate-200">{user.email}</b> (a normal player account). Ask the server owner to give your email staff access.</p>
          <Link to="/account" className={`${btnPrimary} mt-5`}>My account</Link>
        </div>
      </div>
    );
  }

  const sub = route.replace(/^\/admin\/?/, '').split('/')[0] || 'overview';
  const visible = ITEMS.filter((i) => hasRole(i.min));
  const current = visible.find((i) => i.id === sub) || visible[0];

  let body: React.ReactNode;
  switch (current.id) {
    case 'complaints': body = <MinecraftComplaintsManager />; break;
    case 'applications': body = <StaffApplicationsManager user={{ email: user.email, role: user.isAdmin ? 'admin' : 'user', isAdmin: user.isAdmin, verifiedAt: new Date().toISOString() }} />; break;
    case 'transcripts': body = <TranscriptsAdmin />; break;
    case 'reaction-roles': body = <ReactionRoleManager />; break;
    case 'leveling': body = <LevelingSystem />; break;
    case 'bridge': body = <MinecraftBridgeManager />; break;
    case 'store': body = <StoreAdmin />; break;
    case 'economy': body = <EconomyAdmin />; break;
    case 'vouchers': body = <VouchersAdmin />; break;
    case 'messages': body = <MessageBuilder />; break;
    case 'content': body = <SiteContentAdmin />; break;
    case 'ai': body = <AiSettings />; break;
    case 'limits': body = <SecurityLimits />; break;
    case 'bot': body = <div className="space-y-6"><RamUsageMonitor /><BotProcessManager /></div>; break;
    case 'access': body = <AccessManager />; break;
    default: body = <Overview />;
  }

  return (
    <div className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:px-6 lg:grid-cols-[230px_1fr]">
      <aside className="lg:sticky lg:top-24 lg:self-start">
        <nav className="glass flex gap-2 overflow-x-auto rounded-2xl p-2 lg:flex-col lg:gap-0.5 lg:overflow-visible" aria-label="Admin sections">
          {GROUPS.map((g) => {
            const items = g.items.filter((i) => hasRole(i.min));
            if (!items.length) return null;
            return (
              <React.Fragment key={g.title}>
                <div className="hidden px-3 pb-1 pt-3 text-[10px] font-black uppercase tracking-wider text-slate-500 lg:block">{g.title}</div>
                {items.map(({ id, label, icon: Icon }) => (
                  <Link key={id} to={`/admin/${id}`} className={`flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-bold transition ${current.id === id ? 'bg-gradient-to-r from-emerald-400 to-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20' : 'text-slate-300 hover:bg-slate-800/80'}`}>
                    <Icon className="h-4 w-4" /> {label}
                  </Link>
                ))}
              </React.Fragment>
            );
          })}
        </nav>
      </aside>
      <div className="min-w-0">{body}</div>
    </div>
  );
};
