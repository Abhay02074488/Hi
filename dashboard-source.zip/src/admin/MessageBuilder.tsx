import React, { useCallback, useEffect, useState } from 'react';
import { Calendar, Plus, Send, Trash2 } from 'lucide-react';
import { api, errText } from '../lib/api';
import { btnDanger, btnGhost, btnPrimary, input } from '../site/ui';
import { BotOffline, Label, Notice, Panel, Title, Toggle } from './kit';

interface Btn { label: string; url: string }
interface Sched { id: string; channel_id: string; send_at: number; content: string; embed: any; status: string; result?: string }

export const MessageBuilder: React.FC = () => {
  const [channels, setChannels] = useState<Array<{ id: string; name: string; category: string }>>([]);
  const [err, setErr] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [channel, setChannel] = useState('');
  const [content, setContent] = useState('');
  const [embed, setEmbed] = useState({ title: '', description: '', color: '#f97316', image: '', thumbnail: '', footer: '', author: '' });
  const [buttons, setButtons] = useState<Btn[]>([]);
  const [pings, setPings] = useState(false);
  const [when, setWhen] = useState('');
  const [items, setItems] = useState<Sched[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const c = await api('GET', '/api/botadmin/channels');
    if (!c.ok) return setErr(errText(c.data));
    setErr(''); setChannels(c.data.channels); if (!channel && c.data.channels[0]) setChannel(c.data.channels[0].id);
    const s = await api('GET', '/api/botadmin/schedule'); if (s.ok) setItems(s.data.items);
  }, [channel]);
  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const payload = () => ({ channel_id: channel, content, embed, buttons, allow_pings: pings });
  const say = (ok: boolean, text: string) => setMsg({ ok, text });
  const sendNow = async () => { setBusy(true); const { ok, data } = await api('POST', '/api/botadmin/send', payload()); setBusy(false); say(ok, ok ? 'Message sent! ✅' : errText(data)); };
  const schedule = async () => {
    const t = Date.parse(when);
    if (!when || isNaN(t)) return say(false, 'Pick the date and time first.');
    const { ok, data } = await api('POST', '/api/botadmin/schedule', { ...payload(), send_at: t / 1000 });
    say(ok, ok ? 'Scheduled! It will be sent automatically.' : errText(data)); if (ok) load();
  };
  const chName = (id: string) => channels.find((c) => c.id === id)?.name || id;
  const colorOk = /^#[0-9a-fA-F]{6}$/.test(embed.color);
  const hasEmbed = Object.entries(embed).some(([k, v]) => k !== 'color' && v);

  if (err) return <div className="space-y-4"><Title icon="📣" title="Message builder" /><BotOffline error={err} /></div>;
  return (
    <div className="space-y-6">
      <Title icon="📣" title="Announcements & embed builder" sub="Design a message, see it live, then send it to any channel now or later." />
      <Notice msg={msg} />
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Compose">
          <div className="space-y-4">
            <Label text="Channel"><select className={input} value={channel} onChange={(e) => setChannel(e.target.value)}>{channels.map((c) => <option key={c.id} value={c.id}>#{c.name}{c.category ? ` — ${c.category}` : ''}</option>)}</select></Label>
            <Label text="Message text" hint="(optional, above the embed)"><textarea className={`${input} min-h-[70px]`} maxLength={2000} value={content} onChange={(e) => setContent(e.target.value)} /></Label>
            <div className="grid gap-3 sm:grid-cols-[1fr_120px]">
              <Label text="Embed title"><input className={input} maxLength={256} value={embed.title} onChange={(e) => setEmbed({ ...embed, title: e.target.value })} /></Label>
              <Label text="Colour"><div className="flex gap-2"><input type="color" className="h-[42px] w-12 cursor-pointer rounded-lg border border-slate-700 bg-slate-950" value={colorOk ? embed.color : '#f97316'} onChange={(e) => setEmbed({ ...embed, color: e.target.value })} aria-label="Pick colour" /><input className={input} value={embed.color} onChange={(e) => setEmbed({ ...embed, color: e.target.value })} /></div></Label>
            </div>
            <Label text="Embed description"><textarea className={`${input} min-h-[120px]`} maxLength={4000} value={embed.description} onChange={(e) => setEmbed({ ...embed, description: e.target.value })} /></Label>
            <div className="grid gap-3 sm:grid-cols-2">
              <Label text="Big image URL"><input className={input} placeholder="https://…" value={embed.image} onChange={(e) => setEmbed({ ...embed, image: e.target.value })} /></Label>
              <Label text="Thumbnail URL"><input className={input} placeholder="https://…" value={embed.thumbnail} onChange={(e) => setEmbed({ ...embed, thumbnail: e.target.value })} /></Label>
              <Label text="Author line"><input className={input} maxLength={100} value={embed.author} onChange={(e) => setEmbed({ ...embed, author: e.target.value })} /></Label>
              <Label text="Footer"><input className={input} maxLength={200} value={embed.footer} onChange={(e) => setEmbed({ ...embed, footer: e.target.value })} /></Label>
            </div>
            <div>
              <div className="mb-2 flex items-center justify-between text-xs font-bold text-slate-400">Link buttons <span className="font-normal text-slate-500">(max 5)</span></div>
              {buttons.map((b, i) => (
                <div key={i} className="mb-2 flex gap-2"><input className={input} placeholder="Label" maxLength={80} value={b.label} onChange={(e) => setButtons(buttons.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))} />
                  <input className={input} placeholder="https://…" value={b.url} onChange={(e) => setButtons(buttons.map((x, j) => (j === i ? { ...x, url: e.target.value } : x)))} />
                  <button type="button" className={btnDanger} aria-label="Remove button" onClick={() => setButtons(buttons.filter((_, j) => j !== i))}><Trash2 className="h-3.5 w-3.5" /></button></div>))}
              {buttons.length < 5 ? <button type="button" className={`${btnGhost} !py-1.5 !text-xs`} onClick={() => setButtons([...buttons, { label: '', url: '' }])}><Plus className="h-3.5 w-3.5" /> Add button</button> : null}
            </div>
            <Toggle on={pings} onChange={setPings} label={pings ? '@everyone / role pings are ALLOWED' : 'Pings are blocked (safe)'} />
          </div>
        </Panel>

        <div className="space-y-6">
          <Panel title="Live preview">
            <div className="rounded-xl bg-[#313338] p-4 text-[#dbdee1]">
              <div className="flex gap-3"><div className="h-10 w-10 shrink-0 rounded-full bg-emerald-500" />
                <div className="min-w-0 flex-1"><div className="text-sm font-bold text-white">WonderMc <span className="ml-1 rounded bg-indigo-500 px-1 text-[10px]">APP</span></div>
                  {content ? <p className="mt-1 whitespace-pre-wrap break-words text-sm">{content}</p> : null}
                  {hasEmbed ? (
                    <div className="mt-2 flex max-w-md overflow-hidden rounded bg-[#2b2d31]"><div className="w-1 shrink-0" style={{ background: colorOk ? embed.color : '#5865f2' }} />
                      <div className="min-w-0 flex-1 p-3">
                        {embed.author ? <div className="mb-1 text-xs font-bold text-white">{embed.author}</div> : null}
                        <div className="flex gap-3"><div className="min-w-0 flex-1">{embed.title ? <div className="font-bold text-white">{embed.title}</div> : null}
                          {embed.description ? <p className="mt-1 whitespace-pre-wrap break-words text-sm">{embed.description}</p> : null}</div>
                          {/^https?:\/\//.test(embed.thumbnail) ? <img src={embed.thumbnail} alt="" className="h-16 w-16 rounded object-cover" /> : null}</div>
                        {/^https?:\/\//.test(embed.image) ? <img src={embed.image} alt="" className="mt-2 max-h-56 rounded object-cover" /> : null}
                        {embed.footer ? <div className="mt-2 text-xs text-[#949ba4]">{embed.footer}</div> : null}</div></div>) : null}
                  {buttons.filter((b) => b.label).length ? <div className="mt-2 flex flex-wrap gap-2">{buttons.filter((b) => b.label).map((b, i) => <span key={i} className="rounded bg-[#4e5058] px-3 py-1.5 text-sm font-semibold text-white">{b.label} ↗</span>)}</div> : null}
                  {!content && !hasEmbed ? <p className="mt-1 text-sm italic text-[#949ba4]">Your message will appear here…</p> : null}
                </div></div>
            </div>
          </Panel>
          <Panel title="Send">
            <button type="button" className={`${btnPrimary} w-full`} disabled={busy || !channel} onClick={sendNow}><Send className="h-4 w-4" /> {busy ? 'Sending…' : 'Send now'}</button>
            <div className="mt-4 flex gap-2"><input type="datetime-local" className={input} value={when} onChange={(e) => setWhen(e.target.value)} aria-label="Send at" />
              <button type="button" className={btnGhost} onClick={schedule}><Calendar className="h-4 w-4" /> Schedule</button></div>
            <p className="mt-2 text-xs text-slate-500">Scheduled messages are sent by the bot, so it has to be online at that time.</p>
          </Panel>
        </div>
      </div>

      <Panel title={`Scheduled messages (${items.length})`}>
        {items.length === 0 ? <p className="text-sm text-slate-400">Nothing scheduled.</p> : (
          <ul className="divide-y divide-slate-800/70">{items.map((s) => (
            <li key={s.id} className="flex flex-wrap items-center gap-3 py-3 text-sm"><span className="font-bold text-white">#{chName(s.channel_id)}</span>
              <span className="text-slate-400">{new Date(s.send_at * 1000).toLocaleString()}</span><span className="min-w-0 flex-1 truncate text-slate-300">{s.embed?.title || s.content}</span>
              <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${s.status === 'sent' ? 'bg-emerald-950 text-emerald-300' : s.status === 'failed' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'}`} title={s.result}>{s.status}</span>
              <button type="button" className={btnDanger} aria-label="Delete scheduled message" onClick={async () => { await api('POST', '/api/botadmin/schedule/delete', { id: s.id }); load(); }}><Trash2 className="h-3.5 w-3.5" /></button></li>))}</ul>)}
      </Panel>
    </div>
  );
};
