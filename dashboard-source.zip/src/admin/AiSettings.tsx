import React, { useCallback, useEffect, useState } from 'react';
import { Key, Sparkles } from 'lucide-react';
import { api, errText } from '../lib/api';
import { btnDanger, btnGhost, btnPrimary, input } from '../site/ui';
import { BotOffline, Label, Notice, Panel, Title, Toggle } from './kit';

interface Cfg { enabled: boolean; base_url: string; model: string; api_key_set: boolean; api_key_hint: string; system_prompt: string; max_tokens: number; temperature: number; channels: number[]; cooldown_seconds: number; daily_limit: number; errors: Array<{ at: string; text: string }>; presets: Record<string, { base_url: string; model: string }> }

export const AiSettings: React.FC = () => {
  const [cfg, setCfg] = useState<Cfg | null>(null);
  const [err, setErr] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [key, setKey] = useState('');
  const [channels, setChannels] = useState<Array<{ id: string; name: string }>>([]);
  const [testing, setTesting] = useState(false);

  const load = useCallback(async () => {
    const { ok, data } = await api('GET', '/api/botadmin/ai');
    if (!ok) return setErr(errText(data));
    setErr(''); setCfg(data.config);
    const c = await api('GET', '/api/botadmin/channels'); if (c.ok) setChannels(c.data.channels);
  }, []);
  useEffect(() => { load(); }, [load]);
  const say = (ok: boolean, text: string) => setMsg({ ok, text });

  const save = async (extra: object = {}) => {
    if (!cfg) return;
    const { ok, data } = await api('POST', '/api/botadmin/ai', { ...cfg, ...extra, api_key: key, errors: undefined, presets: undefined });
    say(ok, ok ? 'AI settings saved.' : errText(data));
    if (ok) { setKey(''); setCfg(data.config); }
  };
  const test = async () => { setTesting(true); const { ok, data } = await api('POST', '/api/botadmin/ai/test'); setTesting(false); say(ok, ok ? `✅ The AI answered: “${data.reply}”` : errText(data)); load(); };

  if (err && !cfg) return <div className="space-y-4"><Title icon="🤖" title="AI assistant" /><BotOffline error={err} /></div>;
  if (!cfg) return <div className="text-sm text-slate-400">Loading…</div>;
  return (
    <div className="space-y-6">
      <Title icon="🤖" title="AI assistant" sub="Use ANY AI service that speaks the OpenAI format — just paste its API key. The key is stored on the bot's server and is never shown again." />
      <Notice msg={msg} />
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Connection">
          <div className="space-y-4">
            <Toggle on={cfg.enabled} onChange={(v) => setCfg({ ...cfg, enabled: v })} label={cfg.enabled ? 'AI assistant is ON' : 'AI assistant is OFF'} />
            <Label text="Provider preset"><select className={input} defaultValue="" onChange={(e) => { const p = cfg.presets[e.target.value]; if (p) setCfg({ ...cfg, base_url: p.base_url, model: p.model }); }}>
              <option value="">Choose to fill in the URL + model…</option>{Object.keys(cfg.presets).map((k) => <option key={k} value={k}>{k}</option>)}</select></Label>
            <Label text="Base URL"><input className={input} value={cfg.base_url} onChange={(e) => setCfg({ ...cfg, base_url: e.target.value })} /></Label>
            <Label text="Model"><input className={input} value={cfg.model} onChange={(e) => setCfg({ ...cfg, model: e.target.value })} /></Label>
            <Label text="API key" hint={cfg.api_key_set ? `— current key: ${cfg.api_key_hint}` : '— none saved yet'}>
              <div className="flex gap-2"><div className="relative flex-1"><Key className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                <input className={`${input} pl-9`} type="password" autoComplete="off" placeholder={cfg.api_key_set ? 'Type a new key to replace it (leave empty to keep)' : 'Paste your API key'} value={key} onChange={(e) => setKey(e.target.value)} /></div>
                {cfg.api_key_set ? <button type="button" className={btnDanger} onClick={async () => { const x = await api('POST', '/api/botadmin/ai', { clear_key: true }); say(x.ok, x.ok ? 'Key removed.' : errText(x.data)); load(); }}>Remove</button> : null}</div>
            </Label>
            <div className="flex gap-2"><button type="button" className={btnPrimary} onClick={() => save()}>Save</button>
              <button type="button" className={btnGhost} disabled={testing} onClick={test}><Sparkles className="h-4 w-4" /> {testing ? 'Testing…' : 'Test the connection'}</button></div>
          </div>
        </Panel>

        <Panel title="Behaviour">
          <div className="space-y-4">
            <Label text="Personality / instructions"><textarea className={`${input} min-h-[140px]`} maxLength={1500} value={cfg.system_prompt} onChange={(e) => setCfg({ ...cfg, system_prompt: e.target.value })} /></Label>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Label text="Max reply tokens"><input className={input} type="number" value={cfg.max_tokens} onChange={(e) => setCfg({ ...cfg, max_tokens: Number(e.target.value) })} /></Label>
              <Label text="Creativity 0–1.5"><input className={input} type="number" step="0.1" value={cfg.temperature} onChange={(e) => setCfg({ ...cfg, temperature: Number(e.target.value) })} /></Label>
              <Label text="Cooldown (s)"><input className={input} type="number" value={cfg.cooldown_seconds} onChange={(e) => setCfg({ ...cfg, cooldown_seconds: Number(e.target.value) })} /></Label>
              <Label text="Per-user / day"><input className={input} type="number" value={cfg.daily_limit} onChange={(e) => setCfg({ ...cfg, daily_limit: Number(e.target.value) })} /></Label>
            </div>
            <fieldset><legend className="mb-2 text-xs font-bold text-slate-400">AI channels <span className="font-normal text-slate-500">— the bot answers every message there (it also answers when mentioned anywhere)</span></legend>
              <div className="flex max-h-44 flex-wrap gap-2 overflow-auto">{channels.map((c) => {
                const on = cfg.channels.includes(Number(c.id));
                return <button key={c.id} type="button" onClick={() => setCfg({ ...cfg, channels: on ? cfg.channels.filter((x) => x !== Number(c.id)) : [...cfg.channels, Number(c.id)] })} className={`rounded-lg border px-2.5 py-1 text-xs font-bold ${on ? 'border-emerald-500 bg-emerald-500/15 text-white' : 'border-slate-700 text-slate-400 hover:border-slate-600'}`}>#{c.name}</button>; })}</div></fieldset>
            <button type="button" className={btnPrimary} onClick={() => save()}>Save</button>
          </div>
        </Panel>
      </div>
      <Panel title={`Recent AI errors (${cfg.errors.length})`}>
        {cfg.errors.length === 0 ? <p className="text-sm text-slate-400">No errors. 🎉</p> : <ul className="space-y-1.5 text-xs">{[...cfg.errors].reverse().map((e, i) => <li key={i} className="rounded-lg bg-slate-950/60 px-3 py-2 text-slate-300"><span className="text-slate-500">{new Date(e.at).toLocaleString()}</span> — {e.text}</li>)}</ul>}
      </Panel>
    </div>
  );
};
