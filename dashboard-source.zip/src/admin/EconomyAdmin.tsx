import React, { useCallback, useEffect, useState } from 'react';
import { Coins, Database, RefreshCw, Search } from 'lucide-react';
import { api, errText } from '../lib/api';
import { EconomyVaults } from '../components/EconomyVaults';
import { btnGhost, btnPrimary, input } from '../site/ui';
import { Avatar, BotOffline, Label, Notice, Panel, Tabs, Title } from './kit';

interface Stats { users: number; total_cash: number; total_bank: number; total: number; symbol: string; richest: Array<{ user_id: string; name: string; avatar: string; cash: number; bank: number; net: number }> }
interface Player { user_id: string; name: string; avatar: string; has_account: boolean; cash: number; bank: number; total_earned: number; total_spent: number; streak: number; inventory: Record<string, number> }
const FIELDS: Array<[string, string, string, string]> = [
  ['currency_symbol', 'Currency symbol / emoji', 'text', 'Shown next to every amount'], ['starting_cash', 'Starting money (wallet)', 'number', 'New players begin with this'],
  ['starting_bank', 'Starting money (bank)', 'number', ''], ['bank_capacity', 'Bank capacity', 'number', 'Default bank size'],
  ['wallet_limit', 'Wallet limit', 'number', 'Max cash a player can carry'], ['bank_limit', 'Bank limit', 'number', 'Max the bank can ever hold'],
  ['max_bet', 'Max bet', 'number', 'Largest gamble allowed'], ['cf_limit', 'Coinflip limit', 'number', ''], ['win_chance', 'Gambling win chance %', 'number', '0 – 100'],
];

export const EconomyAdmin: React.FC = () => {
  const [tab, setTab] = useState('overview');
  const [stats, setStats] = useState<Stats | null>(null);
  const [err, setErr] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [q, setQ] = useState('');
  const [players, setPlayers] = useState<Player[]>([]);
  const [amount, setAmount] = useState(100);
  const [cfg, setCfg] = useState<Record<string, any>>({});
  const [backups, setBackups] = useState<Array<{ name: string; size: number; at: number }>>([]);

  const load = useCallback(async () => {
    const s = await api('GET', '/api/botadmin/economy/stats');
    if (!s.ok) return setErr(errText(s.data));
    setErr(''); setStats(s.data);
    const c = await api('GET', '/api/botadmin/economy/config'); if (c.ok) setCfg(c.data.config || {});
    const b = await api('GET', '/api/botadmin/economy/backups'); if (b.ok) setBackups(b.data.backups);
  }, []);
  useEffect(() => { load(); }, [load]);
  const say = (ok: boolean, text: string) => setMsg({ ok, text });
  const search = async () => { const { ok, data } = await api('GET', `/api/botadmin/economy/user?q=${encodeURIComponent(q.trim())}`); setPlayers(ok ? data.users : []); if (!ok) say(false, errText(data)); };
  const adjust = async (p: Player, action: string, where: 'cash' | 'bank') => {
    if (action === 'reset' && !window.confirm(`Reset ${p.name}'s ${where} to 0?`)) return;
    const { ok, data } = await api('POST', '/api/botadmin/economy/adjust', { user_id: p.user_id, action, where, amount });
    say(ok, ok ? `${p.name}: ${where} ${data.before.toLocaleString()} → ${data.after.toLocaleString()}` : errText(data));
    if (ok) { search(); load(); }
  };
  const sym = stats?.symbol || '💵';

  if (err) return <div className="space-y-4"><Title icon="🪙" title="Economy" /><BotOffline error={err} /></div>;
  return (
    <div className="space-y-6">
      <Title icon="🪙" title="Economy admin" sub="Balances, settings, richest players and backups." right={<button type="button" onClick={load} className={btnGhost}><RefreshCw className="h-4 w-4" /> Refresh</button>} />
      <Notice msg={msg} />
      <Tabs tabs={[['overview', 'Overview'], ['players', 'Players'], ['settings', 'Settings'], ['backup', 'Backup'], ['vaults', 'Vaults']]} value={tab} onChange={setTab} />

      {tab === 'overview' && stats ? (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[['Players with money', stats.users.toLocaleString()], ['Money in wallets', `${sym} ${stats.total_cash.toLocaleString()}`], ['Money in banks', `${sym} ${stats.total_bank.toLocaleString()}`], ['Total in the economy', `${sym} ${stats.total.toLocaleString()}`]].map(([k, v]) => (
              <Panel key={k}><div className="text-xs font-bold uppercase tracking-wider text-slate-500">{k}</div><div className="mt-2 text-2xl font-black text-white">{v}</div></Panel>
            ))}
          </div>
          <Panel title="Richest players">
            {stats.richest.length === 0 ? <p className="text-sm text-slate-400">Nobody has money yet.</p> : (
              <ol className="divide-y divide-slate-800/70">{stats.richest.map((r, i) => (
                <li key={r.user_id} className="flex items-center gap-3 py-3"><span className="w-6 text-center font-display text-xl text-emerald-300">{i + 1}</span><Avatar src={r.avatar} name={r.name} size={32} />
                  <span className="flex-1 truncate font-bold text-white">{r.name}</span><span className="text-xs text-slate-500">wallet {r.cash.toLocaleString()} • bank {r.bank.toLocaleString()}</span><span className="font-black text-emerald-300">{sym} {r.net.toLocaleString()}</span></li>))}</ol>)}
          </Panel>
        </>
      ) : null}

      {tab === 'players' ? (
        <Panel title="Find a player">
          <div className="flex gap-2"><div className="relative flex-1"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input className={`${input} pl-9`} placeholder="Name or Discord ID" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && search()} /></div>
            <button type="button" className={btnPrimary} onClick={search}>Search</button></div>
          <div className="mt-4 flex items-center gap-3"><Label text="Amount for add / remove / set"><input className={`${input} !w-40`} type="number" min={0} value={amount} onChange={(e) => setAmount(Number(e.target.value))} /></Label></div>
          <div className="mt-4 space-y-4">
            {players.map((p) => (
              <div key={p.user_id} className="rounded-xl border border-slate-700/70 bg-slate-950/50 p-4">
                <div className="flex flex-wrap items-center gap-3"><Avatar src={p.avatar} name={p.name} /><div className="flex-1"><div className="font-bold text-white">{p.name}</div><div className="font-mono text-[11px] text-slate-500">{p.user_id}</div></div>
                  <div className="text-right text-sm"><div className="text-slate-300">Wallet <b className="text-white">{sym} {p.cash.toLocaleString()}</b></div><div className="text-slate-300">Bank <b className="text-white">{sym} {p.bank.toLocaleString()}</b></div></div></div>
                {Object.keys(p.inventory).length ? <div className="mt-2 flex flex-wrap gap-1.5 text-xs">{Object.entries(p.inventory).map(([k, v]) => <span key={k} className="rounded bg-slate-800 px-2 py-0.5 text-slate-300">{k.replace(/_/g, ' ')} ×{v}</span>)}</div> : null}
                <div className="mt-3 flex flex-wrap gap-2">{(['cash', 'bank'] as const).map((w) => (
                  <div key={w} className="flex flex-wrap items-center gap-1.5 rounded-lg bg-slate-900/80 p-1.5 text-xs"><span className="px-1.5 font-bold uppercase text-slate-500">{w}</span>
                    {['add', 'remove', 'set', 'reset'].map((a) => <button key={a} type="button" onClick={() => adjust(p, a, w)} className="rounded-md bg-slate-800 px-2.5 py-1 font-bold text-slate-200 hover:bg-emerald-600 hover:text-slate-950">{a}</button>)}</div>))}</div>
              </div>
            ))}
            {players.length === 0 ? <p className="text-sm text-slate-500">Search for someone to see their balance and fix it.</p> : null}
          </div>
        </Panel>
      ) : null}

      {tab === 'settings' ? (
        <Panel title="Economy settings">
          <div className="grid gap-4 sm:grid-cols-2">{FIELDS.map(([k, label, type, hint]) => (
            <Label key={k} text={label} hint={hint ? `— ${hint}` : ''}><input className={input} type={type} value={cfg[k] ?? ''} onChange={(e) => setCfg({ ...cfg, [k]: e.target.value })} /></Label>))}</div>
          <button type="button" className={`${btnPrimary} mt-5`} onClick={async () => { const x = await api('POST', '/api/botadmin/economy/config', cfg); say(x.ok, x.ok ? 'Settings saved.' : errText(x.data)); load(); }}><Coins className="h-4 w-4" /> Save settings</button>
        </Panel>
      ) : null}

      {tab === 'backup' ? (
        <Panel title="Database backups">
          <p className="mb-4 text-sm text-slate-400">Makes a safe copy of the whole economy database (the last 10 are kept in <code className="rounded bg-slate-800 px-1">data/backups</code>).</p>
          <button type="button" className={btnPrimary} onClick={async () => { const x = await api('POST', '/api/botadmin/economy/backup'); say(x.ok, x.ok ? x.data.message : errText(x.data)); load(); }}><Database className="h-4 w-4" /> Back up now</button>
          <ul className="mt-4 divide-y divide-slate-800/70 text-sm">{backups.map((b) => <li key={b.name} className="flex justify-between py-2"><span className="font-mono text-slate-200">{b.name}</span><span className="text-slate-500">{(b.size / 1024).toFixed(0)} KB • {new Date(b.at * 1000).toLocaleString()}</span></li>)}</ul>
        </Panel>
      ) : null}

      {tab === 'vaults' ? <EconomyVaults /> : null}
    </div>
  );
};
