import React, { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { api, errText } from '../lib/api';
import { btnDanger, btnGhost, btnPrimary, input } from '../site/ui';
import { Label, Notice, Panel, Title, Toggle } from './kit';

interface Content { announcement: { enabled: boolean; text: string; link: string }; rules: Array<{ title: string; text: string }>; faq: Array<{ q: string; a: string }> }

export const SiteContentAdmin: React.FC = () => {
  const [c, setC] = useState<Content | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => { api('GET', '/api/site/content').then(({ data }) => setC(data.content)); }, []);
  if (!c) return <div className="text-sm text-slate-400">Loading…</div>;
  const save = async () => { const { ok, data } = await api('POST', '/api/site/content', c); setMsg({ ok, text: ok ? 'Saved! The website is updated.' : errText(data) }); if (ok) setC(data.content); };

  return (
    <div className="space-y-6">
      <Title icon="📝" title="Site content" sub="Edit the announcement bar, the rules and the FAQ shown on the website." right={<button type="button" className={btnPrimary} onClick={save}>Save all</button>} />
      <Notice msg={msg} />
      <Panel title="Announcement bar">
        <div className="space-y-3">
          <Toggle on={c.announcement.enabled} onChange={(v) => setC({ ...c, announcement: { ...c.announcement, enabled: v } })} label={c.announcement.enabled ? 'Shown at the top of every page' : 'Hidden'} />
          <Label text="Text"><input className={input} maxLength={200} value={c.announcement.text} onChange={(e) => setC({ ...c, announcement: { ...c.announcement, text: e.target.value } })} /></Label>
          <Label text="Link" hint="(optional, https://…)"><input className={input} value={c.announcement.link} onChange={(e) => setC({ ...c, announcement: { ...c.announcement, link: e.target.value } })} /></Label>
        </div>
      </Panel>
      <Panel title={`Rules (${c.rules.length})`}>
        <div className="space-y-3">{c.rules.map((r, i) => (
          <div key={i} className="grid gap-2 rounded-xl border border-slate-800/80 p-3 sm:grid-cols-[220px_1fr_auto]">
            <input className={input} placeholder="Rule title" maxLength={80} value={r.title} onChange={(e) => setC({ ...c, rules: c.rules.map((x, j) => (j === i ? { ...x, title: e.target.value } : x)) })} />
            <input className={input} placeholder="Explanation" maxLength={500} value={r.text} onChange={(e) => setC({ ...c, rules: c.rules.map((x, j) => (j === i ? { ...x, text: e.target.value } : x)) })} />
            <button type="button" className={btnDanger} aria-label="Delete rule" onClick={() => setC({ ...c, rules: c.rules.filter((_, j) => j !== i) })}><Trash2 className="h-3.5 w-3.5" /></button></div>))}
          <button type="button" className={btnGhost} onClick={() => setC({ ...c, rules: [...c.rules, { title: '', text: '' }] })}><Plus className="h-4 w-4" /> Add rule</button></div>
      </Panel>
      <Panel title={`FAQ (${c.faq.length})`}>
        <div className="space-y-3">{c.faq.map((f, i) => (
          <div key={i} className="space-y-2 rounded-xl border border-slate-800/80 p-3">
            <div className="flex gap-2"><input className={input} placeholder="Question" maxLength={160} value={f.q} onChange={(e) => setC({ ...c, faq: c.faq.map((x, j) => (j === i ? { ...x, q: e.target.value } : x)) })} />
              <button type="button" className={btnDanger} aria-label="Delete question" onClick={() => setC({ ...c, faq: c.faq.filter((_, j) => j !== i) })}><Trash2 className="h-3.5 w-3.5" /></button></div>
            <textarea className={`${input} min-h-[64px]`} placeholder="Answer" maxLength={1000} value={f.a} onChange={(e) => setC({ ...c, faq: c.faq.map((x, j) => (j === i ? { ...x, a: e.target.value } : x)) })} /></div>))}
          <button type="button" className={btnGhost} onClick={() => setC({ ...c, faq: [...c.faq, { q: '', a: '' }] })}><Plus className="h-4 w-4" /> Add question</button></div>
      </Panel>
      <button type="button" className={btnPrimary} onClick={save}>Save all</button>
    </div>
  );
};
