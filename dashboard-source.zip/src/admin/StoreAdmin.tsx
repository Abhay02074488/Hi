import React, { useCallback, useEffect, useState } from 'react';
import { CheckCircle2, RefreshCw } from 'lucide-react';
import { btnGhost, btnPrimary, card, input } from '../site/ui';

interface Order { id: string; minecraftUsername: string; discordTag?: string; items: Array<{ name?: string; productName?: string; quantity?: number }>; finalAmount: number; couponCode?: string; upiRefId?: string; status: string; createdAt: string; verifiedAt?: string }

const FIELDS: Array<[string, string, 'text' | 'number']> = [
  ['serverName', 'Server name', 'text'], ['javaIp', 'Java IP', 'text'], ['javaPort', 'Java port', 'number'],
  ['bedrockIp', 'Bedrock IP', 'text'], ['bedrockPort', 'Bedrock port', 'number'], ['discordUrl', 'Discord invite', 'text'],
  ['storeUrl', 'Store URL', 'text'], ['upiId', 'UPI ID (where customers pay)', 'text'], ['upiName', 'UPI account name', 'text'],
  ['currencySymbol', 'Currency symbol', 'text'], ['currencyCode', 'Currency code', 'text'], ['saleTitle', 'Sale title', 'text'], ['salePercent', 'Sale percent', 'number'],
];

export const StoreAdmin: React.FC = () => {
  const [tab, setTab] = useState<'orders' | 'settings'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [config, setConfig] = useState<Record<string, any> | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [filter, setFilter] = useState<'pending' | 'all'>('pending');

  const load = useCallback(async () => {
    const [o, c] = await Promise.all([fetch('/api/orders').then((r) => r.json()).catch(() => null), fetch('/api/store/config').then((r) => r.json()).catch(() => null)]);
    if (o?.orders) setOrders(o.orders);
    if (c?.config) setConfig(c.config);
  }, []);
  useEffect(() => { load(); }, [load]);

  const sym = config?.currencySymbol || '₹';
  const verify = async (id: string) => {
    if (!window.confirm(`Mark order ${id} as PAID? Only do this after you checked the payment in your UPI app.`)) return;
    const r = await fetch(`/api/orders/${id}/verify`, { method: 'POST' });
    setMsg({ ok: r.ok, text: r.ok ? `Order ${id} marked as paid.` : 'Could not verify that order.' });
    load();
  };
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!config) return;
    const clean: Record<string, any> = { ...config };
    for (const [k, , t] of FIELDS) if (t === 'number') clean[k] = Number(clean[k]) || 0;
    const r = await fetch('/api/store/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(clean) });
    setMsg({ ok: r.ok, text: r.ok ? 'Store settings saved.' : 'Could not save the settings.' });
  };

  const shown = orders.filter((o) => (filter === 'pending' ? o.status === 'pending_verification' : true));
  const pending = orders.filter((o) => o.status === 'pending_verification').length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-black text-white">Store</h1><p className="text-sm text-slate-400">Check payments and edit store settings.</p></div>
        <button type="button" onClick={load} className={btnGhost}><RefreshCw className="h-4 w-4" /> Refresh</button>
      </div>
      <div className="flex gap-2">
        {(['orders', 'settings'] as const).map((t) => (
          <button key={t} type="button" onClick={() => setTab(t)} className={`rounded-xl px-4 py-2 text-sm font-bold ${tab === t ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-300'}`}>{t === 'orders' ? `Orders${pending ? ` (${pending} pending)` : ''}` : 'Settings'}</button>
        ))}
      </div>
      {msg ? <div role="status" className={`rounded-xl border px-4 py-3 text-sm ${msg.ok ? 'border-emerald-900 bg-emerald-950/50 text-emerald-300' : 'border-rose-900 bg-rose-950/50 text-rose-300'}`}>{msg.text}</div> : null}

      {tab === 'orders' ? (
        <div className={`${card} overflow-hidden`}>
          <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3">
            <div className="text-sm font-black text-white">{shown.length} order(s)</div>
            <select value={filter} onChange={(e) => setFilter(e.target.value as 'pending' | 'all')} className="rounded-lg border border-slate-700 bg-slate-950 px-2 py-1 text-xs font-bold text-white"><option value="pending">Needs checking</option><option value="all">All orders</option></select>
          </div>
          {shown.length === 0 ? <div className="p-8 text-center text-sm text-slate-400">No orders here.</div> : (
            <ul className="divide-y divide-slate-800">
              {shown.map((o) => (
                <li key={o.id} className="flex flex-wrap items-center gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2"><span className="font-mono text-sm font-black text-emerald-300">{o.id}</span><span className="font-bold text-white">{o.minecraftUsername}</span>{o.discordTag ? <span className="text-xs text-slate-400">{o.discordTag}</span> : null}</div>
                    <div className="mt-1 text-xs text-slate-400">{(o.items || []).map((i) => `${i.name || i.productName || 'item'}${i.quantity && i.quantity > 1 ? ` ×${i.quantity}` : ''}`).join(', ') || 'no items'}</div>
                    <div className="mt-1 text-xs text-slate-500">UTR/Ref: <span className="font-mono text-slate-300">{o.upiRefId || '—'}</span>{o.couponCode ? ` • coupon ${o.couponCode}` : ''} • {new Date(o.createdAt).toLocaleString()}</div>
                  </div>
                  <div className="text-right"><div className="text-lg font-black text-white">{sym}{o.finalAmount}</div><div className={`text-[10px] font-black uppercase ${o.status === 'completed' ? 'text-emerald-400' : 'text-amber-400'}`}>{o.status.replace('_', ' ')}</div></div>
                  {o.status !== 'completed' ? <button type="button" className={btnPrimary} onClick={() => verify(o.id)}><CheckCircle2 className="h-4 w-4" /> Mark paid</button> : null}
                </li>
              ))}
            </ul>
          )}
          <p className="border-t border-slate-800 px-5 py-3 text-xs text-slate-500">Prices come from the customer's browser, so always compare the amount with what actually arrived in your UPI app before marking an order paid.</p>
        </div>
      ) : (
        <form onSubmit={save} className={`${card} p-5`}>
          {!config ? <div className="text-sm text-slate-400">Loading…</div> : (
            <>
              <div className="grid gap-3 sm:grid-cols-2">
                {FIELDS.map(([k, label, type]) => (
                  <label key={k} className="block text-xs font-bold text-slate-400">{label}
                    <input className={`${input} mt-1`} type={type} value={config[k] ?? ''} onChange={(e) => setConfig({ ...config, [k]: e.target.value })} />
                  </label>
                ))}
                <label className="flex items-center gap-2 text-sm font-bold text-slate-200 sm:col-span-2"><input type="checkbox" checked={!!config.saleActive} onChange={(e) => setConfig({ ...config, saleActive: e.target.checked })} /> Sale is active</label>
              </div>
              <button type="submit" className={`${btnPrimary} mt-5`}>Save settings</button>
            </>
          )}
        </form>
      )}
    </div>
  );
};
