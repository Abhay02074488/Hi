import React, { useCallback, useEffect, useState } from 'react';
import { CheckCircle2, Gift, RefreshCw, Trash2 } from 'lucide-react';
import { api, errText } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { CopyButton, btnDanger, btnGhost, btnPrimary, input } from '../site/ui';
import { BotOffline, Label, Notice, Panel, Tabs, Title } from './kit';

interface Voucher { code: string; label: string; kind: string; amount: number; max_uses: number; uses: number; remaining: number; enabled: boolean; expired: boolean; expires_at: number | null; note: string; created_by: string }
interface Redemption { id: string; code: string; label: string; kind: string; discord_name: string; discord_id: string; minecraft_username: string; redeemed_at: string; status: string; delivered_by: string | null; delivered_at: string | null; note: string }

const when = (iso: string | null) => (iso ? new Date(iso).toLocaleString() : '—');

export const VouchersAdmin: React.FC = () => {
  const { hasRole } = useAuth();
  const admin = hasRole('admin');
  const [tab, setTab] = useState('history');
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [reds, setReds] = useState<Redemption[]>([]);
  const [status, setStatus] = useState('pending');
  const [q, setQ] = useState('');
  const [err, setErr] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [channels, setChannels] = useState<Array<{ id: string; name: string }>>([]);
  const [notify, setNotify] = useState('');
  const [made, setMade] = useState<Voucher[]>([]);
  const [form, setForm] = useState({ label: '', kind: 'ingame', amount: 100, max_uses: 1, expires_days: 0, code: '', count: 1, note: '' });

  const load = useCallback(async () => {
    const [v, r] = await Promise.all([api('GET', '/api/botadmin/vouchers'), api('GET', `/api/botadmin/redemptions?status=${status === 'all' ? '' : status}&q=${encodeURIComponent(q)}`)]);
    if (!v.ok && !r.ok) return setErr(errText(v.data));
    setErr('');
    if (v.ok) { setVouchers(v.data.vouchers); setNotify(v.data.settings?.notify_channel || ''); }
    if (r.ok) setReds(r.data.redemptions);
  }, [status, q]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (admin) api('GET', '/api/botadmin/channels').then(({ ok, data }) => ok && setChannels(data.channels)); }, [admin]);

  const say = (ok: boolean, text: string) => setMsg({ ok, text });
  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    const { ok, data } = await api('POST', '/api/botadmin/vouchers', form);
    if (!ok) return say(false, errText(data));
    setMade(data.created); say(true, `Created ${data.created.length} voucher(s). Copy the code(s) below and share them.`);
    setForm({ ...form, label: '', code: '', count: 1 }); load();
  };
  const deliver = async (r: Redemption) => {
    const { ok, data } = await api('POST', '/api/botadmin/redemptions/deliver', { id: r.id });
    say(ok, ok ? `Marked as delivered to ${r.minecraft_username}.` : errText(data)); load();
  };

  if (err) return <div className="space-y-4"><Title icon="🎟️" title="Vouchers" /><BotOffline error={err} /></div>;
  const pending = reds.filter((r) => r.status === 'pending').length;

  return (
    <div className="space-y-6">
      <Title icon="🎟️" title="Vouchers & redemptions" sub="Players use /redeem in Discord with their Minecraft name. Staff then deliver the reward in game and mark it delivered here."
        right={<button type="button" onClick={load} className={btnGhost}><RefreshCw className="h-4 w-4" /> Refresh</button>} />
      <Notice msg={msg} />
      <Tabs tabs={[['history', `Redemptions${pending && status === 'pending' ? ` (${pending})` : ''}`], ['list', 'Vouchers'], ...(admin ? [['create', 'Create vouchers']] as Array<[string, string]> : [])]} value={tab} onChange={setTab} />

      {tab === 'history' ? (
        <Panel>
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <select className={`${input} !w-auto`} value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status filter"><option value="pending">Needs delivery</option><option value="delivered">Delivered</option><option value="all">All</option></select>
            <input className={`${input} !w-64`} placeholder="Search Minecraft name, Discord name, code…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          {reds.length === 0 ? <p className="py-8 text-center text-sm text-slate-400">{status === 'pending' ? 'Nothing waiting for delivery. 🎉' : 'No redemptions found.'}</p> : (
            <ul className="divide-y divide-slate-800/70">
              {reds.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center gap-4 py-3.5">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2"><span className="font-mono text-base font-black text-emerald-300">{r.minecraft_username}</span>
                      <CopyButton text={r.minecraft_username} className="rounded-lg p-1 text-slate-400 hover:bg-slate-800" />
                      <span className="text-xs text-slate-500">Discord: {r.discord_name}</span></div>
                    <div className="mt-0.5 text-sm font-semibold text-white">🎁 {r.label} <span className="font-mono text-xs font-normal text-slate-500">({r.code})</span></div>
                    <div className="text-xs text-slate-500">Redeemed {when(r.redeemed_at)}{r.status === 'delivered' ? ` • delivered by ${r.delivered_by} ${r.delivered_by === 'auto' ? '' : `on ${when(r.delivered_at)}`}` : ''}</div>
                  </div>
                  {r.status === 'pending'
                    ? <button type="button" className={btnPrimary} onClick={() => deliver(r)}><CheckCircle2 className="h-4 w-4" /> Mark delivered</button>
                    : <span className="rounded-full border border-emerald-700/60 bg-emerald-950/40 px-3 py-1 text-xs font-bold text-emerald-300">Delivered</span>}
                </li>
              ))}
            </ul>
          )}
          {admin ? (
            <div className="mt-6 border-t border-slate-800/70 pt-4">
              <Label text="Alert channel" hint="— the bot posts every new redemption here so staff notice it">
                <div className="flex gap-2"><select className={input} value={notify} onChange={(e) => setNotify(e.target.value)}><option value="">No alerts</option>{channels.map((c) => <option key={c.id} value={c.id}>#{c.name}</option>)}</select>
                  <button type="button" className={btnGhost} onClick={async () => { const x = await api('POST', '/api/botadmin/vouchers/settings', { notify_channel: notify }); say(x.ok, x.ok ? 'Alert channel saved.' : errText(x.data)); }}>Save</button></div>
              </Label>
            </div>
          ) : null}
        </Panel>
      ) : null}

      {tab === 'list' ? (
        <Panel>
          {vouchers.length === 0 ? <p className="py-8 text-center text-sm text-slate-400">No vouchers yet.</p> : (
            <div className="overflow-x-auto"><table className="w-full text-left text-sm">
              <thead><tr className="text-xs uppercase tracking-wider text-slate-500"><th className="pb-2">Code</th><th className="pb-2">Reward</th><th className="pb-2">Used</th><th className="pb-2">Expires</th><th className="pb-2">Status</th>{admin ? <th className="pb-2 text-right">Actions</th> : null}</tr></thead>
              <tbody className="divide-y divide-slate-800/70">
                {vouchers.map((v) => (
                  <tr key={v.code}>
                    <td className="py-3 font-mono font-bold text-emerald-300">{v.code} <CopyButton text={v.code} className="ml-1 rounded p-1 text-slate-400 hover:bg-slate-800" /></td>
                    <td className="py-3 text-white">{v.label}{v.kind === 'wallet' ? <span className="ml-2 rounded bg-slate-800 px-1.5 text-[10px] font-bold text-slate-300">AUTO</span> : null}</td>
                    <td className="py-3 text-slate-300">{v.uses}/{v.max_uses}</td>
                    <td className="py-3 text-slate-400">{v.expires_at ? new Date(v.expires_at * 1000).toLocaleDateString() : 'never'}</td>
                    <td className="py-3"><span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${!v.enabled ? 'bg-slate-800 text-slate-400' : v.expired ? 'bg-rose-950 text-rose-300' : v.remaining === 0 ? 'bg-amber-950 text-amber-300' : 'bg-emerald-950 text-emerald-300'}`}>{!v.enabled ? 'Disabled' : v.expired ? 'Expired' : v.remaining === 0 ? 'Used up' : 'Active'}</span></td>
                    {admin ? <td className="py-3"><div className="flex justify-end gap-2">
                      <button type="button" className={`${btnGhost} !px-3 !py-1.5 !text-xs`} onClick={async () => { await api('POST', '/api/botadmin/vouchers/toggle', { code: v.code, enabled: !v.enabled }); load(); }}>{v.enabled ? 'Disable' : 'Enable'}</button>
                      <button type="button" className={btnDanger} aria-label={`Delete ${v.code}`} onClick={async () => { if (window.confirm(`Delete voucher ${v.code}?`)) { await api('POST', '/api/botadmin/vouchers/delete', { code: v.code }); load(); } }}><Trash2 className="h-3.5 w-3.5" /></button></div></td> : null}
                  </tr>
                ))}
              </tbody></table></div>
          )}
        </Panel>
      ) : null}

      {tab === 'create' && admin ? (
        <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
          <form onSubmit={create}><Panel title="Create vouchers">
            <div className="grid gap-4 sm:grid-cols-2">
              <Label text="Reward type"><select className={input} value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}><option value="ingame">In-game reward (staff delivers)</option><option value="wallet">Discord wallet coins (automatic)</option></select></Label>
              {form.kind === 'wallet'
                ? <Label text="Coins"><input className={input} type="number" min={1} value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} /></Label>
                : <Label text="What does the player get?" hint="e.g. 100 coins, VIP rank, Legendary key"><input className={input} value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} required /></Label>}
              <Label text="How many people can use it?"><input className={input} type="number" min={1} max={10000} value={form.max_uses} onChange={(e) => setForm({ ...form, max_uses: Number(e.target.value) })} /></Label>
              <Label text="Expires after (days)" hint="0 = never"><input className={input} type="number" min={0} value={form.expires_days} onChange={(e) => setForm({ ...form, expires_days: Number(e.target.value) })} /></Label>
              <Label text="Custom code" hint="optional, A-Z 0-9 -"><input className={input} value={form.code} maxLength={24} placeholder="auto-generated" onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} /></Label>
              <Label text="How many codes?" hint="make 1-50 at once"><input className={input} type="number" min={1} max={50} value={form.count} onChange={(e) => setForm({ ...form, count: Number(e.target.value) })} /></Label>
            </div>
            <button type="submit" className={`${btnPrimary} mt-5`}><Gift className="h-4 w-4" /> Create</button>
          </Panel></form>
          <Panel title="New codes">
            {made.length === 0 ? <p className="text-sm text-slate-400">Created codes appear here. Share them with players — they redeem with <code className="rounded bg-slate-800 px-1 text-slate-200">/redeem</code>.</p> : (
              <><ul className="space-y-2">{made.map((v) => <li key={v.code} className="flex items-center justify-between rounded-xl bg-slate-950/70 px-3 py-2.5"><span className="font-mono font-black text-emerald-300">{v.code}</span><span className="text-xs text-slate-400">{v.label}</span><CopyButton text={v.code} className="rounded p-1.5 text-slate-300 hover:bg-slate-800" /></li>)}</ul>
                <div className="mt-3"><CopyButton text={made.map((v) => v.code).join('\n')} label="Copy all codes" /></div></>
            )}
          </Panel>
        </div>
      ) : null}
    </div>
  );
};
