import React, { useEffect, useState } from 'react';
import { AlertCircle, CheckCircle2, ShieldAlert } from 'lucide-react';
import { Link } from '../lib/router';
import { SITE } from '../lib/site';
import { useMcStatus } from '../lib/useMcStatus';
import { useAuth } from '../context/AuthContext';
import { StatusPill, card } from '../site/ui';

interface Check { level: 'ok' | 'warn' | 'bad'; text: string }

export const Overview: React.FC = () => {
  const { user, hasRole } = useAuth();
  const mc = useMcStatus();
  const [pendingApps, setPendingApps] = useState<number | null>(null);
  const [pendingOrders, setPendingOrders] = useState<number | null>(null);
  const [accounts, setAccounts] = useState<number | null>(null);
  const [bot, setBot] = useState<any>(null);
  const [deliveries, setDeliveries] = useState<number | null>(null);
  const [checks, setChecks] = useState<Check[]>([]);

  useEffect(() => {
    fetch('/api/botadmin/overview').then((r) => r.json()).then((d) => { if (d?.success) setBot(d.bot); }).catch(() => {});
    fetch('/api/botadmin/redemptions?status=pending').then((r) => r.json()).then((d) => { if (Array.isArray(d?.redemptions)) setDeliveries(d.redemptions.length); }).catch(() => {});
    fetch('/api/applications/submissions').then((r) => r.json()).then((d) => {
      if (Array.isArray(d?.submissions)) setPendingApps(d.submissions.filter((s: any) => s.status === 'pending').length);
    }).catch(() => {});
    if (hasRole('admin')) {
      fetch('/api/orders').then((r) => r.json()).then((d) => {
        if (Array.isArray(d?.orders)) setPendingOrders(d.orders.filter((o: any) => o.status === 'pending_verification').length);
      }).catch(() => {});
    }
    if (hasRole('owner')) {
      fetch('/api/access/users').then((r) => r.json()).then((d) => { if (Array.isArray(d?.users)) setAccounts(d.users.length); }).catch(() => {});
      fetch('/api/security/status').then((r) => r.json()).then((d) => { if (Array.isArray(d?.checks)) setChecks(d.checks); }).catch(() => {});
    }
  }, [hasRole]);

  const tile = (label: string, value: React.ReactNode, to?: string, hint?: string) => {
    const body = (
      <div className={`${card} h-full p-5 transition ${to ? 'hover:border-emerald-700' : ''}`}>
        <div className="text-xs font-bold uppercase tracking-wider text-slate-500">{label}</div>
        <div className="mt-2 text-3xl font-black text-white">{value}</div>
        {hint ? <div className="mt-1 text-xs text-slate-400">{hint}</div> : null}
      </div>
    );
    return to ? <Link to={to} key={label}>{body}</Link> : <div key={label}>{body}</div>;
  };
  const problems = checks.filter((c) => c.level !== 'ok');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl text-white">Welcome back, {user?.name} 🎃</h1>
        <p className="text-sm text-slate-400">Here's what needs your attention.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {tile('Minecraft server', <StatusPill online={mc.online} loading={mc.loading} failed={mc.failed} />, '/status', mc.online ? `${mc.players.online}/${mc.players.max} players${mc.ping !== null ? ` • ${mc.ping} ms` : ''}` : SITE.ip)}
        {tile('Discord bot', bot ? <span className="text-emerald-300">Online</span> : <span className="text-slate-500">–</span>, undefined, bot ? `${bot.guild_count} server(s) • ${bot.member_count} members • ${bot.latency_ms ?? '?'} ms` : 'Not reachable right now')}
        {tile('Rewards to deliver', deliveries ?? '–', '/admin/vouchers', 'Voucher redemptions waiting for staff')}
        {tile('Applications waiting', pendingApps ?? '–', '/admin/applications', 'Staff applications to review')}
        {hasRole('admin') ? tile('Orders to check', pendingOrders ?? '–', '/admin/store', 'Payments waiting for verification') : null}
        {hasRole('owner') ? tile('Accounts', accounts ?? '–', '/admin/access', 'People with a website account') : null}
      </div>

      {hasRole('owner') && checks.length ? (
        <div className={`${card} p-5`}>
          <h2 className="flex items-center gap-2 font-black text-white"><ShieldAlert className="h-4 w-4 text-amber-400" /> Security {problems.length ? `— ${problems.length} thing(s) to fix` : '— all good'}</h2>
          <ul className="mt-3 space-y-2">
            {(problems.length ? problems : checks).map((c, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                {c.level === 'ok' ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> : <AlertCircle className={`mt-0.5 h-4 w-4 shrink-0 ${c.level === 'bad' ? 'text-rose-400' : 'text-amber-400'}`} />}
                <span className={c.level === 'bad' ? 'text-rose-300' : c.level === 'warn' ? 'text-amber-200' : 'text-slate-300'}>{c.text}</span>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <div className={`${card} p-5`}>
        <h2 className="font-black text-white">Quick links</h2>
        <div className="mt-3 flex flex-wrap gap-2 text-sm">
          <Link to="/admin/applications" className="rounded-xl bg-slate-800 px-4 py-2 font-bold text-slate-200 hover:bg-slate-700">Review applications</Link>
          {hasRole('admin') ? <Link to="/admin/bridge" className="rounded-xl bg-slate-800 px-4 py-2 font-bold text-slate-200 hover:bg-slate-700">Minecraft ⇄ Discord bridge</Link> : null}
          {hasRole('admin') ? <Link to="/admin/store" className="rounded-xl bg-slate-800 px-4 py-2 font-bold text-slate-200 hover:bg-slate-700">Store orders</Link> : null}
          <a href={SITE.discord} target="_blank" rel="noreferrer" className="rounded-xl bg-indigo-500 px-4 py-2 font-bold text-white hover:bg-indigo-400">Open Discord</a>
        </div>
      </div>
    </div>
  );
};
