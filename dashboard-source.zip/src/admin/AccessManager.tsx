import React, { useCallback, useEffect, useState } from 'react';
import { AlertCircle, CheckCircle2, Crown, Key, Plus, RefreshCw, Shield, ShieldAlert, Trash2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { btnDanger, btnGhost, btnPrimary, card, input } from '../site/ui';

interface Row { id: string; email: string; name: string; role: 'owner' | 'admin' | 'staff' | 'user'; disabled?: boolean; createdAt: string; lastLogin?: string }
interface Check { level: 'ok' | 'warn' | 'bad'; text: string }

async function api(url: string, method: string, body?: unknown) {
  try {
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok && data?.success !== false, data };
  } catch {
    return { ok: false, data: { error: 'Could not reach the server.' } };
  }
}

const LEGEND: Array<[string, string, string]> = [
  ['owner', 'Everything, including this page.', 'text-amber-300'],
  ['admin', 'Whole admin panel: store, bridge, reaction roles, bot control.', 'text-emerald-300'],
  ['staff', 'Applications, transcripts and read-only tools.', 'text-cyan-300'],
  ['user', 'Normal website account. No admin access.', 'text-slate-300'],
];

export const AccessManager: React.FC = () => {
  const { user: me } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [checks, setChecks] = useState<Check[]>([]);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [form, setForm] = useState({ email: '', name: '', password: '', role: 'staff' });
  const [resetFor, setResetFor] = useState<string | null>(null);
  const [resetPw, setResetPw] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [u, s] = await Promise.all([api('/api/access/users', 'GET'), api('/api/security/status', 'GET')]);
    if (u.ok) setRows(u.data.users || []);
    if (s.ok) setChecks(s.data.checks || []);
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  const say = (ok: boolean, text: string) => setMsg({ ok, text });

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await api('/api/access/users', 'POST', form);
    if (!r.ok) return say(false, r.data?.error || 'Could not create the account.');
    say(true, `Account created for ${form.email}. Give them the password you chose — they can change it on their Account page.`);
    setForm({ email: '', name: '', password: '', role: 'staff' });
    load();
  };

  const patch = async (id: string, body: object, okText: string) => {
    const r = await api(`/api/access/users/${id}`, 'POST', body);
    say(r.ok, r.ok ? okText : r.data?.error || 'Update failed.');
    if (r.ok) load();
    return r.ok;
  };

  const remove = async (row: Row) => {
    if (!window.confirm(`Delete the account ${row.email}? This cannot be undone.`)) return;
    const r = await api(`/api/access/users/${row.id}`, 'DELETE');
    say(r.ok, r.ok ? 'Account deleted.' : r.data?.error || 'Delete failed.');
    if (r.ok) load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-white">Access control</h1>
          <p className="text-sm text-slate-400">Only you (the owner) can see this page. Decide who can use the admin panel.</p>
        </div>
        <button type="button" onClick={load} className={btnGhost}><RefreshCw className="h-4 w-4" /> Refresh</button>
      </div>

      {msg ? <div role="status" className={`rounded-xl border px-4 py-3 text-sm ${msg.ok ? 'border-emerald-900 bg-emerald-950/50 text-emerald-300' : 'border-rose-900 bg-rose-950/50 text-rose-300'}`}>{msg.text}</div> : null}

      <div className="grid gap-4 md:grid-cols-4">
        {LEGEND.map(([role, text, color]) => (
          <div key={role} className={`${card} p-4`}><div className={`text-xs font-black uppercase tracking-wider ${color}`}>{role}</div><div className="mt-1 text-xs text-slate-400">{text}</div></div>
        ))}
      </div>

      <form onSubmit={create} className={`${card} p-5`}>
        <h2 className="flex items-center gap-2 font-black text-white"><Plus className="h-4 w-4 text-emerald-400" /> Give someone access</h2>
        <p className="mt-1 text-xs text-slate-400">Create their account with a password, or let them sign up on the site and then change their role below.</p>
        <div className="mt-4 grid gap-3 md:grid-cols-5">
          <input className={`${input} md:col-span-2`} type="email" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
          <input className={input} placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className={input} type="text" placeholder="Password (8+, with a number)" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
          <select className={input} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
            <option value="staff">Staff</option><option value="admin">Admin</option><option value="user">User</option><option value="owner">Owner</option>
          </select>
        </div>
        <button type="submit" className={`${btnPrimary} mt-4`}>Create account</button>
      </form>

      <div className={`${card} overflow-hidden`}>
        <div className="border-b border-slate-800 px-5 py-3 text-sm font-black text-white">Accounts ({rows.length})</div>
        {loading ? <div className="p-6 text-sm text-slate-400">Loading…</div> : (
          <ul className="divide-y divide-slate-800">
            {rows.map((r) => {
              const self = r.id === me?.id;
              return (
                <li key={r.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 font-bold text-white">
                      {r.role === 'owner' ? <Crown className="h-4 w-4 text-amber-400" /> : r.role === 'user' ? null : <Shield className="h-4 w-4 text-emerald-400" />}
                      <span className="truncate">{r.name}</span>
                      {self ? <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-black text-slate-300">YOU</span> : null}
                      {r.disabled ? <span className="rounded bg-rose-950 px-1.5 py-0.5 text-[10px] font-black text-rose-300">DISABLED</span> : null}
                    </div>
                    <div className="truncate text-xs text-slate-400">{r.email} • joined {new Date(r.createdAt).toLocaleDateString()}{r.lastLogin ? ` • last login ${new Date(r.lastLogin).toLocaleString()}` : ''}</div>
                  </div>
                  <select className="rounded-lg border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs font-bold text-white disabled:opacity-50" disabled={self} value={r.role}
                    onChange={(e) => patch(r.id, { role: e.target.value }, `${r.email} is now ${e.target.value}.`)}>
                    <option value="owner">owner</option><option value="admin">admin</option><option value="staff">staff</option><option value="user">user</option>
                  </select>
                  <button type="button" className={btnGhost + ' !px-3 !py-1.5 !text-xs'} onClick={() => { setResetFor(resetFor === r.id ? null : r.id); setResetPw(''); }}><Key className="h-3.5 w-3.5" /> Reset password</button>
                  <button type="button" disabled={self} className={btnGhost + ' !px-3 !py-1.5 !text-xs'} onClick={() => patch(r.id, { disabled: !r.disabled }, r.disabled ? 'Account enabled.' : 'Account disabled and signed out.')}>{r.disabled ? 'Enable' : 'Disable'}</button>
                  <button type="button" disabled={self} className={btnDanger} onClick={() => remove(r)}><Trash2 className="h-3.5 w-3.5" /></button>
                  {resetFor === r.id ? (
                    <div className="flex w-full gap-2">
                      <input className={input} type="text" placeholder="New password (8+, with a number)" value={resetPw} onChange={(e) => setResetPw(e.target.value)} />
                      <button type="button" className={btnPrimary} onClick={async () => { if (await patch(r.id, { password: resetPw }, 'Password reset. They were signed out everywhere.')) setResetFor(null); }}>Save</button>
                    </div>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div className={`${card} p-5`}>
        <h2 className="flex items-center gap-2 font-black text-white"><ShieldAlert className="h-4 w-4 text-amber-400" /> Security checklist</h2>
        <ul className="mt-3 space-y-2">
          {checks.map((c, i) => (
            <li key={i} className="flex items-start gap-2 text-sm">
              {c.level === 'ok' ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> : <AlertCircle className={`mt-0.5 h-4 w-4 shrink-0 ${c.level === 'bad' ? 'text-rose-400' : 'text-amber-400'}`} />}
              <span className={c.level === 'ok' ? 'text-slate-300' : c.level === 'bad' ? 'text-rose-300' : 'text-amber-200'}>{c.text}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
