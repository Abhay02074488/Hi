import React from 'react';
import { card } from '../site/ui';

export const Notice: React.FC<{ msg: { ok: boolean; text: string } | null }> = ({ msg }) =>
  msg ? <div role="status" className={`rounded-xl border px-4 py-3 text-sm ${msg.ok ? 'border-emerald-700/60 bg-emerald-950/40 text-emerald-300' : 'border-rose-900 bg-rose-950/50 text-rose-300'}`}>{msg.text}</div> : null;

export const Avatar: React.FC<{ src?: string; name: string; size?: number }> = ({ src, name, size = 36 }) =>
  src ? <img src={src} alt="" width={size} height={size} className="rounded-full bg-slate-800 object-cover" style={{ width: size, height: size }} onError={(e) => { (e.target as HTMLImageElement).style.visibility = 'hidden'; }} />
    : <span className="flex items-center justify-center rounded-full bg-slate-800 font-bold text-slate-300" style={{ width: size, height: size }}>{name.slice(0, 1).toUpperCase()}</span>;

export const Toggle: React.FC<{ on: boolean; onChange: (v: boolean) => void; label: string }> = ({ on, onChange, label }) => (
  <button type="button" role="switch" aria-checked={on} onClick={() => onChange(!on)} className="flex items-center gap-3 text-sm font-bold text-slate-200">
    <span className={`relative h-6 w-11 rounded-full transition ${on ? 'bg-emerald-500' : 'bg-slate-700'}`}><span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${on ? 'left-[22px]' : 'left-0.5'}`} /></span>{label}
  </button>
);

export const Tabs: React.FC<{ tabs: Array<[string, string]>; value: string; onChange: (v: string) => void }> = ({ tabs, value, onChange }) => (
  <div className="flex flex-wrap gap-2" role="tablist">
    {tabs.map(([id, label]) => (
      <button key={id} type="button" role="tab" aria-selected={value === id} onClick={() => onChange(id)}
        className={`rounded-xl px-4 py-2 text-sm font-bold transition ${value === id ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'}`}>{label}</button>
    ))}
  </div>
);

export const Title: React.FC<{ icon?: string; title: string; sub?: string; right?: React.ReactNode }> = ({ icon, title, sub, right }) => (
  <div className="flex flex-wrap items-start justify-between gap-3">
    <div><h1 className="font-display text-3xl text-white">{icon ? `${icon} ` : ''}{title}</h1>{sub ? <p className="mt-1 text-sm text-slate-400">{sub}</p> : null}</div>
    {right}
  </div>
);

export const Panel: React.FC<{ title?: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
  <div className={`${card} p-5 ${className || ''}`}>{title ? <h2 className="mb-4 font-black text-white">{title}</h2> : null}{children}</div>
);

export const Label: React.FC<{ text: string; hint?: string; children: React.ReactNode }> = ({ text, hint, children }) => (
  <label className="block text-xs font-bold text-slate-400">{text}{hint ? <span className="ml-1 font-normal text-slate-500">{hint}</span> : null}<div className="mt-1.5">{children}</div></label>
);

export const BotOffline: React.FC<{ error?: string }> = ({ error }) => (
  <div className="rounded-xl border border-amber-800/70 bg-amber-950/30 px-4 py-3 text-sm text-amber-200">
    ⚠️ {error || 'The bot did not answer.'} <span className="text-amber-300/70">Check that the bot is running and that the dashboard and the bot use the same BRIDGE_SECRET.</span>
  </div>
);
