import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Search, ShieldAlert, Trash2, RefreshCw } from 'lucide-react';
import { api, errText } from '../lib/api';
import { btnDanger, btnGhost, btnPrimary, input } from '../site/ui';
import { Avatar, BotOffline, Label, Notice, Panel, Title, Toggle } from './kit';

interface Member { id: string; name: string; username: string; avatar: string; top_role: string }
interface Row { user_id: string; name: string; avatar: string; kick: number; ban: number; period: string; used_kick: number; used_ban: number }
interface Data { enabled: boolean; limit_action: string; default: { kick: number; ban: number; period: string }; users: Row[]; actions: string[]; periods: string[]; guild: { name: string } }

const PERIOD_LABEL: Record<string, string> = { daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', lifetime: 'Lifetime' };
const ACTION_LABEL: Record<string, string> = { kick: 'Kick them from the server', ban: 'Ban them', quarantine: 'Quarantine (remove roles, add a Quarantined role)', strip_roles: 'Remove all their roles', timeout: 'Time them out for 24 hours' };

const Bar: React.FC<{ used: number; max: number }> = ({ used, max }) => {
  const pct = max <= 0 ? 100 : Math.min(100, (used / max) * 100);
  return (
    <div className="min-w-[96px]"><div className="text-xs font-bold text-slate-200">{used}/{max}</div>
      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-800"><div className={`h-full rounded-full ${pct >= 100 ? 'bg-rose-500' : pct >= 70 ? 'bg-amber-400' : 'bg-emerald-400'}`} style={{ width: `${pct}%` }} /></div></div>
  );
};

export const SecurityLimits: React.FC = () => {
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [term, setTerm] = useState('');
  const [hits, setHits] = useState<Member[]>([]);
  const [picked, setPicked] = useState<{ id: string; name: string; avatar: string } | null>(null);
  const [kick, setKick] = useState(5);
  const [ban, setBan] = useState(3);
  const [period, setPeriod] = useState('daily');
  const timer = useRef<any>(null);

  const load = useCallback(async () => {
    const { ok, data: d } = await api('GET', '/api/botadmin/security');
    if (ok) { setData(d); setError(''); } else setError(errText(d));
  }, []);
  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    clearTimeout(timer.current);
    if (term.trim().length < 2) { setHits([]); return; }
    timer.current = setTimeout(async () => {
      const { ok, data: d } = await api('GET', `/api/botadmin/members?q=${encodeURIComponent(term.trim())}`);
      setHits(ok ? d.members : []);
    }, 250);
    return () => clearTimeout(timer.current);
  }, [term]);

  const say = (ok: boolean, text: string) => setMsg({ ok, text });
  const save = async () => {
    if (!picked) return say(false, 'Pick a user first.');
    const { ok, data: d } = await api('POST', '/api/botadmin/security/limit', { user_id: picked.id, kick, ban, period });
    say(ok, ok ? `Saved: ${picked.name} may kick ${kick} and ban ${ban} (${PERIOD_LABEL[period].toLowerCase()}).` : errText(d));
    if (ok) { setPicked(null); setTerm(''); load(); }
  };
  const settings = async (patch: object, okText: string) => {
    const { ok, data: d } = await api('POST', '/api/botadmin/security/settings', patch);
    say(ok, ok ? okText : errText(d));
    if (ok) load();
  };

  if (error && !data) return <div className="space-y-4"><Title icon="🛡️" title="Admin Management — User Limits" /><BotOffline error={error} /></div>;
  if (!data) return <div className="text-sm text-slate-400">Loading…</div>;

  return (
    <div className="space-y-6">
      <Title icon="🛡️" title="Admin Management — User Limits" sub={`Control how many members each admin or moderator may kick and ban in ${data.guild.name}.`}
        right={<button type="button" onClick={load} className={btnGhost}><RefreshCw className="h-4 w-4" /> Refresh</button>} />
      <Notice msg={msg} />

      <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        <Panel title="Manage admin limits">
          <div className="space-y-5">
            <div>
              <div className="mb-1.5 text-xs font-bold text-slate-400">Select user / admin</div>
              {picked ? (
                <div className="flex items-center justify-between rounded-xl border border-emerald-700/60 bg-emerald-950/30 px-3 py-2.5">
                  <span className="flex items-center gap-2.5 font-bold text-white"><Avatar src={picked.avatar} name={picked.name} /> @{picked.name}</span>
                  <button type="button" className="text-xs font-bold text-slate-400 hover:text-white" onClick={() => setPicked(null)}>Change</button>
                </div>
              ) : (
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                  <input className={`${input} pl-9`} placeholder="Type a name or paste a Discord ID…" value={term} onChange={(e) => setTerm(e.target.value)} aria-label="Search members" />
                  {hits.length ? (
                    <ul className="glass-strong absolute z-20 mt-1 max-h-64 w-full overflow-auto rounded-xl p-1 shadow-2xl">
                      {hits.map((m) => (
                        <li key={m.id}><button type="button" className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left hover:bg-slate-800" onClick={() => { setPicked({ id: m.id, name: m.name, avatar: m.avatar }); setHits([]); }}>
                          <Avatar src={m.avatar} name={m.name} size={28} /><span className="font-semibold text-white">{m.name}</span><span className="text-xs text-slate-500">{m.top_role || m.username}</span></button></li>
                      ))}
                    </ul>
                  ) : null}
                </div>
              )}
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Label text="Kick limit"><input className={input} type="number" min={0} max={1000} value={kick} onChange={(e) => setKick(Number(e.target.value))} /></Label>
              <Label text="Ban limit"><input className={input} type="number" min={0} max={1000} value={ban} onChange={(e) => setBan(Number(e.target.value))} /></Label>
            </div>
            <fieldset>
              <legend className="mb-2 text-xs font-bold text-slate-400">Limit period</legend>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {data.periods.map((p) => (
                  <label key={p} className={`flex cursor-pointer items-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-bold ${period === p ? 'border-emerald-500 bg-emerald-500/10 text-white' : 'border-slate-700 text-slate-300 hover:border-slate-600'}`}>
                    <input type="radio" name="period" className="accent-orange-500" checked={period === p} onChange={() => setPeriod(p)} /> {PERIOD_LABEL[p]}
                  </label>
                ))}
              </div>
            </fieldset>
            <button type="button" className={`${btnPrimary} w-full`} onClick={save}>Save limit</button>
          </div>
        </Panel>

        <div className="space-y-6">
          <Panel title="Protection">
            <div className="space-y-4">
              <Toggle on={data.enabled} onChange={(v) => settings({ enabled: v }, v ? 'Protection is ON.' : 'Protection is OFF.')} label={data.enabled ? 'Protection is ON' : 'Protection is OFF — limits are not enforced'} />
              <Label text="When someone goes over their limit" hint="Applies to Moderators AND Administrators">
                <select className={input} value={data.limit_action} onChange={(e) => settings({ limit_action: e.target.value }, 'Saved.')}>
                  {data.actions.map((a) => <option key={a} value={a}>{ACTION_LABEL[a] || a}</option>)}
                </select>
              </Label>
              <div className="rounded-xl border border-rose-500/40 bg-rose-950/30 p-3 text-xs text-rose-200">
                <b className="text-rose-100">⚠ Administrator override:</b> Agar koi Admin / Moderator apni Kick ya Ban limit exceed kare, to selected action (Kick / Ban / etc.) <b>un par bhi</b> apply hoga — role se farak nahi padta. Sirf Server Owner + whitelist safe rehte hain.
              </div>
              <div className="grid grid-cols-3 gap-2">
                <Label text="Default kick"><input className={input} type="number" min={0} defaultValue={data.default.kick} id="dk" /></Label>
                <Label text="Default ban"><input className={input} type="number" min={0} defaultValue={data.default.ban} id="db" /></Label>
                <Label text="Period"><select className={input} defaultValue={data.default.period} id="dp">{data.periods.map((p) => <option key={p} value={p}>{PERIOD_LABEL[p]}</option>)}</select></Label>
              </div>
              <button type="button" className={btnGhost} onClick={() => settings({ default: { kick: Number((document.getElementById('dk') as HTMLInputElement).value), ban: Number((document.getElementById('db') as HTMLInputElement).value), period: (document.getElementById('dp') as HTMLSelectElement).value } }, 'Default limits saved.')}>Save default limits</button>
              <p className="flex gap-2 rounded-xl border border-slate-700/70 bg-slate-950/60 p-3 text-xs text-slate-400"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
                Bot sirf un logon ko kick/ban kar sakta hai jinka highest role bot se <b className="text-slate-200">neeche</b> ho. Server Owner + whitelist kabhi limit me nahi aate. Bot commands pe limit pehle block hoti hai; Discord native actions baad me detect hoke upar wala punishment lagta hai.</p>
            </div>
          </Panel>
        </div>
      </div>

      <Panel title={`Limited people (${data.users.length})`}>
        {data.users.length === 0 ? <p className="text-sm text-slate-400">Nobody has a personal limit yet — everyone not whitelisted uses the default ({data.default.kick} kicks / {data.default.ban} bans, {PERIOD_LABEL[data.default.period].toLowerCase()}).</p> : (
          <div className="overflow-x-auto"><table className="w-full text-left text-sm">
            <thead><tr className="text-xs uppercase tracking-wider text-slate-500"><th className="pb-2">Member</th><th className="pb-2">Kicks</th><th className="pb-2">Bans</th><th className="pb-2">Period</th><th className="pb-2 text-right">Actions</th></tr></thead>
            <tbody className="divide-y divide-slate-800/70">
              {data.users.map((r) => (
                <tr key={r.user_id}>
                  <td className="py-3"><span className="flex items-center gap-2.5 font-bold text-white"><Avatar src={r.avatar} name={r.name} size={30} />{r.name}</span></td>
                  <td className="py-3"><Bar used={r.used_kick} max={r.kick} /></td>
                  <td className="py-3"><Bar used={r.used_ban} max={r.ban} /></td>
                  <td className="py-3 text-slate-300">{PERIOD_LABEL[r.period] || r.period}</td>
                  <td className="py-3"><div className="flex justify-end gap-2">
                    <button type="button" className={`${btnGhost} !px-3 !py-1.5 !text-xs`} onClick={() => { setPicked({ id: r.user_id, name: r.name, avatar: r.avatar }); setKick(r.kick); setBan(r.ban); setPeriod(r.period); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Edit</button>
                    <button type="button" className={`${btnGhost} !px-3 !py-1.5 !text-xs`} onClick={async () => { const x = await api('POST', '/api/botadmin/security/reset', { user_id: r.user_id }); say(x.ok, x.ok ? 'Counters reset.' : errText(x.data)); load(); }}>Reset used</button>
                    <button type="button" className={btnDanger} aria-label={`Remove limit of ${r.name}`} onClick={async () => { const x = await api('POST', '/api/botadmin/security/limit/remove', { user_id: r.user_id }); say(x.ok, x.ok ? 'Limit removed.' : errText(x.data)); load(); }}><Trash2 className="h-3.5 w-3.5" /></button>
                  </div></td>
                </tr>
              ))}
            </tbody></table></div>
        )}
      </Panel>
    </div>
  );
};
