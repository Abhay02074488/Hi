export interface Product {
  id: string;
  name: string;
  category: 'ranks' | 'keys' | 'coins' | 'kits' | 'merch' | 'others';
  price: number;
  originalPrice?: number;
  description: string;
  features: string[];
  image: string;
  badge?: string;
  popular?: boolean;
  color?: string;
}

export interface Coupon {
  code: string;
  discountPercent: number;
  maxDiscount?: number;
  minCartValue?: number;
  active: boolean;
}

export interface StoreOrder {
  id: string;
  minecraftUsername: string;
  discordTag?: string;
  items: {
    productId: string;
    productName: string;
    price: number;
    quantity: number;
  }[];
  subtotal: number;
  discountAmount: number;
  finalAmount: number;
  couponCode?: string;
  paymentMethod: 'upi' | 'card' | 'crypto';
  upiRefId?: string;
  status: 'pending_verification' | 'verified' | 'completed' | 'cancelled';
  createdAt: string;
  verifiedAt?: string;
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  rankColor: string;
  skinUsername: string;
  discordTag: string;
  about: string;
  isOwner?: boolean;
}

export interface ServerUpdate {
  id: string;
  version: string;
  title: string;
  date: string;
  category: 'major' | 'feature' | 'fix' | 'event';
  description: string;
  highlights: string[];
}

export interface TopBuyer {
  rank: number;
  username: string;
  totalSpent: number;
  skinUsername: string;
  tier: string;
}

export const STORE_CATEGORIES = [
  { id: 'all', name: 'All Products', icon: 'Sparkles' },
  { id: 'ranks', name: 'Server Ranks', icon: 'Crown' },
  { id: 'keys', name: 'Crate Keys', icon: 'Key' },
  { id: 'coins', name: 'Economy Coins', icon: 'Coins' },
  { id: 'kits', name: 'Battle Kits', icon: 'Shield' },
  { id: 'merch', name: 'Cosmetics & Tags', icon: 'Tag' },
  { id: 'others', name: 'Unbans & Perks', icon: 'Zap' },
] as const;

export const DEFAULT_PRODUCTS: Product[] = [
  // Ranks
  {
    id: 'rank-vip',
    name: 'VIP Rank',
    category: 'ranks',
    price: 99,
    originalPrice: 149,
    badge: 'Popular',
    color: '#22c55e',
    description: 'Entry-level server rank with instant permanent perks on BoxPvP & Lifesteal.',
    image: '/public/wondermc_logo.png',
    features: [
      '[VIP] In-game & Discord Prefix',
      '+2 Extra Homes (/sethome)',
      'Access to /fly in Hub & Protected Spawns',
      'Priority Queue on full servers',
      'Daily VIP Kit with P4 Iron Armor',
      '1x Free Golden Key every week'
    ]
  },
  {
    id: 'rank-mvp',
    name: 'MVP Rank',
    category: 'ranks',
    price: 199,
    originalPrice: 299,
    color: '#3b82f6',
    description: 'Empower your gameplay with advanced kits and exclusive chat colors.',
    image: '/public/wondermc_logo.png',
    features: [
      '[MVP] In-game & Discord Role',
      '+4 Extra Homes (/sethome)',
      'Access to /near and /feed commands',
      'Full access to /craft and /enderchest anywhere',
      'Daily MVP Kit with Diamond Gear',
      '2x Free Golden Keys weekly'
    ]
  },
  {
    id: 'rank-elite',
    name: 'ELITE Rank',
    category: 'ranks',
    price: 349,
    originalPrice: 499,
    badge: 'Best Value',
    popular: true,
    color: '#a855f7',
    description: 'Top-tier warrior rank designed for dominant BoxPvP and Lifesteal leaders.',
    image: '/public/wondermc_logo.png',
    features: [
      '[ELITE] Gradient In-game Prefix',
      '+6 Extra Homes & Instant Teleport delay reduction',
      'Access to /heal (3m cooldown) and /hat',
      'Keep 50% XP upon accidental death',
      'Elite Netherite Kit with Sharpness 5',
      '3x Golden Keys + 1x Wonder Key monthly'
    ]
  },
  {
    id: 'rank-wonder',
    name: 'WONDER Rank',
    category: 'ranks',
    price: 699,
    originalPrice: 999,
    color: '#eab308',
    badge: 'Prestigious',
    description: 'The signature rank of WonderMc Network with ultimate privileges.',
    image: '/public/wondermc_logo.png',
    features: [
      '[WONDER] Animated Gold Gradient Prefix',
      '+10 Homes & Instant Teleports',
      'Custom Join & Leave Announcement Message',
      'Access to /fix hand & /workbench anywhere',
      'Full Netherite God Kit with Protection 4',
      '5x Golden Keys + 3x Wonder Crate Keys'
    ]
  },
  {
    id: 'rank-god',
    name: 'GOD Rank',
    category: 'ranks',
    price: 1199,
    originalPrice: 1499,
    color: '#ef4444',
    badge: 'Supreme Tier',
    description: 'Unrivaled prestige rank with maximum permissions, god kits, and server recognition.',
    image: '/public/wondermc_logo.png',
    features: [
      '★ [GOD] Supreme Holographic Prefix',
      'Unlimited Homes (/sethome)',
      'Access to /fly in Lifesteal Claimed Territory',
      'Instant Auto-Repair (/fix all with cooldown)',
      'Permanent 2x Economy Booster for your Clan',
      'Weekly God Crate Drops & Discord God Role'
    ]
  },

  // Crate Keys
  {
    id: 'key-golden-3',
    name: '3x Golden Keys',
    category: 'keys',
    price: 69,
    originalPrice: 99,
    color: '#f59e0b',
    description: 'Unlock the Golden Mystery Crate at /spawn for legendary weapons and enchant books.',
    image: '/public/wondermc_logo.png',
    features: [
      '3x Golden Crate Keys',
      'Guaranteed Tier 4 or higher loot',
      'Chance for Netherite Ingots and Totems',
      'Instantly added to your virtual key pouch (/keys)'
    ]
  },
  {
    id: 'key-golden-10',
    name: '10x Golden Keys Bundle',
    category: 'keys',
    price: 189,
    originalPrice: 249,
    badge: 'Mega Deal',
    popular: true,
    color: '#f59e0b',
    description: 'Huge crate key package with high chances of dropping Wonder Tier Armor.',
    image: '/public/wondermc_logo.png',
    features: [
      '10x Golden Crate Keys',
      'Bonus 1x Free Rare Key',
      'High chance for God Apples & Sharpness 6 Books',
      'Tradeable with other players in-game'
    ]
  },
  {
    id: 'key-wonder-5',
    name: '5x Wonder Crate Keys',
    category: 'keys',
    price: 299,
    originalPrice: 399,
    color: '#ec4899',
    badge: 'Highest Tier',
    description: 'The rarest crate keys on the server containing exclusive custom items & heart fragments.',
    image: '/public/wondermc_logo.png',
    features: [
      '5x Wonder Master Crate Keys',
      'Guaranteed 3+ Permanent Extra Hearts (Lifesteal)',
      'Chance of receiving Custom Particle Auras',
      'Global server opening announcement ping'
    ]
  },

  // Economy Coins
  {
    id: 'coins-50k',
    name: '50,000 In-Game Coins',
    category: 'coins',
    price: 49,
    color: '#10b981',
    description: 'Kickstart your economy balance for shop trading and clan upgrades.',
    image: '/public/wondermc_logo.png',
    features: [
      '50,000 In-Game Coins delivered via /bal',
      'Use at /shop and Black Market auction house',
      'Deposit in bank to earn daily interest'
    ]
  },
  {
    id: 'coins-200k',
    name: '200,000 Coins Pack',
    category: 'coins',
    price: 149,
    originalPrice: 199,
    popular: true,
    badge: '+25% Extra',
    color: '#10b981',
    description: 'A massive economy boost to purchase top-tier gear from other players.',
    image: '/public/wondermc_logo.png',
    features: [
      '200,000 Coins added instantly',
      'Sufficient to buy elite clan land claims',
      'Bonus 10,000 casino tokens for /gamble'
    ]
  },
  {
    id: 'coins-1m',
    name: '1,000,000 Millionaire Vault',
    category: 'coins',
    price: 499,
    originalPrice: 699,
    color: '#10b981',
    badge: 'Tycoon',
    description: 'Become the richest player on the WonderMc leaderboard immediately.',
    image: '/public/wondermc_logo.png',
    features: [
      '1,000,000 In-Game Currency Balance',
      'Instant [Tycoon] in-game title tag',
      'Top 5 ranking on the global /baltop leaderboard'
    ]
  },

  // Kits
  {
    id: 'kit-gladiator',
    name: 'Gladiator Battle Kit',
    category: 'kits',
    price: 129,
    color: '#f97316',
    description: 'Arm yourself with reinforced diamond armor, fire resistance, and combat potions.',
    image: '/public/wondermc_logo.png',
    features: [
      'Full Protection 4, Unbreaking 3 Diamond Set',
      'Sharpness 5 Diamond Sword with Fire Aspect 2',
      '32x Golden Apples & 5x Strength II Potions',
      'Can be claimed every 24 hours via /kit gladiator'
    ]
  },
  {
    id: 'kit-titan',
    name: 'Titan Netherite Kit',
    category: 'kits',
    price: 249,
    originalPrice: 349,
    popular: true,
    badge: 'PvP Ready',
    color: '#6366f1',
    description: 'Heavy reinforced netherite gear engineered for clan wars and lifesteal raids.',
    image: '/public/wondermc_logo.png',
    features: [
      'Full Protection 4 Netherite Armor Set',
      'Netherite Sword & Axe with Sharpness 5, Knockback 2',
      '64x Golden Apples & 4x Enchanted Golden Apples (God Apples)',
      '16x Ender Pearls + Speed II Potions'
    ]
  },

  // Merch & Cosmetics
  {
    id: 'cosmetic-custom-tag',
    name: 'Custom Chat Tag',
    category: 'merch',
    price: 79,
    color: '#06b6d4',
    description: 'Design your own custom color prefix/tag displayed next to your name in all chats.',
    image: '/public/wondermc_logo.png',
    features: [
      'Choose any 3-12 character custom word',
      'Select any Hex or Minecraft color code',
      'Permanent chat prefix shown across all servers'
    ]
  },
  {
    id: 'cosmetic-wings-aura',
    name: 'Dragon Wings & Halo Particle Aura',
    category: 'merch',
    price: 99,
    color: '#d946ef',
    description: 'Stunning animated particle effects that hover around your player character.',
    image: '/public/wondermc_logo.png',
    features: [
      'Interactive cosmetic particle wings',
      'Golden floating halo above your head',
      'Toggle on or off anytime with /cosmetics'
    ]
  },

  // Others / Unbans
  {
    id: 'perk-unban',
    name: 'Official Unban Pass',
    category: 'others',
    price: 299,
    originalPrice: 499,
    badge: 'Second Chance',
    color: '#64748b',
    description: 'Get your account unbanned and given a fresh clean record on WonderMc.',
    image: '/public/wondermc_logo.png',
    features: [
      'Removal of previous server ban or mute record',
      'Clean start on Java and Bedrock crossplay',
      'Subject to standard server rules upon return'
    ]
  }
];

export const DEFAULT_STAFF_MEMBERS: StaffMember[] = [
  {
    id: 'staff-1',
    name: 'Avihaan_PvP',
    role: 'Server Owner & Lead Dev',
    rankColor: '#ef4444',
    skinUsername: 'Avihaan_PvP',
    discordTag: 'avihaan_owner',
    about: 'Founder of WonderMc Network. Oversees bot systems, plugin development, and server hosting.',
    isOwner: true
  },
  {
    id: 'staff-2',
    name: 'EndermanSlayer_99',
    role: 'Head Administrator',
    rankColor: '#f59e0b',
    skinUsername: 'EndermanSlayer_99',
    discordTag: 'ender_slayer',
    about: 'Manages staff recruitment, community events, anti-cheat enforcement, and player support.'
  },
  {
    id: 'staff-3',
    name: 'ShadowBlade_X',
    role: 'Senior Moderator',
    rankColor: '#3b82f6',
    skinUsername: 'ShadowBlade_X',
    discordTag: 'shadow_blade',
    about: 'Specializes in BoxPvP tournaments, ticket dispute resolution, and in-game fair play.'
  },
  {
    id: 'staff-4',
    name: 'CreeperGuard',
    role: 'Trial Helper',
    rankColor: '#22c55e',
    skinUsername: 'CreeperGuard',
    discordTag: 'creeper_guard',
    about: 'Friendly support assistant guiding new players on Bedrock port setup and economy guides.'
  }
];

export const DEFAULT_SERVER_UPDATES: ServerUpdate[] = [
  {
    id: 'upd-1',
    version: 'v2.4.0',
    title: 'Summer Season 2 & UPI Store Integration',
    date: 'September 2026',
    category: 'major',
    description: 'Major infrastructure upgrade introducing instant UPI payments with auto-verification, new BoxPvP mine tiers, and crossplay voice latency improvements.',
    highlights: [
      'Automated Indian UPI QR code checkout with instant discord transaction notifications',
      'New Wonder God Crate with custom heart-stealing enchantments',
      'Bedrock player skin rendering fix on port 19132',
      'Upgraded server hardware to 64GB DDR5 RAM with 240 FPS tick consistency'
    ]
  },
  {
    id: 'upd-2',
    version: 'v2.3.2',
    title: 'Anti-Cheat v4 & Combat Fixes',
    date: 'August 2026',
    category: 'fix',
    description: 'Refined reach detection and knockback consistency on Lifesteal SMP arena.',
    highlights: [
      'False-flag reduction for mobile Bedrock PvP bridge building',
      'Added /baltop and /rank command improvements with graphical cards',
      'Automated staff application review workflow via Discord bot'
    ]
  }
];

export const DEFAULT_TOP_BUYERS: TopBuyer[] = [
  { rank: 1, username: 'Warrior_King77', totalSpent: 3499, skinUsername: 'Warrior_King77', tier: 'GOD' },
  { rank: 2, username: 'FlameStrike_X', totalSpent: 2199, skinUsername: 'FlameStrike_X', tier: 'WONDER' },
  { rank: 3, username: 'DiamondRush_9', totalSpent: 1499, skinUsername: 'DiamondRush_9', tier: 'ELITE' },
  { rank: 4, username: 'SilentNinja_IN', totalSpent: 999, skinUsername: 'SilentNinja_IN', tier: 'MVP' },
  { rank: 5, username: 'BlockMaster_PvP', totalSpent: 699, skinUsername: 'BlockMaster_PvP', tier: 'VIP' }
];

export const DEFAULT_VOTE_SITES = [
  { id: '1', name: 'TopG Minecraft Servers', url: 'https://topg.org', reward: '1x Vote Key + 5,000 Coins' },
  { id: '2', name: 'Minecraft-MP Leaderboard', url: 'https://minecraft-mp.com', reward: '1x Vote Key + 2x Diamonds' },
  { id: '3', name: 'Planet Minecraft (PMC)', url: 'https://planetminecraft.com', reward: '1x Vote Key + 15m Flight Token' },
  { id: '4', name: 'Minecraft Server List', url: 'https://minecraftservers.org', reward: '1x Vote Key + 5,000 Coins' },
];
