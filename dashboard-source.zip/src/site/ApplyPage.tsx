import React, { useEffect, useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { Link } from '../lib/router';
import { api, errText } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { PageHeader, btnPrimary, card, input } from './ui';

interface Cfg { enabled?: boolean; title?: string; description?: string; questions?: string[] }

export const ApplyPage: React.FC = () => {
  const { user, loading } = useAuth();
  const [cfg, setCfg] = useState<Cfg | null>(null);
  const [answers, setAnswers] = useState<string[]>([]);
  const [discordId, setDiscordId] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  useEffect(() => {
    api('GET', '/api/applications/config').then(({ data }) => {
      const c: Cfg = data?.config || {};
      setCfg(c);
      setAnswers((c.questions || []).map(() => ''));
    });
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    const { ok, data } = await api('POST', '/api/applications/submissions/create', {
      discord_id: discordId, answers: (cfg?.questions || []).map((q, i) => ({ question: q, answer: answers[i] })),
    });
    setBusy(false);
    if (!ok) return setError(errText(data, 'Could not send your application.'));
    setDone(true);
  };

  const questions = cfg?.questions || [];
  return (
    <div>
      <PageHeader emoji="🛡️" title={cfg?.title || 'Staff application'} sub={cfg?.description || 'Tell us about yourself. Staff review every application.'} />
      <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
        {loading || !cfg ? <div className="text-sm text-slate-400">Loading…</div> : done ? (
          <div className={`${card} p-8 text-center`}>
            <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-400" />
            <h2 className="mt-4 font-display text-3xl text-white">Application sent!</h2>
            <p className="mt-2 text-sm text-slate-400">Staff will review it soon. You will be contacted on Discord, so keep your DMs open.</p>
            <Link to="/" className={`${btnPrimary} mt-6`}>Back to home</Link>
          </div>
        ) : cfg.enabled === false ? (
          <div className={`${card} p-8 text-center text-slate-300`}>Staff applications are closed right now. Check Discord for news.</div>
        ) : !user ? (
          <div className={`${card} p-8 text-center`}>
            <h2 className="font-display text-3xl text-white">Sign in to apply</h2>
            <p className="mt-2 text-sm text-slate-400">You need a free account so we can link your application to you.</p>
            <div className="mt-5 flex justify-center gap-3"><Link to="/login" className={btnPrimary}>Log in</Link><Link to="/register" className="inline-flex items-center rounded-xl border border-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-200">Create account</Link></div>
          </div>
        ) : questions.length === 0 ? (
          <div className={`${card} p-8 text-center text-slate-300`}>No questions have been set up yet. Please ask staff on Discord.</div>
        ) : (
          <form onSubmit={submit} className="space-y-5">
            <div className={`${card} p-5`}>
              <label className="block text-sm font-bold text-white">Your Discord user ID <span className="font-normal text-slate-500">(recommended so staff can contact you)</span>
                <input className={`${input} mt-2`} inputMode="numeric" placeholder="e.g. 123456789012345678" value={discordId} onChange={(e) => setDiscordId(e.target.value)} />
              </label>
            </div>
            {questions.map((q, i) => (
              <div key={i} className={`${card} p-5`}>
                <label className="block text-sm font-bold text-white"><span className="mr-2 text-emerald-400">{i + 1}.</span>{q}
                  <textarea className={`${input} mt-2 min-h-[96px]`} maxLength={2000} value={answers[i] || ''} onChange={(e) => setAnswers(answers.map((a, j) => (j === i ? e.target.value : a)))} required />
                </label>
              </div>
            ))}
            {error ? <div role="alert" className="rounded-xl border border-rose-900 bg-rose-950/50 px-4 py-3 text-sm text-rose-300">{error}</div> : null}
            <button type="submit" disabled={busy} className={`${btnPrimary} w-full`}>{busy ? 'Sending…' : 'Submit application'}</button>
            <p className="text-center text-xs text-slate-500">Signed in as {user.email}. You can apply once per cooldown period.</p>
          </form>
        )}
      </div>
    </div>
  );
};
