import React from 'react';

/** Spooky decorations behind the whole site. CSS hides it in the other themes; reduced-motion users get no animation. */
export const HalloweenBackdrop: React.FC = () => (
  <div className="hw-layer" aria-hidden="true">
    <div className="hw-moon" />
    <div className="hw-fog" style={{ top: '22%' }} />
    <div className="hw-fog" style={{ top: '62%', animationDelay: '-9s' }} />
    <svg className="hw-web" viewBox="0 0 200 200" fill="none" stroke="#fff" strokeWidth="1">
      <path d="M0 0 L200 0 M0 0 L170 60 M0 0 L120 120 M0 0 L60 170 M0 0 L0 200" />
      <path d="M40 0 Q35 30 0 40 M80 0 Q65 55 0 80 M120 0 Q95 80 0 120 M160 0 Q125 105 0 160" />
    </svg>
    <div className="hw-spider" />
    {[0, 1, 2, 3].map((i) => (
      <span key={i} className="hw-bat" style={{ top: `${8 + i * 13}%`, animationDuration: `${22 + i * 7}s`, animationDelay: `${-i * 6}s` }}>🦇</span>
    ))}
    <span className="hw-ghost" style={{ top: '38%', left: '6%' }}>👻</span>
    <span className="hw-ghost" style={{ top: '58%', right: '5%', animationDelay: '-4s' }}>👻</span>
    <span className="hw-pumpkin" style={{ left: '2%' }}>🎃</span>
    <span className="hw-pumpkin" style={{ right: '2%', animationDelay: '-1.4s' }}>🎃</span>
  </div>
);
