import React, { useState } from 'react';
import { THEMES, useTheme } from '../lib/theme';

export const ThemeSwitcher: React.FC = () => {
  const [theme, setTheme] = useTheme();
  const [open, setOpen] = useState(false);
  const current = THEMES.find((t) => t.id === theme) || THEMES[0];
  return (
    <div className="relative">
      <button type="button" onClick={() => setOpen(!open)} className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-700/80 bg-slate-900/70 hover:bg-slate-800" aria-label="Change colour theme" title="Change colour theme">
        <span className="h-4 w-4 rounded-full ring-2 ring-white/20" style={{ background: current.swatch }} />
      </button>
      {open ? (
        <div className="glass-strong absolute right-0 mt-2 w-44 rounded-xl p-2 shadow-2xl" onClick={() => setOpen(false)}>
          <div className="px-2 pb-1 pt-1 text-[10px] font-bold uppercase tracking-wider text-slate-500">Theme</div>
          {THEMES.map((t) => (
            <button key={t.id} type="button" onClick={() => setTheme(t.id)} className={`flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left text-sm font-semibold hover:bg-slate-800 ${t.id === theme ? 'text-white' : 'text-slate-300'}`}>
              <span className="h-4 w-4 rounded-full" style={{ background: t.swatch }} /> {t.label}{t.id === theme ? <span className="ml-auto text-emerald-400">✓</span> : null}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
};
