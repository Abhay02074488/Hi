import React, { useState } from 'react';
import { Lock, ShieldCheck } from 'lucide-react';
import { Link, navigate } from '../lib/router';
import { SITE } from '../lib/site';
import { useAuth } from '../context/AuthContext';
import { btnPrimary, card, input } from './ui';

type Mode = 'login' | 'register';

export const AuthPage: React.FC<{ mode: Mode }> = ({ mode }) => {
  const { login, register, setup, setupRequired, user } = useAuth();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [key, setKey] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  if (user) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <div className={`${card} p-8`}>
          <ShieldCheck className="mx-auto h-10 w-10 text-emerald-400" />
          <h1 className="mt-4 text-xl font-black text-white">You're signed in</h1>
          <p className="mt-1 text-sm text-slate-400">{user.email}</p>
          <div className="mt-6 flex flex-col gap-2">
            <Link to="/account" className={btnPrimary}>My account</Link>
            {user.isStaff ? <Link to="/admin" className={btnPrimary}>Open admin panel</Link> : null}
          </div>
        </div>
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    let err: string | null;
    if (setupRequired) err = await setup(key, email, name, password);
    else if (mode === 'register') err = await register(email, name, password);
    else err = await login(email, password);
    setBusy(false);
    if (err) return setError(err);
    navigate(setupRequired ? '/admin' : '/account');
  };

  const title = setupRequired ? 'First-time setup' : mode === 'register' ? 'Create your account' : 'Welcome back';
  const sub = setupRequired
    ? 'Create the OWNER account. You need the STAFF_MASTER_KEY from your server .env file.'
    : mode === 'register' ? `Join the ${SITE.name} community website.` : 'Sign in with your email and password.';

  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <div className={`${card} p-7`}>
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-300"><Lock className="h-6 w-6" /></div>
          <h1 className="text-2xl font-black text-white">{title}</h1>
          <p className="mt-1 text-sm text-slate-400">{sub}</p>
        </div>

        <form onSubmit={submit} className="space-y-3">
          {setupRequired ? <input className={input} type="password" placeholder="Setup key (STAFF_MASTER_KEY)" value={key} onChange={(e) => setKey(e.target.value)} autoComplete="off" required /> : null}
          {(setupRequired || mode === 'register') ? <input className={input} placeholder="Display name" value={name} onChange={(e) => setName(e.target.value)} maxLength={40} autoComplete="nickname" /> : null}
          <input className={input} type="email" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required />
          <div className="relative">
            <input className={`${input} pr-16`} type={show ? 'text' : 'password'} placeholder={mode === 'login' && !setupRequired ? 'Password' : 'Password (8+ characters, with a number)'} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === 'login' && !setupRequired ? 'current-password' : 'new-password'} required />
            <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 hover:text-white">{show ? 'Hide' : 'Show'}</button>
          </div>
          {error ? <div role="alert" className="rounded-xl border border-rose-900 bg-rose-950/50 px-3 py-2 text-sm text-rose-300">{error}</div> : null}
          <button type="submit" disabled={busy} className={`${btnPrimary} w-full`}>{busy ? 'Please wait…' : setupRequired ? 'Create owner account' : mode === 'register' ? 'Create account' : 'Sign in'}</button>
        </form>

        {!setupRequired ? (
          <p className="mt-5 text-center text-sm text-slate-400">
            {mode === 'login' ? <>New here? <Link to="/register" className="font-bold text-emerald-400 hover:text-emerald-300">Create an account</Link></> : <>Already have an account? <Link to="/login" className="font-bold text-emerald-400 hover:text-emerald-300">Sign in</Link></>}
          </p>
        ) : null}
        {mode === 'register' && !setupRequired ? <p className="mt-3 text-center text-xs text-slate-500">New accounts are normal player accounts. Staff access is given by the server owner.</p> : null}
      </div>
    </div>
  );
};
