import React, { useState } from 'react';
import { Menu, X, ShoppingCart, Shield, Crown } from 'lucide-react';
import { Link, navigate } from '../lib/router';
import { SITE } from '../lib/site';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { CopyButton } from './ui';
import { ThemeSwitcher } from './ThemeSwitcher';

const LINKS: Array<[string, string]> = [
  ['/', 'Home'], ['/status', 'Status'], ['/store', 'Store'], ['/leaderboard', 'Leaderboard'],
  ['/games', 'Games'], ['/help', 'Rules & Help'], ['/staff', 'Staff'], ['/updates', 'Updates'],
];

export const SiteNav: React.FC<{ route: string }> = ({ route }) => {
  const { user, logout, hasRole } = useAuth();
  const cart = useCart() as any;
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const count = Array.isArray(cart.items) ? cart.items.reduce((n: number, i: any) => n + (i.quantity || 1), 0) : 0;
  const active = (p: string) => (p === '/' ? route === '/' : route.startsWith(p));

  return (
    <header className="glass-strong sticky top-0 z-40 border-x-0 border-t-0">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-2 text-lg font-black tracking-tight text-white">
          <span className="text-2xl">🎃</span> <span className="font-display text-2xl">{SITE.name}</span>
        </Link>

        <nav className="ml-4 hidden items-center gap-1 lg:flex">
          {LINKS.map(([to, label]) => (
            <Link key={to} to={to} className={`rounded-lg px-3 py-2 text-sm font-semibold transition ${active(to) ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'}`}>{label}</Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <span className="hidden items-center gap-1 rounded-xl border border-slate-700 bg-slate-900 py-1 pl-3 pr-1 text-xs font-mono text-emerald-300 md:flex">
            {SITE.ip} <CopyButton text={SITE.ip} className="rounded-lg p-1.5 text-slate-300 hover:bg-slate-700" />
          </span>
          <a href={SITE.discord} target="_blank" rel="noreferrer" className="hidden rounded-xl bg-indigo-500 px-3 py-2 text-xs font-bold text-white transition hover:bg-indigo-400 sm:inline-flex">Discord</a>
          <ThemeSwitcher />

          <button type="button" onClick={() => cart.setIsCartOpen && cart.setIsCartOpen(true)} className="relative rounded-xl border border-slate-700 bg-slate-900 p-2 text-slate-200 hover:bg-slate-800" aria-label="Open cart">
            <ShoppingCart className="h-4 w-4" />
            {count > 0 ? <span className="absolute -right-1.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-emerald-500 px-1 text-[10px] font-black text-slate-950">{count}</span> : null}
          </button>

          {user ? (
            <div className="relative">
              <button type="button" onClick={() => setMenu(!menu)} className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-bold text-white hover:bg-slate-800">
                {user.isOwner ? <Crown className="h-3.5 w-3.5 text-amber-400" /> : user.isStaff ? <Shield className="h-3.5 w-3.5 text-emerald-400" /> : null}
                <span className="max-w-[7rem] truncate">{user.name}</span>
              </button>
              {menu ? (
                <div className="absolute right-0 mt-2 w-52 overflow-hidden rounded-xl border border-slate-700 bg-slate-900 shadow-2xl" onClick={() => setMenu(false)}>
                  <div className="border-b border-slate-800 px-4 py-3 text-xs text-slate-400"><div className="truncate font-semibold text-slate-200">{user.email}</div><div className="mt-0.5 uppercase tracking-wide text-emerald-400">{user.role}</div></div>
                  <Link to="/account" className="block px-4 py-2.5 text-sm text-slate-200 hover:bg-slate-800">My account</Link>
                  {hasRole('staff') ? <Link to="/admin" className="block px-4 py-2.5 text-sm text-slate-200 hover:bg-slate-800">Admin panel</Link> : null}
                  <button type="button" onClick={async () => { await logout(); navigate('/'); }} className="block w-full px-4 py-2.5 text-left text-sm text-rose-300 hover:bg-slate-800">Sign out</button>
                </div>
              ) : null}
            </div>
          ) : (
            <>
              <Link to="/login" className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-bold text-white hover:bg-slate-800">Log in</Link>
              <Link to="/register" className="hidden rounded-xl bg-emerald-500 px-3 py-2 text-xs font-black text-slate-950 hover:bg-emerald-400 sm:inline-flex">Sign up</Link>
            </>
          )}

          <button type="button" onClick={() => setOpen(!open)} className="rounded-xl border border-slate-700 bg-slate-900 p-2 text-slate-200 lg:hidden" aria-label="Menu">
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {open ? (
        <nav className="border-t border-slate-800 bg-slate-950 px-4 py-3 lg:hidden">
          <div className="grid grid-cols-2 gap-2">
            {LINKS.map(([to, label]) => (
              <Link key={to} to={to} onClick={() => setOpen(false)} className={`rounded-lg px-3 py-2.5 text-sm font-semibold ${active(to) ? 'bg-slate-800 text-white' : 'bg-slate-900 text-slate-300'}`}>{label}</Link>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs">
            <span className="font-mono text-emerald-300">{SITE.ip}</span>
            <CopyButton text={SITE.ip} label="Copy IP" className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-bold text-white" />
          </div>
          <a href={SITE.discord} target="_blank" rel="noreferrer" className="mt-2 block rounded-xl bg-indigo-500 px-3 py-2.5 text-center text-sm font-bold text-white">Join our Discord</a>
        </nav>
      ) : null}
    </header>
  );
};
