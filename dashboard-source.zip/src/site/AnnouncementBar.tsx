import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';

export const AnnouncementBar: React.FC = () => {
  const [a, setA] = useState<{ enabled: boolean; text: string; link: string } | null>(null);
  const [closed, setClosed] = useState(false);
  useEffect(() => {
    fetch('/api/site/content').then((r) => r.json()).then((d) => { if (d?.content?.announcement) setA(d.content.announcement); }).catch(() => {});
  }, []);
  if (!a || !a.enabled || !a.text || closed) return null;
  const body = <span className="font-semibold">{a.text}</span>;
  return (
    <div className="relative z-30 flex items-center justify-center gap-3 bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 px-4 py-2 text-center text-sm text-slate-950">
      🎃 {a.link ? <a href={a.link} target="_blank" rel="noreferrer" className="underline decoration-dotted underline-offset-2">{body}</a> : body}
      <button type="button" onClick={() => setClosed(true)} className="rounded p-0.5 hover:bg-black/10" aria-label="Close announcement"><X className="h-4 w-4" /></button>
    </div>
  );
};
