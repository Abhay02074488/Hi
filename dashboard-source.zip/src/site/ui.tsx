import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';

export const card = 'glass rounded-2xl';
export const input = 'w-full rounded-xl border border-slate-700/80 bg-slate-950/80 px-3.5 py-2.5 text-sm text-white placeholder-slate-500 outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/25';
export const btnPrimary = 'inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-emerald-500 px-4 py-2.5 text-sm font-extrabold text-slate-950 shadow-lg shadow-emerald-500/20 transition hover:brightness-110 active:scale-[.98] disabled:cursor-not-allowed disabled:opacity-50';
export const btnGhost = 'inline-flex items-center justify-center gap-2 rounded-xl border border-slate-700/80 bg-slate-800/50 px-4 py-2.5 text-sm font-semibold text-slate-200 transition hover:border-slate-600 hover:bg-slate-700/60 active:scale-[.98] disabled:opacity-50';
export const btnDanger = 'inline-flex items-center justify-center gap-2 rounded-xl border border-rose-800/80 bg-rose-950/50 px-3 py-2 text-xs font-bold text-rose-300 transition hover:bg-rose-900/60 disabled:opacity-50';

export const CopyButton: React.FC<{ text: string; label?: string; className?: string }> = ({ text, label, className }) => {
  const [done, setDone] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); }
    catch {
      const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch { /* ignore */ }
      document.body.removeChild(ta);
    }
    setDone(true);
    setTimeout(() => setDone(false), 1800);
  };
  return (
    <button type="button" onClick={copy} className={className || btnGhost} aria-label={`Copy ${text}`}>
      {done ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
      {label !== undefined ? (done ? 'Copied!' : label) : null}
    </button>
  );
};

export const StatusPill: React.FC<{ online: boolean; loading?: boolean; failed?: boolean; players?: string }> = ({ online, loading, failed, players }) => {
  if (loading) return <span className="inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-800/70 px-3 py-1 text-xs font-semibold text-slate-300"><span className="h-2 w-2 animate-pulse rounded-full bg-slate-500" /> Checking server…</span>;
  if (failed) return <span className="inline-flex items-center gap-2 rounded-full border border-amber-700/70 bg-amber-950/50 px-3 py-1 text-xs font-semibold text-amber-300">Status unavailable</span>;
  return online ? (
    <span className="inline-flex items-center gap-2 rounded-full border border-emerald-600/60 bg-emerald-950/60 px-3 py-1 text-xs font-extrabold tracking-wide text-emerald-300">
      <span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" /><span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" /></span>
      ONLINE{players ? ` • ${players}` : ''}
    </span>
  ) : (
    <span className="inline-flex items-center gap-2 rounded-full border border-rose-800/70 bg-rose-950/60 px-3 py-1 text-xs font-extrabold tracking-wide text-rose-300"><span className="h-2 w-2 rounded-full bg-rose-400" /> OFFLINE</span>
  );
};

export const Section: React.FC<{ title: string; sub?: string; action?: React.ReactNode; children: React.ReactNode }> = ({ title, sub, action, children }) => (
  <section className="mx-auto w-full max-w-6xl px-4 py-12 sm:px-6">
    <div className="mb-7 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">{title}</h2>
        {sub ? <p className="mt-1.5 max-w-2xl text-sm text-slate-400">{sub}</p> : null}
      </div>
      {action}
    </div>
    {children}
  </section>
);

export const PageHeader: React.FC<{ title: string; sub?: string; emoji?: string }> = ({ title, sub, emoji }) => (
  <div className="relative overflow-hidden border-b border-slate-800/70">
    <div className="grid-bg pointer-events-none absolute inset-0" />
    <div className="relative mx-auto max-w-6xl px-4 py-12 sm:px-6">
      {emoji ? <div className="mb-3 text-4xl">{emoji}</div> : null}
      <h1 className="font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">{title}</h1>
      {sub ? <p className="mt-2 max-w-2xl text-slate-400">{sub}</p> : null}
    </div>
  </div>
);

export const Skeleton: React.FC<{ className?: string }> = ({ className }) => <div className={`skeleton ${className || 'h-6 w-full'}`} />;
