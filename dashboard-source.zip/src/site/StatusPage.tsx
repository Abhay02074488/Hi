import React from 'react';
import { SITE } from '../lib/site';
import { useMcStatus } from '../lib/useMcStatus';
import { CopyButton, Section, StatusPill, card } from './ui';

export const StatusPage: React.FC = () => {
  const mc = useMcStatus(10000);
  const players = mc.online ? `${mc.players.online}/${mc.players.max} players` : undefined;
  const when = mc.checkedAt ? new Date(mc.checkedAt).toLocaleTimeString() : '—';

  return (
    <Section title="Server status" sub={`Live data from ${SITE.ip}. Refreshes every 10 seconds.`}>
      <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <div className={`${card} p-6`}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <StatusPill online={mc.online} loading={mc.loading} failed={mc.failed} players={players} />
            <span className="text-xs text-slate-500">Last checked {when}{mc.source !== 'none' ? ` • via ${mc.source}` : ''}</span>
          </div>

          {mc.failed ? (
            <p className="mt-5 rounded-xl border border-amber-800 bg-amber-950/40 p-4 text-sm text-amber-200">The website could not reach its own backend, so the server status is unknown right now. Try refreshing in a moment.</p>
          ) : null}
          {!mc.loading && !mc.failed && !mc.online ? (
            <div className="mt-5 rounded-xl border border-rose-900 bg-rose-950/40 p-4 text-sm text-rose-200">
              <div className="font-bold">The server isn't answering right now.</div>
              <div className="mt-1 text-rose-300/80">{mc.error ? `Reason: ${mc.error}.` : ''} It may be restarting — check our Discord for announcements.</div>
            </div>
          ) : null}

          {mc.online ? (
            <>
              <div className="mt-5 rounded-xl border border-slate-800 bg-slate-950 px-4 py-4 text-center font-mono text-sm text-slate-200">
                {mc.motdLines.length ? mc.motdLines.map((l, i) => <div key={i}>{l}</div>) : <span className="text-slate-500">No message of the day</span>}
              </div>
              <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[['Players', `${mc.players.online}/${mc.players.max}`], ['Ping', mc.ping !== null ? `${mc.ping} ms` : '—'], ['Version', mc.version || '—'], ['Status', 'Online']].map(([k, v]) => (
                  <div key={k} className="rounded-xl bg-slate-950 p-4 text-center"><div className="truncate text-xl font-black text-white">{v}</div><div className="mt-1 text-xs text-slate-500">{k}</div></div>
                ))}
              </div>
              {mc.players.sample.length ? (
                <div className="mt-5">
                  <div className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">Players online (sample)</div>
                  <div className="flex flex-wrap gap-2">{mc.players.sample.map((p) => <span key={p} className="rounded-lg bg-slate-800 px-2.5 py-1 text-xs font-semibold text-slate-200">{p}</span>)}</div>
                </div>
              ) : null}
            </>
          ) : null}
        </div>

        <div className={`${card} p-6`}>
          <h3 className="font-black text-white">How to connect</h3>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex items-center justify-between gap-2 rounded-xl border border-slate-800 bg-slate-950 p-3"><div><div className="text-[10px] font-bold uppercase text-slate-500">Java Edition</div><div className="font-mono text-emerald-300">{SITE.ip}</div></div><CopyButton text={SITE.ip} label="Copy" /></div>
            <div className="flex items-center justify-between gap-2 rounded-xl border border-slate-800 bg-slate-950 p-3"><div><div className="text-[10px] font-bold uppercase text-slate-500">Bedrock Edition</div><div className="font-mono text-cyan-300">{SITE.ip}</div><div className="font-mono text-xs text-slate-400">Port {SITE.bedrockPort}</div></div><CopyButton text={SITE.ip} label="Copy" /></div>
          </div>
          <ol className="mt-5 list-decimal space-y-1.5 pl-5 text-sm text-slate-400">
            <li>Open Minecraft → Multiplayer / Servers.</li>
            <li>Add Server and paste the address above.</li>
            <li>On Bedrock also enter port {SITE.bedrockPort}.</li>
            <li>Join, then type <code className="rounded bg-slate-800 px-1 text-slate-200">/link</code> to connect with Discord.</li>
          </ol>
          <a href={SITE.discord} target="_blank" rel="noreferrer" className="mt-5 block rounded-xl bg-indigo-500 px-4 py-2.5 text-center text-sm font-bold text-white hover:bg-indigo-400">Need help? Join Discord</a>
        </div>
      </div>
    </Section>
  );
};
