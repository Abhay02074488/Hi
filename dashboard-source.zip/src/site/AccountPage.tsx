import React, { useState } from 'react';
import { Crown, Shield } from 'lucide-react';
import { Link, navigate } from '../lib/router';
import { postJson, setToken } from '../lib/auth';
import { SITE } from '../lib/site';
import { useAuth } from '../context/AuthContext';
import { btnGhost, btnPrimary, card, input } from './ui';

const ROLE_TEXT: Record<string, string> = {
  owner: 'Full control, including who can access the admin panel.',
  admin: 'Full admin panel except managing access.',
  staff: 'Applications, transcripts and support tools.',
  user: 'Player account — store, leaderboards and your profile.',
};

export const AccountPage: React.FC = () => {
  const { user, logout, refresh } = useAuth();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <div className={`${card} p-8`}>
          <h1 className="text-xl font-black text-white">Please sign in</h1>
          <p className="mt-1 text-sm text-slate-400">You need an account to see this page.</p>
          <Link to="/login" className={`${btnPrimary} mt-5`}>Sign in</Link>
        </div>
      </div>
    );
  }

  const change = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setMsg(null);
    const { ok, data } = await postJson('/api/auth/password', { current, next });
    setBusy(false);
    if (!ok) return setMsg({ ok: false, text: data?.error || 'Could not change the password.' });
    if (data?.token) setToken(data.token);
    await refresh();
    setCurrent(''); setNext('');
    setMsg({ ok: true, text: 'Password changed. Other devices were signed out.' });
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <div className={`${card} p-6`}>
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/10 text-2xl font-black text-emerald-300">{user.name.slice(0, 1).toUpperCase()}</div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-2xl font-black text-white">{user.name}</h1>
            <div className="truncate text-sm text-slate-400">{user.email}</div>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-700 bg-slate-800 px-3 py-1 text-xs font-black uppercase tracking-wider text-emerald-300">
            {user.isOwner ? <Crown className="h-3.5 w-3.5 text-amber-400" /> : user.isStaff ? <Shield className="h-3.5 w-3.5" /> : null}{user.role}
          </span>
        </div>
        <p className="mt-4 text-sm text-slate-400">{ROLE_TEXT[user.role]}</p>
        <div className="mt-5 flex flex-wrap gap-2">
          {user.isStaff ? <Link to="/admin" className={btnPrimary}>Open admin panel</Link> : null}
          <Link to="/store" className={btnGhost}>Store</Link>
          <a href={SITE.discord} target="_blank" rel="noreferrer" className={btnGhost}>Discord</a>
          <button type="button" className={btnGhost} onClick={async () => { await logout(); navigate('/'); }}>Sign out</button>
        </div>
        {!user.isStaff ? <p className="mt-4 rounded-xl border border-slate-800 bg-slate-950 p-3 text-xs text-slate-400">Want staff access? Apply from the <Link to="/staff" className="font-bold text-emerald-400">Staff page</Link>. The owner can then grant it to your email.</p> : null}
      </div>

      <form onSubmit={change} className={`${card} mt-6 p-6`}>
        <h2 className="text-lg font-black text-white">Change password</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <input className={input} type="password" placeholder="Current password" value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" required />
          <input className={input} type="password" placeholder="New password (8+, with a number)" value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" required />
        </div>
        {msg ? <div role="status" className={`mt-3 rounded-xl border px-3 py-2 text-sm ${msg.ok ? 'border-emerald-900 bg-emerald-950/50 text-emerald-300' : 'border-rose-900 bg-rose-950/50 text-rose-300'}`}>{msg.text}</div> : null}
        <button type="submit" disabled={busy} className={`${btnPrimary} mt-4`}>{busy ? 'Saving…' : 'Update password'}</button>
      </form>
    </div>
  );
};
