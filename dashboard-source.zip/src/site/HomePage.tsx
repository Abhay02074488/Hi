import React, { useEffect, useState } from 'react';
import { ArrowRight, Crown, Key, Shield, Trophy, MessageSquare, Zap, Flame, Coins, Tag } from 'lucide-react';
import { Link } from '../lib/router';
import { SITE } from '../lib/site';
import { useMcStatus } from '../lib/useMcStatus';
import { useAuth } from '../context/AuthContext';
import { useStoreConfig } from '../context/StoreConfigContext';
import { DEFAULT_PRODUCTS } from '../data/storeData';
import { CopyButton, Section, StatusPill, btnGhost, btnPrimary, card } from './ui';

const FEATURES = [
  { icon: Crown, title: 'Ranks & Perks', text: 'Support the server and unlock ranks, kits and cosmetics.', to: '/store' },
  { icon: Key, title: 'Crate Keys & Coins', text: 'Grab keys and in-game coins right after checkout.', to: '/store' },
  { icon: Trophy, title: 'Leaderboards', text: 'Climb the levels and get your name on the board.', to: '/leaderboard' },
  { icon: Shield, title: 'Join the Staff Team', text: 'Apply on the website — staff review every application.', to: '/apply' },
  { icon: MessageSquare, title: 'Help & Rules', text: 'Server rules, answers to common questions and support.', to: '/help' },
  { icon: Zap, title: 'Discord ⇄ Minecraft', text: 'Chat and events are synced between the game and Discord.', to: '/bot' },
];
const MODE_ICON: Record<string, string> = { boxpvp: '⚔️', lifesteal: '❤️‍🔥', practice: '🎯' };
const CAT_ICON: Record<string, React.ComponentType<{ className?: string }>> = { ranks: Crown, keys: Key, coins: Coins, kits: Shield, merch: Tag, others: Zap };

interface Player { id: string; username: string; level: number; xp: number; role?: string }
interface Faq { q: string; a: string }

export const HomePage: React.FC = () => {
  const mc = useMcStatus();
  const { user } = useAuth();
  const { config } = useStoreConfig() as any;
  const [players, setPlayers] = useState<Player[] | null>(null);
  const [faq, setFaq] = useState<Faq[]>([]);
  const sym = config?.currencySymbol || '₹';
  const popular = DEFAULT_PRODUCTS.filter((p) => p.popular).slice(0, 4);
  const onlineText = mc.online ? `${mc.players.online}/${mc.players.max} players` : undefined;

  useEffect(() => {
    fetch('/api/levels/leaderboard').then((r) => r.json()).then((d) => {
      if (Array.isArray(d?.leaderboard)) setPlayers(d.leaderboard.slice(0, 5));
      else setPlayers([]);
    }).catch(() => setPlayers([]));
    fetch('/api/site/content').then((r) => r.json()).then((d) => { if (Array.isArray(d?.content?.faq)) setFaq(d.content.faq.slice(0, 4)); }).catch(() => {});
  }, []);

  return (
    <div>
      <div className="relative overflow-hidden border-b border-slate-800/70">
        <div className="grid-bg pointer-events-none absolute inset-0" />
        <div className="relative mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 md:grid-cols-[1.15fr_1fr] md:py-24">
          <div>
            <StatusPill online={mc.online} loading={mc.loading} failed={mc.failed} players={onlineText} />
            <h1 className="hw-title mt-5 font-display text-5xl leading-[1.05] text-white sm:text-7xl">
              Welcome to <span className="text-gradient">{SITE.name}</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-slate-300">{SITE.tagline} A competitive Minecraft network with BoxPvP, Lifesteal and Practice — built by players, for players.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href={SITE.discord} target="_blank" rel="noreferrer" className={btnPrimary}>Join our Discord <ArrowRight className="h-4 w-4" /></a>
              <Link to="/store" className={btnGhost}>Visit the store</Link>
              {!user ? <Link to="/register" className={btnGhost}>Create an account</Link> : null}
            </div>
          </div>

          <div className={`${card} glow p-5`}>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Server address</div>
            <div className="mt-3 flex items-center justify-between gap-3 rounded-xl border border-slate-700 bg-slate-950/80 px-4 py-3">
              <div><div className="text-[10px] font-bold uppercase text-slate-500">Java Edition</div><div className="font-mono text-lg font-bold text-emerald-300">{SITE.ip}</div></div>
              <CopyButton text={SITE.ip} label="Copy" />
            </div>
            <div className="mt-3 flex items-center justify-between gap-3 rounded-xl border border-slate-700 bg-slate-950/80 px-4 py-3">
              <div><div className="text-[10px] font-bold uppercase text-slate-500">Bedrock Edition</div><div className="font-mono text-sm font-bold text-indigo-300">{SITE.ip} <span className="text-slate-500">port</span> {SITE.bedrockPort}</div></div>
              <CopyButton text={`${SITE.ip}:${SITE.bedrockPort}`} label="Copy" />
            </div>
            {mc.online ? (
              <div className="mt-4">
                <div className="mb-1 flex justify-between text-[11px] font-bold text-slate-400"><span>Players</span><span>{mc.players.online}/{mc.players.max}</span></div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-800"><div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-indigo-400" style={{ width: `${mc.players.max ? Math.min(100, (mc.players.online / mc.players.max) * 100) : 0}%` }} /></div>
              </div>
            ) : null}
            <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="rounded-xl bg-slate-950/70 p-3"><div className="text-lg font-black text-white">{mc.online ? mc.players.online : '–'}</div><div className="text-slate-500">Online</div></div>
              <div className="rounded-xl bg-slate-950/70 p-3"><div className="text-lg font-black text-white">{mc.ping !== null ? `${mc.ping}ms` : '–'}</div><div className="text-slate-500">Ping</div></div>
              <div className="rounded-xl bg-slate-950/70 p-3"><div className="truncate text-lg font-black text-white">{mc.version ? mc.version.replace(/^Paper\s*/i, '') : '–'}</div><div className="text-slate-500">Version</div></div>
            </div>
            {mc.motdLines.length ? <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-center font-mono text-xs text-slate-300">{mc.motdLines.map((l, i) => <div key={i}>{l}</div>)}</div> : null}
            <Link to="/status" className="mt-4 block text-center text-xs font-semibold text-emerald-400 hover:text-emerald-300">Full status & how to join →</Link>
          </div>
        </div>
      </div>

      {mc.gamemodes.length ? (
        <Section title="Game modes" sub="Pick a fight, a hunt or a grind.">
          <div className="grid gap-4 sm:grid-cols-3">
            {mc.gamemodes.map((g) => (
              <div key={g.name} className={`${card} card-hover p-6`}>
                <div className="mb-4 flex items-center justify-between"><span className="text-4xl">{MODE_ICON[g.name.toLowerCase()] || '⛏️'}</span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-slate-800 px-2.5 py-1 text-[10px] font-black tracking-wider text-emerald-300"><Flame className="h-3 w-3" /> {g.badge}</span></div>
                <h3 className="font-display text-2xl text-white">{g.name}</h3>
                <p className="mt-1 text-sm text-slate-400">{g.desc}</p>
              </div>
            ))}
          </div>
        </Section>
      ) : null}

      <Section title="Popular in the store" sub="Support the server and get rewarded." action={<Link to="/store" className="text-sm font-bold text-emerald-400 hover:text-emerald-300">See everything →</Link>}>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {popular.map((p) => {
            const Icon = CAT_ICON[p.category] || Zap;
            return (
              <Link key={p.id} to="/store" className={`${card} card-hover group p-5`}>
                <div className="mb-4 inline-flex rounded-2xl bg-emerald-500/10 p-3 text-emerald-300"><Icon className="h-6 w-6" /></div>
                <div className="font-bold text-white">{p.name}</div>
                <p className="mt-1 line-clamp-2 text-xs text-slate-400">{p.description}</p>
                <div className="mt-4 flex items-end gap-2"><span className="text-2xl font-black text-white">{sym}{p.price}</span>
                  {p.originalPrice ? <span className="text-xs text-slate-500 line-through">{sym}{p.originalPrice}</span> : null}</div>
              </Link>
            );
          })}
        </div>
      </Section>

      <Section title="Top players" sub="The most active members of our community." action={<Link to="/leaderboard" className="text-sm font-bold text-emerald-400 hover:text-emerald-300">Full leaderboard →</Link>}>
        <div className={`${card} overflow-hidden`}>
          {players === null ? <div className="p-6 text-sm text-slate-400">Loading…</div> : players.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-400">No one is on the board yet — chat and play to earn XP!</div>
          ) : (
            <ol className="divide-y divide-slate-800/80">
              {players.map((p, i) => (
                <li key={p.id} className="flex items-center gap-4 px-5 py-3.5">
                  <span className={`flex h-9 w-9 items-center justify-center rounded-xl text-sm font-black ${i === 0 ? 'bg-amber-400 text-slate-950' : i === 1 ? 'bg-slate-300 text-slate-950' : i === 2 ? 'bg-orange-400 text-slate-950' : 'bg-slate-800 text-slate-300'}`}>{i + 1}</span>
                  <div className="min-w-0 flex-1"><div className="truncate font-bold text-white">{p.username}</div><div className="text-xs text-slate-500">{p.role || 'Member'}</div></div>
                  <div className="text-right"><div className="font-black text-emerald-300">Level {p.level}</div><div className="text-xs text-slate-500">{Number(p.xp || 0).toLocaleString()} XP</div></div>
                </li>
              ))}
            </ol>
          )}
        </div>
      </Section>

      <Section title="Everything in one place" sub="The website, the Discord bot and the game are connected.">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map(({ icon: Icon, title, text, to }) => (
            <Link key={title} to={to} className={`${card} card-hover group p-5`}>
              <div className="mb-3 inline-flex rounded-xl bg-emerald-500/10 p-2.5 text-emerald-300"><Icon className="h-5 w-5" /></div>
              <h3 className="font-bold text-white">{title}</h3>
              <p className="mt-1 text-sm text-slate-400">{text}</p>
              <span className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-emerald-400 group-hover:gap-2">Open <ArrowRight className="h-3 w-3" /></span>
            </Link>
          ))}
        </div>
      </Section>

      <Section title="How to join in 3 steps">
        <ol className="grid gap-4 sm:grid-cols-3">
          {[['1', 'Open Minecraft', 'Java or Bedrock — any recent version.'], ['2', 'Add the server', `Use the address ${SITE.ip} (Bedrock port ${SITE.bedrockPort}).`], ['3', 'Link your account', 'Type /link in game, then run /link with the code in our Discord.']].map(([n, t, d]) => (
            <li key={n} className={`${card} p-5`}>
              <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 font-display text-xl text-slate-950">{n}</div>
              <h3 className="font-bold text-white">{t}</h3><p className="mt-1 text-sm text-slate-400">{d}</p>
            </li>
          ))}
        </ol>
      </Section>

      {faq.length ? (
        <Section title="Quick answers" action={<Link to="/help" className="text-sm font-bold text-emerald-400 hover:text-emerald-300">All rules & FAQ →</Link>}>
          <div className="grid gap-4 md:grid-cols-2">
            {faq.map((f) => <div key={f.q} className={`${card} p-5`}><div className="font-bold text-white">{f.q}</div><p className="mt-1.5 text-sm text-slate-400">{f.a}</p></div>)}
          </div>
        </Section>
      ) : null}

      <div className="mx-auto max-w-6xl px-4 pb-6 sm:px-6">
        <div className={`${card} glow flex flex-wrap items-center justify-between gap-4 p-7`}>
          <div><div className="font-display text-3xl text-white">Ready to join the fun?</div><p className="mt-1 text-sm text-slate-400">Jump into Discord, grab your rank and meet the community.</p></div>
          <a href={SITE.discord} target="_blank" rel="noreferrer" className={btnPrimary}>Join Discord <ArrowRight className="h-4 w-4" /></a>
        </div>
      </div>
    </div>
  );
};
