import React from 'react';
import { Link } from '../lib/router';
import { SITE } from '../lib/site';
import { CopyButton } from './ui';

export const SiteFooter: React.FC = () => (
  <footer className="relative z-10 mt-16 border-t border-slate-800/80 bg-slate-950/70 backdrop-blur">
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
      <div>
        <div className="font-display text-2xl text-white">🎃 {SITE.name}</div>
        <p className="mt-2 text-sm text-slate-400">{SITE.tagline}</p>
        <div className="mt-3 inline-flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-900 py-1 pl-3 pr-1 font-mono text-xs text-emerald-300">
          {SITE.ip} <CopyButton text={SITE.ip} className="rounded-lg p-1.5 text-slate-300 hover:bg-slate-700" />
        </div>
      </div>
      <div><div className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">Play</div>
        <ul className="space-y-1.5 text-sm text-slate-300"><li><Link to="/status" className="hover:text-white">Server status</Link></li><li><Link to="/store" className="hover:text-white">Store</Link></li><li><Link to="/leaderboard" className="hover:text-white">Leaderboard</Link></li><li><Link to="/games" className="hover:text-white">Games</Link></li></ul></div>
      <div><div className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">Community</div>
        <ul className="space-y-1.5 text-sm text-slate-300"><li><a href={SITE.discord} target="_blank" rel="noreferrer" className="hover:text-white">Discord</a></li><li><Link to="/help" className="hover:text-white">Rules & FAQ</Link></li><li><Link to="/apply" className="hover:text-white">Apply for staff</Link></li><li><Link to="/updates" className="hover:text-white">Updates</Link></li><li><Link to="/bot" className="hover:text-white">Bot features</Link></li></ul></div>
      <div><div className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">Account</div>
        <ul className="space-y-1.5 text-sm text-slate-300"><li><Link to="/login" className="hover:text-white">Log in</Link></li><li><Link to="/register" className="hover:text-white">Create account</Link></li><li><Link to="/account" className="hover:text-white">My account</Link></li></ul></div>
    </div>
    <div className="border-t border-slate-800/80 py-4 text-center text-xs text-slate-500">© {new Date().getFullYear()} {SITE.name} • Not affiliated with Mojang or Microsoft.</div>
  </footer>
);
