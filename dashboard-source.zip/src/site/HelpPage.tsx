import React, { useEffect, useState } from 'react';
import { ChevronRight, Search } from 'lucide-react';
import { SITE } from '../lib/site';
import { PageHeader, card, input } from './ui';

interface Content { rules: Array<{ title: string; text: string }>; faq: Array<{ q: string; a: string }> }

export const HelpPage: React.FC = () => {
  const [c, setC] = useState<Content | null>(null);
  const [q, setQ] = useState('');
  const [open, setOpen] = useState<number | null>(0);
  useEffect(() => {
    fetch('/api/site/content').then((r) => r.json()).then((d) => setC(d?.content || { rules: [], faq: [] })).catch(() => setC({ rules: [], faq: [] }));
  }, []);
  const term = q.trim().toLowerCase();
  const faq = (c?.faq || []).filter((f) => !term || `${f.q} ${f.a}`.toLowerCase().includes(term));

  return (
    <div>
      <PageHeader emoji="📜" title="Rules & Help" sub="Read the rules, find quick answers, or ask us on Discord." />
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-2">
        <section>
          <h2 className="mb-4 font-display text-3xl text-white">Server rules</h2>
          {!c ? <div className="text-sm text-slate-400">Loading…</div> : c.rules.length === 0 ? <div className={`${card} p-5 text-sm text-slate-400`}>The rules have not been written yet.</div> : (
            <ol className="space-y-3">
              {c.rules.map((r, i) => (
                <li key={i} className={`${card} flex gap-4 p-4`}>
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-500/15 font-display text-lg text-emerald-300">{i + 1}</span>
                  <div><div className="font-bold text-white">{r.title}</div><p className="mt-0.5 text-sm text-slate-400">{r.text}</p></div>
                </li>
              ))}
            </ol>
          )}
        </section>
        <section>
          <h2 className="mb-4 font-display text-3xl text-white">Frequently asked</h2>
          <div className="relative mb-3"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input className={`${input} pl-9`} placeholder="Search questions…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search questions" /></div>
          <div className="space-y-2">
            {faq.map((f, i) => (
              <div key={f.q} className={`${card} overflow-hidden`}>
                <button type="button" onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left" aria-expanded={open === i}>
                  <span className="font-bold text-white">{f.q}</span><ChevronRight className={`h-4 w-4 shrink-0 text-emerald-400 transition ${open === i ? 'rotate-90' : ''}`} />
                </button>
                {open === i ? <p className="border-t border-slate-800/80 px-4 py-3 text-sm text-slate-300">{f.a}</p> : null}
              </div>
            ))}
            {c && faq.length === 0 ? <div className={`${card} p-5 text-sm text-slate-400`}>No answer found for “{q}”. Ask us on Discord!</div> : null}
          </div>
          <a href={SITE.discord} target="_blank" rel="noreferrer" className="mt-4 block rounded-xl bg-indigo-500 px-4 py-3 text-center text-sm font-bold text-white hover:bg-indigo-400">Still stuck? Open a ticket on Discord</a>
        </section>
      </div>
    </div>
  );
};
