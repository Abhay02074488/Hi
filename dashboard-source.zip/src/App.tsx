import React, { useState } from 'react';
import { ToastProvider } from './context/ToastContext';
import { StoreConfigProvider } from './context/StoreConfigContext';
import { CartProvider, useCart } from './context/CartContext';
import { AuthProvider } from './context/AuthContext';
import { useRoute, navigate } from './lib/router';
import { SiteNav } from './site/SiteNav';
import { HomePage } from './site/HomePage';
import { StatusPage } from './site/StatusPage';
import { AuthPage } from './site/AuthPage';
import { AccountPage } from './site/AccountPage';
import { AdminShell } from './admin/AdminShell';
import { SiteFooter } from './site/SiteFooter';
import { HalloweenBackdrop } from './site/HalloweenBackdrop';
import { AnnouncementBar } from './site/AnnouncementBar';
import { HelpPage } from './site/HelpPage';
import { ApplyPage } from './site/ApplyPage';
import { StoreView } from './components/StoreView';
import { CartDrawer } from './components/CartDrawer';
import { UpiPaymentModal } from './components/UpiPaymentModal';
import { LevelingSystem } from './components/LevelingSystem';
import { GamesHub } from './components/GamesHub';
import { StaffPage } from './components/StaffPage';
import { UpdatesPage } from './components/UpdatesPage';
import { PublicPortal } from './components/PublicPortal';

function Pages({ route }: { route: string }) {
  const cart = useCart() as any;
  const [paying, setPaying] = useState(false);

  let page: React.ReactNode;
  if (route === '/' || route === '') page = <HomePage />;
  else if (route.startsWith('/status')) page = <StatusPage />;
  else if (route.startsWith('/login')) page = <AuthPage mode="login" />;
  else if (route.startsWith('/register')) page = <AuthPage mode="register" />;
  else if (route.startsWith('/account')) page = <AccountPage />;
  else if (route.startsWith('/admin')) page = <AdminShell route={route} />;
  else if (route.startsWith('/store')) page = <StoreView onInstantBuyProduct={() => {}} />;
  else if (route.startsWith('/leaderboard')) page = <LevelingSystem />;
  else if (route.startsWith('/games')) page = <GamesHub />;
  else if (route.startsWith('/help')) page = <HelpPage />;
  else if (route.startsWith('/apply')) page = <ApplyPage />;
  else if (route.startsWith('/staff')) page = <StaffPage onOpenApplications={() => navigate('/apply')} />;
  else if (route.startsWith('/updates')) page = <UpdatesPage />;
  else if (route.startsWith('/bot')) page = <PublicPortal onOpenLogin={() => navigate('/login')} />;
  else page = (
    <div className="mx-auto max-w-md px-4 py-24 text-center">
      <div className="text-6xl">🧭</div>
      <h1 className="mt-4 text-2xl font-black text-white">Page not found</h1>
      <a href="#/" className="mt-4 inline-block font-bold text-emerald-400">Back to home</a>
    </div>
  );

  return (
    <>
      <main className="min-h-[70vh] flex-1">{page}</main>
      <CartDrawer isOpen={!!cart.isCartOpen} onClose={() => cart.setIsCartOpen && cart.setIsCartOpen(false)} onProceedToPayment={() => { cart.setIsCartOpen && cart.setIsCartOpen(false); setPaying(true); }} />
      <UpiPaymentModal isOpen={paying} onClose={() => setPaying(false)} onOrderSuccess={() => { setPaying(false); cart.clearCart && cart.clearCart(); }} />
    </>
  );
}

function Shell() {
  const route = useRoute();
  return (
    <div className="bg-site relative flex min-h-screen flex-col text-slate-100">
      <HalloweenBackdrop />
      <div className="relative z-10 flex min-h-screen flex-col">
        <AnnouncementBar />
        <SiteNav route={route} />
        <Pages route={route} />
        <SiteFooter />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <StoreConfigProvider>
      <CartProvider>
        <ToastProvider>
          <AuthProvider>
            <Shell />
          </AuthProvider>
        </ToastProvider>
      </CartProvider>
    </StoreConfigProvider>
  );
}
