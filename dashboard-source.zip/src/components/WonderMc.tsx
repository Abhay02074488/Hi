import React, { useState, useEffect } from 'react';
import {
  Globe,
  Server,
  ShoppingBag,
  Vote,
  ExternalLink,
  RefreshCw,
  Copy,
  Check,
  Radio,
  Sparkles,
  Gamepad2,
  Code2,
  Image as ImageIcon,
  Download,
  Crown,
  Shield,
  Layers
} from 'lucide-react';

interface WonderConfig {
  java_ip: string;
  java_port: number;
  bedrock_ip: string;
  bedrock_port: number;
  store_url: string;
  vote_url: string;
  discord_url: string;
}

interface RealtimeMCStatus {
  domain: string;
  java_ip: string;
  java_port: number;
  bedrock_ip: string;
  bedrock_port: number;
  online: boolean;
  players: {
    online: number;
    max: number;
  };
  motd: string;
  motd_line1: string;
  motd_line2: string;
  version: string;
  ping: number;
}

export function WonderMc() {
  const [config, setConfig] = useState<WonderConfig>({
    java_ip: 'play.wondermc.fun',
    java_port: 25565,
    bedrock_ip: 'play.wondermc.fun',
    bedrock_port: 19132,
    store_url: 'https://dc.gg/wondermc',
    vote_url: 'https://dc.gg/wondermc',
    discord_url: 'https://dc.gg/wondermc'
  });

  const [isSaved, setIsSaved] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedIp, setCopiedIp] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [selectedLogo, setSelectedLogo] = useState<'wm' | 'wc'>('wm');
  const [downloadStatus, setDownloadStatus] = useState<string | null>(null);

  const downloadServerIcon = (src: string, filename: string, size = 64) => {
    setDownloadStatus(`Preparing ${filename}...`);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = src;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, size, size);
        const dataUrl = canvas.toDataURL('image/png');
        const a = document.createElement('a');
        a.href = dataUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setDownloadStatus(`✅ Downloaded ${filename}!`);
        setTimeout(() => setDownloadStatus(null), 3500);
      }
    };
    img.onerror = () => {
      // Fallback direct link
      const a = document.createElement('a');
      a.href = src;
      a.download = filename;
      a.target = '_blank';
      a.click();
      setDownloadStatus(`✅ Opened ${filename}!`);
      setTimeout(() => setDownloadStatus(null), 3500);
    };
  };

  // Toggle for testing Offline vs Online MOTD layout preview
  const [previewState, setPreviewState] = useState<'live' | 'online_sim' | 'offline_sim'>('live');

  // Real-time server telemetry
  const [liveStatus, setLiveStatus] = useState<RealtimeMCStatus>({
    domain: 'play.wondermc.fun',
    java_ip: 'play.wondermc.fun',
    java_port: 25565,
    bedrock_ip: 'play.wondermc.fun',
    bedrock_port: 19132,
    online: true,
    players: {
      online: 11,
      max: 2000
    },
    motd: 'WONDERMC ↪ Boxpvp ┆ Lifesteal ┆ Practice\nStep In Gear Up Dominate',
    motd_line1: 'WONDERMC ↪ Boxpvp ┆ Lifesteal ┆ Practice',
    motd_line2: 'Step In Gear Up Dominate',
    version: '1.19.x - 1.20.x',
    ping: 24
  });
  const [isRefreshingStatus, setIsRefreshingStatus] = useState(false);
  const [lastRefreshed, setLastRefreshed] = useState<string>('Just now');

  // Active Embed Preview Tab
  const [embedTab, setEmbedTab] = useState<'server_panel' | 'server' | 'motd' | 'ip' | 'rules' | 'store'>('server_panel');
  const [ephemeralToast, setEphemeralToast] = useState<{ title: string; message: string; type: 'java' | 'bedrock' } | null>(null);

  useEffect(() => {
    fetchData();
    fetchLiveStatus();
    const interval = setInterval(fetchLiveStatus, 15000);
    return () => clearInterval(interval);
  }, []);

  const fetchLiveStatus = async () => {
    try {
      setIsRefreshingStatus(true);
      const res = await fetch('/api/minecraft/realtime');
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setLiveStatus({
            domain: data.domain || 'play.wondermc.fun',
            java_ip: data.java_ip || 'play.wondermc.fun',
            java_port: data.java_port || 25565,
            bedrock_ip: data.bedrock_ip || 'play.wondermc.fun',
            bedrock_port: data.bedrock_port || 19132,
            online: data.online ?? true,
            players: data.players || { online: 11, max: 2000 },
            motd: data.motd || 'WONDERMC ↪ Boxpvp ┆ Lifesteal ┆ Practice\nStep In Gear Up Dominate',
            motd_line1: data.motd_line1 || 'WONDERMC ↪ Boxpvp ┆ Lifesteal ┆ Practice',
            motd_line2: data.motd_line2 || 'Step In Gear Up Dominate',
            version: data.version || '1.19.x - 1.20.x',
            ping: data.ping || 24
          });
          setLastRefreshed(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
        }
      }
    } catch (e) {
      console.error('Failed to fetch real-time MC status:', e);
    } finally {
      setIsRefreshingStatus(false);
    }
  };

  const fetchData = async () => {
    try {
      const res = await fetch('/api/minecraft/config');
      if (res.ok) {
        const data = await res.json();
        setConfig(data);
      }
    } catch (e) {
      console.error('Failed to fetch MC config:', e);
    }
  };

  const handleSaveConfig = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/minecraft/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      if (res.ok) {
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 3000);
        fetchLiveStatus();
      }
    } catch (e) {
      console.error('Failed to save MC config:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIp(type);
    setTimeout(() => setCopiedIp(null), 2500);
  };

  const copyCodeSnippet = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(type);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  // Determine current display status based on previewState toggle
  const isOnline = previewState === 'offline_sim' ? false : (previewState === 'online_sim' ? true : liveStatus.online);
  const displayLine1 = isOnline ? (liveStatus.motd_line1 || 'WONDERMC ↪ Boxpvp ┆ Lifesteal ┆ Practice') : 'SERVER OFFLINE';
  const displayLine2 = isOnline ? (liveStatus.motd_line2 || 'Step In Gear Up Dominate') : "Can't connect to server";

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      
      {/* Top Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 border border-emerald-500/20 p-6 md:p-8 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border-2 border-emerald-500/30 flex items-center justify-center text-3xl shadow-inner font-black text-emerald-400 font-mono">
              ⛏️
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-2xl font-black tracking-tight text-white font-mono">
                  WONDERMC NETWORK
                </h2>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold flex items-center gap-1 border ${
                  isOnline 
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' 
                    : 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                }`}>
                  <Radio className={`w-3 h-3 ${isOnline ? 'text-emerald-400 animate-pulse' : 'text-rose-400'}`} />
                  {isOnline ? 'ONLINE' : 'OFFLINE'}
                </span>
              </div>
              <p className="text-sm text-slate-300 mt-1">
                Custom MOTD Status Panel, Auto-Refreshing Discord Bot & Server Connection
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => copyToClipboard(config.java_ip, 'java')}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 text-white rounded-xl text-xs font-medium transition cursor-pointer"
            >
              <Server className="w-3.5 h-3.5 text-emerald-400" />
              <span>Java IP: <strong className="text-emerald-400">{config.java_ip}</strong></span>
              {copiedIp === 'java' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            </button>

            <button
              onClick={() => copyToClipboard(config.bedrock_ip, 'bedrock')}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 text-white rounded-xl text-xs font-medium transition cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>Bedrock: <strong className="text-cyan-400">{config.bedrock_ip}</strong></span>
              {copiedIp === 'bedrock' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            </button>
          </div>
        </div>
      </div>

      {/* SECTION: OFFICIAL WONDERMC SERVER LOGO & ICON SUITE */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2 font-mono">
              <Crown className="w-5 h-5 text-amber-400" />
              Official WonderMc Minecraft Server Logo Suite
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Custom-sculpted 3D voxel Minecraft logos with diamond & emerald crystals, royal crown, and golden bevels.
            </p>
          </div>

          {downloadStatus && (
            <span className="px-3 py-1 rounded-lg text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-fade-in flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
              {downloadStatus}
            </span>
          )}
        </div>

        {/* Logo Selection Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Variant 1: Royal Crest (WM) */}
          <div
            onClick={() => setSelectedLogo('wm')}
            className={`group relative rounded-2xl p-4 transition-all duration-300 border-2 cursor-pointer ${
              selectedLogo === 'wm'
                ? 'bg-slate-950 border-emerald-500 shadow-[0_0_25px_rgba(16,185,129,0.25)]'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
                    👑 Official 3D Ice "WM" Logo (Discord CDN)
                  </span>
                  {selectedLogo === 'wm' && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                      Active
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Official 3D voxel "WM" Minecraft logo in cyan & ice blue blocks with cracks and dark outlines.
                </p>
              </div>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">
                2048x2048
              </span>
            </div>

            {/* Logo Image Preview */}
            <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-slate-900 border border-slate-800/80 mb-3 flex items-center justify-center group-hover:border-emerald-500/50 transition-colors">
              <img
                src="/wondermc_logo.png"
                alt="Official WonderMc 3D Ice Logo (WM)"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                <span className="text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Official Discord Icon (2048x2048)
                </span>
              </div>
            </div>

            {/* Actions for WM */}
            <div className="flex flex-wrap gap-2 text-xs">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  downloadServerIcon('/server-icon.png', 'server-icon.png', 64);
                }}
                className="flex-1 min-w-[130px] flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>server-icon.png (64x64)</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  downloadServerIcon('/wondermc_logo.png', 'wondermc_logo.png', 2048);
                }}
                className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>HD PNG (2048x2048)</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  copyCodeSnippet('https://cdn.discordapp.com/icons/1546197146879918286/08ad3abe5024106d7faf3bef39e2510a.webp?size=2048', 'logo_url_wm');
                }}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer flex items-center gap-1"
                title="Copy Official Discord CDN URL"
              >
                {copiedCode === 'logo_url_wm' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">Discord CDN</span>
              </button>
            </div>
          </div>

          {/* Variant 2: Battle Crest (WC) */}
          <div
            onClick={() => setSelectedLogo('wc')}
            className={`group relative rounded-2xl p-4 transition-all duration-300 border-2 cursor-pointer ${
              selectedLogo === 'wc'
                ? 'bg-slate-950 border-cyan-500 shadow-[0_0_25px_rgba(6,182,212,0.25)]'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                    ⚔️ WonderMc Battle Crest ("WC" / "Wc")
                  </span>
                  {selectedLogo === 'wc' && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
                      Active
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Blocky stylized 'WC' typography with glowing emeralds, enchanted lapis, and golden bevels.
                </p>
              </div>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-2 py-1 rounded border border-cyan-500/20">
                1024x1024
              </span>
            </div>

            {/* Logo Image Preview */}
            <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-slate-900 border border-slate-800/80 mb-3 flex items-center justify-center group-hover:border-cyan-500/50 transition-colors">
              <img
                src="/wondermc_wc_logo.jpg"
                alt="WonderMc Battle Crest Logo (WC)"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                <span className="text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> High-Resolution 3D Render
                </span>
              </div>
            </div>

            {/* Actions for WC */}
            <div className="flex flex-wrap gap-2 text-xs">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  downloadServerIcon('/wondermc_wc_logo.jpg', 'server-icon.png', 64);
                }}
                className="flex-1 min-w-[130px] flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>server-icon.png (64x64)</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  downloadServerIcon('/wondermc_wc_logo.jpg', 'wondermc_wc_logo_hd.jpg', 1024);
                }}
                className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>HD (1024x1024)</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  copyCodeSnippet(`${window.location.origin}/wondermc_wc_logo.jpg`, 'logo_url_wc');
                }}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                title="Copy Direct Image Link"
              >
                {copiedCode === 'logo_url_wc' ? <Check className="w-3.5 h-3.5 text-cyan-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>

        {/* LIVE IN-GAME MINECRAFT MULTIPLAYER SERVER LIST ROW PREVIEW */}
        <div className="bg-[#101216] border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-1 border-b border-slate-800/80">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5 font-mono">
              <Gamepad2 className="w-4 h-4 text-emerald-400" />
              Minecraft Java Edition Server List Preview
            </span>
            <span className="text-[11px] text-slate-400">
              Active Icon: <strong className={selectedLogo === 'wm' ? 'text-emerald-400' : 'text-cyan-400'}>
                {selectedLogo === 'wm' ? 'Royal 3D Crest (WM)' : 'Battle Crest (Wc)'}
              </strong>
            </span>
          </div>

          {/* Minecraft Server List Entry Container */}
          <div className="bg-[#0b0c0e] hover:bg-[#14171d] border-2 border-slate-700/80 rounded p-3 flex items-center gap-4 transition-colors font-mono select-none">
            {/* 64x64 In-Game Server Icon */}
            <div className="relative w-16 h-16 min-w-16 rounded overflow-hidden border-2 border-slate-600 bg-slate-950 shadow-inner">
              <img
                src={selectedLogo === 'wm' ? '/wondermc_logo.jpg' : '/wondermc_wc_logo.jpg'}
                alt="Minecraft Server Icon"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Server Info & MOTD Text */}
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex items-center justify-between">
                <div className="text-sm font-bold tracking-wide flex items-center gap-2">
                  <span className="text-emerald-400 drop-shadow-[0_0_6px_rgba(52,211,153,0.6)]">WonderMc Network</span>
                  <span className="text-slate-400 text-xs font-normal">| 1.20 - 1.21.x</span>
                </div>
                {/* Ping latency bars & player count */}
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400">{liveStatus.players.online} / {liveStatus.players.max}</span>
                  <div className="flex items-end gap-0.5 h-3.5" title={`${liveStatus.ping} ms`}>
                    <span className="w-0.5 h-1.5 bg-emerald-400 rounded-xs" />
                    <span className="w-0.5 h-2 bg-emerald-400 rounded-xs" />
                    <span className="w-0.5 h-2.5 bg-emerald-400 rounded-xs" />
                    <span className="w-0.5 h-3 bg-emerald-400 rounded-xs" />
                    <span className="w-0.5 h-3.5 bg-emerald-400 rounded-xs" />
                  </div>
                </div>
              </div>

              {/* MOTD Lines */}
              <div className="text-xs text-lime-300 truncate">
                {displayLine1}
              </div>
              <div className="text-xs text-slate-300 truncate flex items-center justify-between">
                <span>{displayLine2}</span>
                <span className="text-[10px] text-cyan-400 font-mono">play.wondermc.fun</span>
              </div>
            </div>
          </div>

          {/* Quick Setup Instructions for server-icon.png */}
          <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 text-[11px] text-slate-400 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <span className="flex items-center gap-1.5">
              💡 <strong>Server Owner Tip:</strong> Click <strong>"server-icon.png (64x64)"</strong> and place it in your Minecraft server's main folder, then restart your server to display this custom logo in-game!
            </span>
            <button
              onClick={() => copyCodeSnippet("server-icon.png", "filename")}
              className="text-emerald-400 hover:underline flex items-center gap-1 whitespace-nowrap cursor-pointer"
            >
              {copiedCode === "filename" ? "Copied name!" : "Copy filename"}
            </button>
          </div>
        </div>
      </div>

      {/* SECTION: PIXEL-PERFECT MOTD BANNER CARD (MATCHING USER SPECIFICATION) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2 font-mono">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              Official Minecraft MOTD Status Banner
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Exact server list banner rendered with MOTD and real-time online player count under it
            </p>
          </div>

          {/* Mode Switcher: Live / Simulate Online / Simulate Offline */}
          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setPreviewState('live')}
              className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer ${
                previewState === 'live' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              ⚡ Live ({liveStatus.online ? 'Online' : 'Offline'})
            </button>
            <button
              onClick={() => setPreviewState('online_sim')}
              className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer ${
                previewState === 'online_sim' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              🟢 Force Online
            </button>
            <button
              onClick={() => setPreviewState('offline_sim')}
              className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer ${
                previewState === 'offline_sim' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              🔴 Force Offline
            </button>
          </div>
        </div>

        {/* CUSTOM MINECRAFT BANNER CONTAINER */}
        <div className="w-full flex justify-center py-4 bg-slate-950/70 rounded-xl border border-slate-800/80">
          <div className="w-full max-w-2xl bg-[#090b10] rounded-2xl p-3 sm:p-4 border-2 border-cyan-500/40 shadow-[0_0_25px_rgba(6,182,212,0.25)] relative overflow-hidden font-mono select-none">
            
            {/* Top Bar with IP on both sides as requested */}
            <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-slate-300 pb-2.5 mb-2.5 border-b border-slate-800/80 px-2 tracking-wide">
              <span className="text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]">play.wondermc.fun</span>
              <span className="text-slate-500 font-normal">-</span>
              <span className="text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]">play.wondermc.fun</span>
            </div>

            {/* Inner Content Area */}
            <div className="flex items-center gap-3 sm:gap-4 px-2 py-1">
              
              {/* Server Icon Box (Official WM 3D Ice Logo) */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl overflow-hidden border border-cyan-500/40 shadow-lg shrink-0 bg-slate-900">
                <img
                  src="/server-icon.png"
                  alt="WonderMc Server Icon"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* MOTD Lines */}
              <div className="flex-1 min-w-0">
                {/* Line 1 */}
                <div className={`text-sm sm:text-base font-bold tracking-tight truncate ${
                  isOnline 
                    ? 'text-[#55FF55] drop-shadow-[0_0_6px_rgba(85,255,85,0.4)]' 
                    : 'text-[#FF5555] font-black tracking-widest drop-shadow-[0_0_6px_rgba(255,85,85,0.6)]'
                }`}>
                  {displayLine1}
                </div>

                {/* Line 2 */}
                <div className={`text-xs sm:text-sm mt-1 truncate ${
                  isOnline 
                    ? 'text-white font-medium' 
                    : 'text-slate-400 italic'
                }`}>
                  {displayLine2}
                </div>
              </div>
            </div>

            {/* Bottom Bar with Player Counter */}
            <div className="mt-3 pt-2.5 border-t border-slate-800/80 px-2 flex items-center justify-between text-xs sm:text-sm font-bold">
              <span className="text-slate-400 text-[11px] sm:text-xs">
                {isOnline ? '🟢 Live Server Telemetry' : '🔴 Connection Lost'}
              </span>
              <div className="flex items-center gap-1 font-mono tracking-wider">
                {isOnline ? (
                  <>
                    <span className="text-[#55FF55]">{liveStatus.players.online}</span>
                    <span className="text-slate-400">/{liveStatus.players.max.toLocaleString()}</span>
                  </>
                ) : (
                  <span className="text-[#FF5555] font-black">OFFLINE</span>
                )}
              </div>
            </div>

          </div>
        </div>

        {/* Banner SVG API Integration & Copy Link */}
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-slate-300 font-mono">
            <ImageIcon className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="text-slate-400">Live Dynamic SVG URL:</span>
            <code className="text-emerald-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
              /api/minecraft/banner.svg
            </code>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => copyCodeSnippet(`${window.location.origin}/api/minecraft/banner.svg`, 'svg_url')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition cursor-pointer border border-slate-700"
            >
              {copiedCode === 'svg_url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>Copy Direct Image URL</span>
            </button>

            <button
              onClick={() => copyCodeSnippet(`![WonderMc Status](${window.location.origin}/api/minecraft/banner.svg)`, 'markdown')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition cursor-pointer border border-slate-700"
            >
              {copiedCode === 'markdown' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Code2 className="w-3.5 h-3.5 text-slate-400" />}
              <span>Copy Markdown Badge</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Server Settings & Live Embed Previews */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Network Connection & Settings (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Server Connection Config Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
              <div className="flex items-center gap-2.5 text-slate-200 font-semibold">
                <Server className="w-5 h-5 text-emerald-400" />
                <span>Server Address & URLs</span>
              </div>
              <span className="text-xs text-slate-400">Syncs to `/wondermc` commands</span>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1.5">☕ Java Server Address</label>
                <input
                  type="text"
                  value={config.java_ip}
                  onChange={(e) => setConfig({ ...config, java_ip: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                  placeholder="play.wondermc.fun"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-slate-400 font-medium mb-1.5">📱 Bedrock Server Address</label>
                  <input
                    type="text"
                    value={config.bedrock_ip}
                    onChange={(e) => setConfig({ ...config, bedrock_ip: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                    placeholder="play.wondermc.fun"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1.5">Port</label>
                  <input
                    type="number"
                    value={config.bedrock_port}
                    onChange={(e) => setConfig({ ...config, bedrock_port: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                    placeholder="19132"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1.5">🛒 Webstore URL</label>
                <input
                  type="text"
                  value={config.store_url}
                  onChange={(e) => setConfig({ ...config, store_url: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:border-emerald-500 focus:outline-none"
                  placeholder="https://dc.gg/wondermc"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1.5">🗳️ Vote URL</label>
                <input
                  type="text"
                  value={config.vote_url}
                  onChange={(e) => setConfig({ ...config, vote_url: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:border-emerald-500 focus:outline-none"
                  placeholder="https://dc.gg/wondermc"
                />
              </div>

              <div className="pt-2">
                <button
                  onClick={handleSaveConfig}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-xl text-xs transition shadow-lg shadow-emerald-900/30 cursor-pointer disabled:opacity-50"
                >
                  {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : isSaved ? <Check className="w-4 h-4" /> : <SaveIcon className="w-4 h-4" />}
                  {isSaved ? 'Settings Saved Successfully!' : 'Save Minecraft Configuration'}
                </button>
              </div>
            </div>
          </div>

          {/* Gamemodes Network Info */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg">
            <h3 className="text-sm font-semibold text-slate-200 mb-3 flex items-center gap-2">
              <Gamepad2 className="w-4 h-4 text-emerald-400" />
              Active Network Gamemodes
            </h3>
            <div className="grid grid-cols-3 gap-2.5 text-xs">
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl text-center">
                <div className="font-semibold text-amber-400">📦 BoxPvP</div>
                <div className="text-slate-400 text-[10px] mt-0.5">Mines & Arena</div>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl text-center">
                <div className="font-semibold text-rose-400">🩸 Lifesteal</div>
                <div className="text-slate-400 text-[10px] mt-0.5">Steal Hearts</div>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl text-center">
                <div className="font-semibold text-cyan-400">⚔️ Practice</div>
                <div className="text-slate-400 text-[10px] mt-0.5">Duels & Combos</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Live Discord Embed Previews (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg">
            
            {/* Header & Tabs */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800 mb-6">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  Discord Bot Interactive Server Panels
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  ANSI-formatted Discord embeds sent by <code className="text-emerald-400">/serverpanel</code>, <code className="text-emerald-400">/panel</code> & <code className="text-emerald-400">/server</code>
                </p>
              </div>

              {/* Embed Tabs */}
              <div className="flex flex-wrap items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  onClick={() => setEmbedTab('server_panel')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    embedTab === 'server_panel' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                  /serverpanel (Live Panel)
                </button>
                <button
                  onClick={() => setEmbedTab('server')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    embedTab === 'server' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-cyan-400 inline-block" />
                  /server (Statsify)
                </button>
                <button
                  onClick={() => setEmbedTab('motd')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    embedTab === 'motd' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                  /motd (MOTD Image)
                </button>
                <button
                  onClick={() => setEmbedTab('ip')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    embedTab === 'ip' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  /ip
                </button>
                <button
                  onClick={() => setEmbedTab('rules')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    embedTab === 'rules' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  /rules
                </button>
                <button
                  onClick={() => setEmbedTab('store')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    embedTab === 'store' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  /store
                </button>
              </div>
            </div>

            {/* TAB 1: AUTO-UPDATING LIVE SERVER PANEL EMBED */}
            {embedTab === 'server_panel' && (
              <div className="space-y-4">
                <div className="bg-emerald-950/40 border border-emerald-500/30 p-3.5 rounded-xl text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-emerald-300">
                    <Radio className="w-4 h-4 text-emerald-400 animate-pulse shrink-0" />
                    <span><strong>Live Auto-Updating Status Panel:</strong> Auto-refreshes every 15s in Discord channels with interactive buttons.</span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => copyCodeSnippet('/serverpanel', 'slash_panel')}
                      className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded border border-slate-700 text-[11px] font-mono transition cursor-pointer flex items-center gap-1"
                    >
                      {copiedCode === 'slash_panel' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                      /serverpanel
                    </button>
                  </div>
                </div>

                {/* Discord Embed Simulation for Live Panel */}
                <div className={`bg-[#2b2d31] rounded-lg p-4 text-white font-sans shadow-md border-l-4 ${isOnline ? 'border-emerald-500' : 'border-rose-500'}`}>
                  
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2 text-sm font-bold text-slate-100">
                      <span>🎮 WonderMc Network • Live Server Panel</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      isOnline ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}>
                      {isOnline ? 'ONLINE' : 'OFFLINE'}
                    </span>
                  </div>

                  {/* Discord ANSI MOTD Banner Box */}
                  <div className="bg-[#1e1f22] p-3 rounded-lg text-xs font-mono mb-4 border border-slate-800 text-slate-200 leading-relaxed shadow-inner">
                    <div className="text-cyan-400 font-bold border-b border-slate-800 pb-1 mb-1.5 flex justify-between">
                      <span>play.wondermc.fun</span>
                      <span>play.wondermc.fun</span>
                    </div>
                    <div className={`font-bold ${isOnline ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {displayLine1}
                    </div>
                    <div className="text-slate-300">
                      {displayLine2}
                    </div>
                    <div className="mt-2 pt-1 border-t border-slate-800 text-right font-bold">
                      {isOnline ? (
                        <span className="text-emerald-400">{liveStatus.players.online} <span className="text-slate-500">/ {liveStatus.players.max.toLocaleString()} Players Online</span></span>
                      ) : (
                        <span className="text-rose-400">OFFLINE</span>
                      )}
                    </div>
                  </div>

                  {/* Statsify Structured Table Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs mb-4">
                    <div className="bg-[#1e1f22]/60 p-2.5 rounded border border-slate-800/80">
                      <div className="text-slate-400 text-[11px] font-semibold flex items-center gap-1">📊 Status & Ping</div>
                      <div className="mt-1">
                        <span className={`font-bold ${isOnline ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {isOnline ? '🟢 ONLINE' : '🔴 OFFLINE'}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-0.5">📶 Latency: <strong className="text-slate-200">{liveStatus.ping} ms</strong></div>
                      </div>
                    </div>

                    <div className="bg-[#1e1f22]/60 p-2.5 rounded border border-slate-800/80">
                      <div className="text-slate-400 text-[11px] font-semibold">☕ Java Connection</div>
                      <div className="font-mono text-slate-200 mt-1">{config.java_ip}</div>
                      <div className="text-[10px] text-slate-400">Port: {config.java_port}</div>
                    </div>

                    <div className="bg-[#1e1f22]/60 p-2.5 rounded border border-slate-800/80">
                      <div className="text-slate-400 text-[11px] font-semibold">📱 Bedrock Connection</div>
                      <div className="font-mono text-slate-200 mt-1">{config.bedrock_ip}</div>
                      <div className="text-[10px] text-slate-400">Port: {config.bedrock_port}</div>
                    </div>

                    <div className="bg-[#1e1f22]/60 p-2.5 rounded border border-slate-800/80">
                      <div className="text-slate-400 text-[11px] font-semibold">🎮 Active Gamemodes</div>
                      <div className="text-slate-200 text-[11px] mt-1 font-mono">
                        📦 BoxPvP ┆ 🩸 Lifesteal ┆ ⚔️ Practice
                      </div>
                    </div>

                    <div className="bg-[#1e1f22]/60 p-2.5 rounded border border-slate-800/80">
                      <div className="text-slate-400 text-[11px] font-semibold">🏷️ Software & Version</div>
                      <div className="text-slate-200 text-[11px] mt-1 font-mono">
                        PaperMC {liveStatus.version}
                      </div>
                      <div className="text-[10px] text-emerald-400/90 italic">Crossplay Java & Bedrock</div>
                    </div>

                    <div className="bg-[#1e1f22]/60 p-2.5 rounded border border-slate-800/80">
                      <div className="text-slate-400 text-[11px] font-semibold">👥 Network Population</div>
                      <div className="font-bold text-slate-200 mt-1">
                        {isOnline ? `${liveStatus.players.online} / ${liveStatus.players.max.toLocaleString()}` : '0 / 0'}
                      </div>
                      <div className="text-[10px] text-slate-400">Auto-refreshing live (15s)</div>
                    </div>
                  </div>

                  {/* Discord Embedded MOTD Banner Image (embed.set_image) */}
                  <div className="mb-3 rounded-lg overflow-hidden border border-slate-700/60 bg-[#111214] shadow-md">
                    <div className="bg-[#18191c] px-3 py-1.5 border-b border-slate-800/80 flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-1.5 text-slate-300 font-medium">
                        <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Discord Embed Image • Live In-Game MOTD</span>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/60 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                        embed.set_image
                      </span>
                    </div>
                    <img
                      src={`https://mcapi.us/server/image?ip=${config.java_ip || 'play.wondermc.fun'}`}
                      alt="WonderMc MOTD Banner"
                      className="w-full h-auto object-cover block"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/api/minecraft/banner.svg';
                      }}
                    />
                  </div>

                  <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between text-[11px] text-slate-400">
                    <span>WonderMc Live Server Panel • play.wondermc.fun • Updates every 15s</span>
                    <span>Synced: {lastRefreshed}</span>
                  </div>
                </div>

                {/* Discord Interactive Button Bar */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={fetchLiveStatus}
                    disabled={isRefreshingStatus}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded text-xs font-medium shadow transition cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingStatus ? 'animate-spin' : ''}`} />
                    🔄 Refresh Status
                  </button>
                  <button
                    onClick={() => {
                      copyToClipboard(config.java_ip, 'btn_java');
                      setEphemeralToast({
                        title: '☕ Java Server Address',
                        message: `play.wondermc.fun (Port: 25565)\nCopied to clipboard! Join via Minecraft Java Multiplayer.`,
                        type: 'java'
                      });
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#4e5058] hover:bg-[#6d6f78] text-white rounded text-xs font-medium transition cursor-pointer"
                  >
                    ☕ Java IP
                  </button>
                  <button
                    onClick={() => {
                      copyToClipboard(`${config.bedrock_ip}:${config.bedrock_port}`, 'btn_bedrock');
                      setEphemeralToast({
                        title: '📱 Bedrock Connection',
                        message: `Address: play.wondermc.fun • Port: 19132\nFor Mobile (PE), Xbox, PS, and Switch!`,
                        type: 'bedrock'
                      });
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#4e5058] hover:bg-[#6d6f78] text-white rounded text-xs font-medium transition cursor-pointer"
                  >
                    📱 Bedrock IP
                  </button>
                  <button
                    onClick={() => setEmbedTab('motd')}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#4e5058] hover:bg-[#6d6f78] text-white rounded text-xs font-medium transition cursor-pointer"
                  >
                    🖼️ MOTD Banner
                  </button>
                  <a
                    href={config.store_url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#4e5058] hover:bg-[#6d6f78] text-white rounded text-xs font-medium transition"
                  >
                    🛒 Store
                  </a>
                  <a
                    href={config.vote_url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#4e5058] hover:bg-[#6d6f78] text-white rounded text-xs font-medium transition"
                  >
                    🗳️ Vote
                  </a>
                </div>

                {/* Interactive Ephemeral Toast Preview */}
                {ephemeralToast && (
                  <div className="bg-[#1e1f22] border-l-4 border-[#5865F2] p-3 rounded-lg text-xs font-sans text-white shadow-lg animate-fade-in flex items-start justify-between">
                    <div>
                      <div className="font-bold text-slate-200 flex items-center gap-1.5">
                        <span className="text-[10px] bg-[#5865F2]/20 text-[#5865F2] px-1.5 py-0.5 rounded font-mono font-bold">Only you can see this</span>
                        {ephemeralToast.title}
                      </div>
                      <div className="text-slate-300 mt-1 whitespace-pre-line font-mono text-[11px]">
                        {ephemeralToast.message}
                      </div>
                    </div>
                    <button
                      onClick={() => setEphemeralToast(null)}
                      className="text-slate-400 hover:text-white text-xs cursor-pointer ml-2"
                    >
                      ✕
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB 1: STATSIFY-STYLED /server COMMAND (MOTD ONLY) */}
            {embedTab === 'server' && (
              <div className="space-y-4">
                <div className="bg-cyan-950/40 border border-cyan-500/30 p-3.5 rounded-xl text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-cyan-300">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    <span><strong>/server Command:</strong> Displays the Server MOTD banner and message only.</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => copyCodeSnippet('/server', 'slash_server')}
                      className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded border border-slate-700 text-[11px] font-mono transition cursor-pointer flex items-center gap-1"
                    >
                      {copiedCode === 'slash_server' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                      /server
                    </button>
                  </div>
                </div>

                {/* Discord Embed Simulation for /server (MOTD ONLY) */}
                <div className={`bg-[#2b2d31] rounded-lg p-4 text-white font-sans shadow-md border-l-4 ${isOnline ? 'border-emerald-500' : 'border-rose-500'}`}>
                  
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2 text-sm font-bold text-slate-100">
                      <span>🎮 play.wondermc.fun • Server MOTD</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      isOnline ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}>
                      {isOnline ? 'ONLINE' : 'OFFLINE'}
                    </span>
                  </div>

                  {/* Clean MOTD Text Section */}
                  <div className="bg-[#1e1f22] p-3 rounded-lg text-xs font-mono mb-4 border border-slate-800 text-slate-200 leading-relaxed shadow-inner">
                    <div className="text-slate-400 font-bold mb-1">MOTD:</div>
                    <div className={`font-bold text-sm ${isOnline ? 'text-emerald-400' : 'text-rose-400'}`}>
                      &gt; {displayLine1}
                    </div>
                    <div className="text-slate-300">
                      &gt; {displayLine2}
                    </div>
                    <div className="mt-2.5 pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between text-[11px] text-slate-400 gap-2">
                      <div className="flex items-center gap-3">
                        <span>📊 Status: <strong className={isOnline ? 'text-emerald-400' : 'text-rose-400'}>{isOnline ? '🟢 Online' : '🔴 Offline'}</strong></span>
                        <span>📶 Ping: <strong className="text-slate-200">{liveStatus.ping} ms</strong></span>
                      </div>
                      <div>
                        👥 Players: <strong className="text-emerald-400">{isOnline ? liveStatus.players.online : 0}</strong> <span className="text-slate-500">/ {liveStatus.players.max.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Discord Embedded MOTD Banner Image (embed.set_image) */}
                  <div className="mb-3 rounded-lg overflow-hidden border border-slate-700/60 bg-[#111214] shadow-md">
                    <div className="bg-[#18191c] px-3 py-1.5 border-b border-slate-800/80 flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-1.5 text-slate-300 font-medium">
                        <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Discord Embed Image • Live In-Game MOTD Banner</span>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/60 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                        embed.set_image
                      </span>
                    </div>
                    <img
                      src={`https://mcapi.us/server/image?ip=${config.java_ip || 'play.wondermc.fun'}`}
                      alt="WonderMc MOTD Banner"
                      className="w-full h-auto object-cover block"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/api/minecraft/banner.svg';
                      }}
                    />
                  </div>

                  <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between text-[11px] text-slate-400">
                    <span>play.wondermc.fun • Server MOTD</span>
                    <span>Synced: {lastRefreshed}</span>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: DEDICATED MOTD IMAGE COMMAND EMBED */}
            {embedTab === 'motd' && (
              <div className="space-y-4">
                <div className="bg-emerald-950/40 border border-emerald-500/30 p-3.5 rounded-xl text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-emerald-300">
                    <ImageIcon className="w-4 h-4 text-emerald-400" />
                    <span><strong>/motd Command:</strong> Official live in-game multiplayer MOTD image banner with custom PIL rendering!</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => copyCodeSnippet('/motd', 'slash_motd')}
                      className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded border border-slate-700 text-[11px] font-mono transition cursor-pointer flex items-center gap-1"
                    >
                      {copiedCode === 'slash_motd' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                      /motd
                    </button>
                    <button
                      onClick={() => copyCodeSnippet('km motd', 'prefix_motd')}
                      className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded border border-slate-700 text-[11px] font-mono transition cursor-pointer flex items-center gap-1"
                    >
                      {copiedCode === 'prefix_motd' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                      wm motd
                    </button>
                  </div>
                </div>

                {/* Discord Embed for /motd */}
                <div className={`bg-[#2b2d31] rounded-lg p-4 text-white font-sans shadow-md border-l-4 ${isOnline ? 'border-emerald-500' : 'border-rose-500'}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-lg bg-emerald-900/60 border border-emerald-700/80 flex items-center justify-center font-bold text-sm text-emerald-300 shadow">
                        ⛏️
                      </div>
                      <div>
                        <div className="font-bold text-sm text-slate-100 flex items-center gap-2">
                          <span>WonderMc • Server MOTD & Live Banner</span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {config.java_ip} (Port: {config.java_port})
                        </div>
                      </div>
                    </div>
                    <img
                      src={`https://api.mcsrvstat.us/icon/${config.java_ip || 'play.wondermc.fun'}`}
                      alt="Server Icon"
                      className="w-10 h-10 rounded border border-slate-700/60 shadow bg-slate-900 object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  </div>

                  <div className="bg-[#1e1f22] p-3 rounded-lg border border-slate-800 text-xs mb-3 space-y-1.5">
                    <div>
                      <span className="text-slate-400">Java Server:</span> <strong className="text-emerald-400 font-mono">{config.java_ip}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400">MOTD Line 1:</span> <span className="text-lime-400 font-mono">{displayLine1}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">MOTD Line 2:</span> <span className="text-slate-200 font-mono">{displayLine2}</span>
                    </div>
                    <div className="pt-1 text-[11px] text-slate-400 flex items-center gap-2">
                      <span>{isOnline ? '🟢 Online' : '🔴 Offline'}</span>
                      <span>•</span>
                      <span>👥 {liveStatus.players.online} / {liveStatus.players.max.toLocaleString()}</span>
                      <span>•</span>
                      <span>📶 {liveStatus.ping} ms</span>
                    </div>
                  </div>

                  {/* High Quality Banner Image */}
                  <div className="rounded-lg overflow-hidden border border-emerald-500/40 bg-[#0e151a] shadow-xl mb-3">
                    <img
                      src={`https://mcapi.us/server/image?ip=${config.java_ip || 'play.wondermc.fun'}`}
                      alt="WonderMc Live MOTD Banner"
                      className="w-full h-auto object-cover block"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/api/minecraft/banner.svg';
                      }}
                    />
                  </div>

                  <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between text-[11px] text-slate-400">
                    <span>WonderMc Network • play.wondermc.fun</span>
                    <span>Direct In-Game Render</span>
                  </div>
                </div>

                {/* Button Bar */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={fetchLiveStatus}
                    disabled={isRefreshingStatus}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded text-xs font-medium shadow transition cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingStatus ? 'animate-spin' : ''}`} />
                    🔄 Refresh MOTD
                  </button>
                  <button
                    onClick={() => copyToClipboard(config.java_ip, 'btn_java')}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#4e5058] hover:bg-[#6d6f78] text-white rounded text-xs font-medium transition cursor-pointer"
                  >
                    ☕ Copy Java IP
                  </button>
                  <button
                    onClick={() => copyToClipboard(`${config.bedrock_ip}:${config.bedrock_port}`, 'btn_bedrock')}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#4e5058] hover:bg-[#6d6f78] text-white rounded text-xs font-medium transition cursor-pointer"
                  >
                    📱 Copy Bedrock IP
                  </button>
                  <a
                    href={`https://mcapi.us/server/image?ip=${config.java_ip || 'play.wondermc.fun'}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded text-xs font-medium transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Open Image in New Tab
                  </a>
                </div>
              </div>
            )}

            {/* TAB: SERVER IP EMBED */}
            {embedTab === 'ip' && (
              <div className="space-y-4">
                <div className="bg-[#2b2d31] rounded-lg p-4 border-l-4 border-emerald-500 text-white font-sans shadow-md">
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-100 mb-2">
                    <span>⛏️ Join WonderMc Minecraft Server!</span>
                  </div>

                  <p className="text-xs text-slate-300 mb-4 leading-relaxed">
                    Welcome to <strong>WonderMc Network</strong>! Connect on both Java Edition and Bedrock Edition (Pocket Edition/Consoles/Windows).
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs mb-4">
                    <div className="bg-[#1e1f22] p-3 rounded border border-slate-800">
                      <div className="font-bold text-emerald-400 mb-1">☕ Java Edition (PC)</div>
                      <div className="text-slate-300 font-mono text-[11px]">IP: {config.java_ip}</div>
                      <div className="text-slate-300 font-mono text-[11px]">Port: 25565</div>
                      <div className="text-slate-400 text-[10px] mt-1">Version: 1.19.x - 1.20.x</div>
                    </div>

                    <div className="bg-[#1e1f22] p-3 rounded border border-slate-800">
                      <div className="font-bold text-cyan-400 mb-1">📱 Bedrock Edition (Mobile/PE/Consoles)</div>
                      <div className="text-slate-300 font-mono text-[11px]">Address: {config.bedrock_ip}</div>
                      <div className="text-slate-300 font-mono text-[11px]">Port: {config.bedrock_port}</div>
                      <div className="text-slate-400 text-[10px] mt-1">Direct Crossplay Enabled</div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between text-[11px] text-slate-400">
                    <span>WonderMc Network • play.wondermc.fun</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={config.store_url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded text-xs font-medium transition"
                  >
                    <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
                    🛒 Webstore
                  </a>
                  <a
                    href={config.vote_url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded text-xs font-medium transition"
                  >
                    <Vote className="w-3.5 h-3.5 text-cyan-400" />
                    🗳️ Vote For Rewards
                  </a>
                </div>
              </div>
            )}

            {/* TAB: RULES EMBED */}
            {embedTab === 'rules' && (
              <div className="bg-[#2b2d31] rounded-lg p-4 border-l-4 border-emerald-500 text-white font-sans shadow-md text-xs space-y-3">
                <div className="font-bold text-sm text-slate-100">📜 WonderMc Official Rules</div>
                <p className="text-slate-300">Please follow all rules on Discord and in-game to ensure a fun experience for everyone:</p>
                <div className="space-y-1.5 text-slate-300">
                  <div>1. <strong>No Hacking / Cheating:</strong> X-Ray, KillAura, Fly, or modified clients are strictly banned.</div>
                  <div>2. <strong>Respect All Members:</strong> Toxic behavior, hate speech, and harassment will not be tolerated.</div>
                  <div>3. <strong>No Spamming or Advertising:</strong> Do not spam chat or promote other Discord servers/IPs.</div>
                  <div>4. <strong>No Duping / Bug Exploiting:</strong> Report any bugs to staff via tickets immediately.</div>
                  <div>5. <strong>Real Money Trading (RMT):</strong> Buying/selling in-game items for real money outside our webstore is prohibited.</div>
                </div>
                <div className="pt-2 border-t border-slate-700/50 text-[11px] text-slate-400">
                  WonderMc Rules & Guidelines
                </div>
              </div>
            )}

            {/* TAB: STORE EMBED */}
            {embedTab === 'store' && (
              <div className="bg-[#2b2d31] rounded-lg p-4 border-l-4 border-amber-500 text-white font-sans shadow-md text-xs space-y-3">
                <div className="font-bold text-sm text-amber-400">🛒 WonderMc Official Store</div>
                <p className="text-slate-300">Support the server and unlock exclusive ranks, keys, cosmetics & perks!</p>
                <div className="bg-[#1e1f22] p-3 rounded border border-slate-800 space-y-1">
                  <div>• <strong className="text-amber-300">VIP</strong> — Fly in lobbies, custom prefix, 2x land claim</div>
                  <div>• <strong className="text-cyan-300">MVP</strong> — MVP particle trails, /wb command, priority queue</div>
                  <div>• <strong className="text-emerald-300">WONDER</strong> — Top tier rank, custom chat colors, unlimited homes & kits!</div>
                </div>
                <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Visit Webstore: <a href={config.store_url} target="_blank" rel="noreferrer" className="text-amber-400 underline">{config.store_url}</a></span>
                </div>
              </div>
            )}

          </div>
        </div>

      </div>

    </div>
  );
}

function SaveIcon(props: any) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
    </svg>
  );
}
