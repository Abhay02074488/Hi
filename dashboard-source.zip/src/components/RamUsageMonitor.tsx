import React, { useState, useEffect } from 'react';
import {
  Cpu,
  HardDrive,
  Activity,
  RefreshCw,
  Server,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Radio,
  Gauge
} from 'lucide-react';
import { SystemMetrics } from '../types';

export const RamUsageMonitor: React.FC = () => {
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [loading, setLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const fetchMetrics = async () => {
    try {
      const res = await fetch('/api/system/metrics');
      const data = await res.json();
      if (data.success) {
        setMetrics(data);
        setLastUpdated(new Date());
      }
    } catch (e) {
      console.error('Error fetching system metrics:', e);
    }
  };

  useEffect(() => {
    fetchMetrics();
    if (!autoRefresh) return;
    const interval = setInterval(fetchMetrics, 3000);
    return () => clearInterval(interval);
  }, [autoRefresh]);

  const handleManualRefresh = async () => {
    setLoading(true);
    await fetchMetrics();
    setLoading(false);
  };

  const memPercent = metrics?.memory?.percentage ?? 42;
  const memColor = memPercent > 85 ? 'text-rose-400' : memPercent > 70 ? 'text-amber-400' : 'text-emerald-400';
  const memBarBg = memPercent > 85 ? 'bg-rose-500' : memPercent > 70 ? 'bg-amber-500' : 'bg-emerald-500';

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Host RAM Usage & Telemetry</h2>
              <p className="text-xs text-slate-400">
                Real-time memory allocation, CPU load, and Python/Node bot hosting specs
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-xs text-slate-300 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 cursor-pointer">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="rounded text-emerald-500 focus:ring-0 focus:outline-none"
            />
            <span>Auto-Refresh (3s)</span>
          </label>

          <button
            onClick={handleManualRefresh}
            disabled={loading}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-medium border border-slate-700 transition cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Main RAM & Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: System RAM Usage */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Total System RAM</span>
            <HardDrive className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl font-extrabold ${memColor}`}>{memPercent}%</span>
            <span className="text-xs text-slate-400">
              ({metrics?.memory?.usedSystemMB || 0} MB / {metrics?.memory?.totalSystemMB || 0} MB)
            </span>
          </div>

          <div className="w-full bg-slate-950 rounded-full h-2 mt-3 overflow-hidden border border-slate-800">
            <div
              className={`h-full ${memBarBg} transition-all duration-500`}
              style={{ width: `${memPercent}%` }}
            />
          </div>

          <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400">
            <span>Free RAM: <strong className="text-slate-200">{metrics?.memory?.freeSystemMB || 0} MB</strong></span>
            <span className="flex items-center gap-1 text-emerald-400 font-medium">
              <CheckCircle2 className="w-3 h-3" /> Healthy
            </span>
          </div>
        </div>

        {/* Card 2: Process RAM (Node & Bot RSS) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Bot Process RAM (RSS)</span>
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-cyan-400">
              {metrics?.memory?.rssMB || 0} <span className="text-sm font-medium text-slate-400">MB</span>
            </span>
          </div>

          <div className="mt-3 space-y-1 text-[11px] text-slate-400">
            <div className="flex justify-between">
              <span>Heap Used:</span>
              <strong className="text-slate-200">{metrics?.memory?.heapUsedMB || 0} MB</strong>
            </div>
            <div className="flex justify-between">
              <span>Heap Allocated:</span>
              <strong className="text-slate-200">{metrics?.memory?.heapTotalMB || 0} MB</strong>
            </div>
          </div>
        </div>

        {/* Card 3: Host CPU Load */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">CPU Load Average</span>
            <Cpu className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-indigo-400">
              {metrics?.cpu?.estimatedUsage || 0}%
            </span>
            <span className="text-xs text-slate-400">({metrics?.cpu?.cores || 2} Cores)</span>
          </div>

          <div className="mt-3 space-y-1 text-[11px] text-slate-400">
            <div className="flex justify-between">
              <span>1m Load:</span>
              <strong className="text-slate-200">{metrics?.cpu?.loadAverage?.[0] || '0.00'}</strong>
            </div>
            <div className="flex justify-between">
              <span>5m Load:</span>
              <strong className="text-slate-200">{metrics?.cpu?.loadAverage?.[1] || '0.00'}</strong>
            </div>
          </div>
        </div>

        {/* Card 4: Bot & Hosting Uptime */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Bot Server Uptime</span>
            <Clock className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-extrabold text-white">
            {metrics?.system?.uptime || 'Online'}
          </div>

          <div className="mt-3 space-y-1 text-[11px] text-slate-400">
            <div className="flex justify-between">
              <span>Discord Gateway Ping:</span>
              <strong className="text-emerald-400">{metrics?.bot?.gatewayLatency || 38} ms</strong>
            </div>
            <div className="flex justify-between">
              <span>Loaded Cogs:</span>
              <strong className="text-slate-200">{metrics?.bot?.cogsLoaded || 15} Modules</strong>
            </div>
          </div>
        </div>

      </div>

      {/* Detailed Host & Process Info Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left: Host Environment Specifications */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
          <h3 className="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <Server className="w-4 h-4 text-emerald-400" />
            Hosting Server Specifications
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">Operating System</span>
              <span className="font-mono font-medium text-slate-200">
                {metrics?.system?.osType || 'Linux'} ({metrics?.system?.platform || 'linux'} / {metrics?.system?.arch || 'x64'})
              </span>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">CPU Model</span>
              <span className="font-mono text-slate-200 truncate max-w-[240px]">
                {metrics?.cpu?.model || 'Intel Xeon / AMD EPYC'}
              </span>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">Node.js Runtime</span>
              <span className="font-mono text-emerald-400">
                {metrics?.system?.nodeVersion || 'v20.x'}
              </span>
            </div>

            <div className="flex items-center justify-between py-2">
              <span className="text-slate-400">Web & Bot Port</span>
              <span className="font-mono text-cyan-400">:3000 (Internal & HTTP Proxy)</span>
            </div>
          </div>
        </div>

        {/* Right: Discord Bot Live Runtime Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
          <h3 className="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400" />
            Discord Bot Process Telemetry
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">Bot Connection State</span>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                ONLINE • Connected
              </span>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">Gateway Shards</span>
              <span className="font-mono text-slate-200">
                {metrics?.bot?.activeShards || 1} Shard Active
              </span>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">Total Discord Guilds</span>
              <span className="font-mono font-medium text-slate-200">
                {metrics?.bot?.guildsCount || 4} Guilds
              </span>
            </div>

            <div className="flex items-center justify-between py-2">
              <span className="text-slate-400">Telemetry Last Updated</span>
              <span className="text-slate-400 font-mono">
                {lastUpdated.toLocaleTimeString()}
              </span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
