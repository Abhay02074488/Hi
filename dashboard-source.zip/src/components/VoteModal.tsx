import React from 'react';
import { X, Vote, ExternalLink, Gift, Award, CheckCircle2 } from 'lucide-react';
import { DEFAULT_VOTE_SITES } from '../data/storeData';

interface VoteModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VoteModal: React.FC<VoteModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl z-10 my-8">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Vote className="w-3.5 h-3.5" /> Support the Server
          </div>
          <h2 className="text-2xl font-black text-white">Vote for WonderMc</h2>
          <p className="text-sm text-slate-400 mt-1">
            Vote daily to receive free in-game crate keys, diamonds, and server coins!
          </p>
        </div>

        {/* Reward Highlight */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 to-yellow-500/10 border border-amber-500/20 flex items-center gap-3.5 mb-6">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
            <Gift className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Daily Voting Rewards</h4>
            <p className="text-xs text-slate-300">
              Receive <strong>1x Vote Key</strong> and <strong>5,000 Coins</strong> per vote link every 24 hours.
            </p>
          </div>
        </div>

        {/* Voting Links */}
        <div className="space-y-3">
          {DEFAULT_VOTE_SITES.map((site, idx) => (
            <a
              key={site.id}
              href={site.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-amber-500/40 flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-lg bg-slate-700 text-slate-300 text-xs font-bold flex items-center justify-center">
                  #{idx + 1}
                </span>
                <div>
                  <h5 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                    {site.name}
                  </h5>
                  <span className="text-[11px] text-emerald-400 font-medium">
                    {site.reward}
                  </span>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors" />
            </a>
          ))}
        </div>

        <p className="mt-6 text-center text-[11px] text-slate-500">
          Make sure your Minecraft account is logged into WonderMc when voting to receive instant crate keys!
        </p>
      </div>
    </div>
  );
};
