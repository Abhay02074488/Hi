import React, { useState, useEffect } from 'react';
import {
  Shield,
  AlertTriangle,
  Search,
  CheckCircle2,
  XCircle,
  UserCheck,
  RefreshCw,
  Settings,
  Hash,
  MessageSquare,
  ClipboardList,
  Eye,
  Clock,
  Gamepad2,
  Link2,
  Save,
  Copy,
  Check
} from 'lucide-react';
import { useToast } from '../context/ToastContext';

/* ── Types ─────────────────────────────────────────────── */

type ComplaintStatus = 'pending' | 'claimed' | 'investigating' | 'resolved' | 'rejected';

interface Complaint {
  id: string;
  reported_by: string;
  reported_by_id?: string;
  minecraft_username: string;
  complaint_type: string;
  server_mode: string;
  description: string;
  evidence?: string;
  status: ComplaintStatus;
  claimed_by?: string;
  reason?: string;
  submitted_at: string;
  reviewed_at?: string;
}

interface ComplaintsConfig {
  channel_id: string;
  channel_name?: string;
  enabled: boolean;
  auto_response_enabled: boolean;
  staff_role_id?: string;
}

const COMPLAINT_TYPES = [
  'Hacking',
  'Cheating',
  'Abusing',
  'Scamming',
  'Bug Abuse',
  'Teaming',
  'Other'
];

const SERVER_MODES = ['Lifesteal', 'Practice', 'Other'];

const STATUS_COLORS: Record<ComplaintStatus, string> = {
  pending: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
  claimed: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
  investigating: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
  resolved: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
  rejected: 'bg-rose-500/20 text-rose-300 border-rose-500/40'
};

const STATUS_LABELS: Record<ComplaintStatus, string> = {
  pending: 'Pending',
  claimed: 'Claimed',
  investigating: 'Investigating',
  resolved: 'Resolved',
  rejected: 'Rejected'
};

/* ── Component ─────────────────────────────────────────── */

export const MinecraftComplaintsManager: React.FC = () => {
  const { showToast } = useToast();

  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [config, setConfig] = useState<ComplaintsConfig>({
    channel_id: '',
    enabled: true,
    auto_response_enabled: true
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState<'all' | ComplaintStatus>('all');
  const [selected, setSelected] = useState<Complaint | null>(null);
  const [actionReason, setActionReason] = useState('');
  const [copied, setCopied] = useState(false);

  // Channel setting form
  const [channelInput, setChannelInput] = useState('');

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [cRes, confRes] = await Promise.all([
        fetch('/api/complaints'),
        fetch('/api/complaints/config')
      ]);
      if (cRes.ok) {
        const data = await cRes.json();
        setComplaints(data.complaints || data || []);
      }
      if (confRes.ok) {
        const conf = await confRes.json();
        setConfig(conf);
        setChannelInput(conf.channel_id || '');
      }
    } catch (e) {
      console.error(e);
      // Demo data so UI is usable even without backend
      setComplaints([
        {
          id: 'MC-1001',
          reported_by: 'Avihaan_PvP',
          minecraft_username: 'ExamplePlayer',
          complaint_type: 'Hacking',
          server_mode: 'Practice',
          description: 'Suspected of using reach and velocity hacks in ranked matches.',
          evidence: 'https://example.com/evidence.mp4',
          status: 'pending',
          submitted_at: new Date(Date.now() - 3600000 * 2).toISOString()
        },
        {
          id: 'MC-1002',
          reported_by: 'ShadowKing',
          minecraft_username: 'ToxicPvP99',
          complaint_type: 'Abusing',
          server_mode: 'Lifesteal',
          description: 'Constantly using racial slurs and harassing other players.',
          status: 'claimed',
          claimed_by: 'StaffMember',
          submitted_at: new Date(Date.now() - 3600000 * 8).toISOString()
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const saveConfig = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/complaints/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...config,
          channel_id: channelInput.trim()
        })
      });
      if (res.ok) {
        const updated = await res.json();
        setConfig(updated);
        showToast('Complaint channel settings saved', 'success');
      } else {
        // Optimistic local save for demo
        setConfig(prev => ({ ...prev, channel_id: channelInput.trim() }));
        showToast('Settings saved (local)', 'success');
      }
    } catch {
      setConfig(prev => ({ ...prev, channel_id: channelInput.trim() }));
      showToast('Settings saved locally', 'success');
    } finally {
      setSaving(false);
    }
  };

  const updateStatus = async (id: string, status: ComplaintStatus, reason?: string) => {
    try {
      const res = await fetch(`/api/complaints/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, reason })
      });
      if (res.ok) {
        const updated = await res.json();
        setComplaints(prev => prev.map(c => (c.id === id ? { ...c, ...updated } : c)));
        setSelected(null);
        setActionReason('');
        showToast(`Complaint marked as ${STATUS_LABELS[status]}`, 'success');
      } else {
        // Optimistic update
        setComplaints(prev =>
          prev.map(c =>
            c.id === id
              ? { ...c, status, reason, reviewed_at: new Date().toISOString() }
              : c
          )
        );
        setSelected(null);
        setActionReason('');
        showToast(`Complaint marked as ${STATUS_LABELS[status]}`, 'success');
      }
    } catch {
      setComplaints(prev =>
        prev.map(c =>
          c.id === id
            ? { ...c, status, reason, reviewed_at: new Date().toISOString() }
            : c
        )
      );
      setSelected(null);
      setActionReason('');
      showToast(`Complaint marked as ${STATUS_LABELS[status]}`, 'success');
    }
  };

  const filtered = filter === 'all' ? complaints : complaints.filter(c => c.status === filter);

  const copyTemplate = () => {
    const tpl = `🚨 WONDER MC | NEW PLAYER COMPLAINT

A new complaint has been submitted against a Minecraft player! ⚠️

Our staff team is requested to review the complaint, verify the evidence, and take appropriate action according to the server rules.

━━━━━━━━━━━━━━━━━━━━

🆔 Complaint ID
#{id}

👤 Reported By
@{reported_by}

🎮 Minecraft Username
{minecraft_username}

⚔️ Complaint Category
{complaint_type}

🌍 Server Mode
{server_mode}

📝 Complaint Description
{description}

📸 Evidence
{evidence}

📊 Current Status
🟡 Pending Review

🕒 Submitted At
{submitted_at}

━━━━━━━━━━━━━━━━━━━━

🛡️ STAFF NOTICE

Please investigate this complaint fairly before making a decision. Ensure the evidence is reviewed and all actions follow WONDER MC server rules.

⚠️ Do not take action based solely on an unverified accusation.

💙 WONDER MC STAFF TEAM
Fair Play • Justice • Community`;
    navigator.clipboard.writeText(tpl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    showToast('Auto-response template copied', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-black text-white sm:text-3xl">
            <Shield className="h-7 w-7 text-amber-400" />
            Minecraft Complaints
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Manage player reports, staff actions, and Discord notification channel
          </p>
        </div>
        <button
          onClick={loadAll}
          className="flex items-center gap-2 rounded-xl bg-slate-800 px-4 py-2.5 text-sm font-bold text-slate-200 transition hover:bg-slate-700"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Channel Settings */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
        <div className="mb-4 flex items-center gap-2">
          <Settings className="h-5 w-5 text-emerald-400" />
          <h2 className="font-black text-white">Complaint Channel Settings</h2>
        </div>
        <p className="mb-4 text-sm text-slate-400">
          Jab koi player <code className="rounded bg-slate-800 px-1.5 py-0.5 text-emerald-300">/complain</code> use karega,
          naya complaint is channel pe staff panel (buttons ke saath) ke form mein aayega.
        </p>

        <div className="grid gap-4 sm:grid-cols-[1fr_auto]">
          <div>
            <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-500">
              Discord Channel ID
            </label>
            <div className="relative">
              <Hash className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                value={channelInput}
                onChange={e => setChannelInput(e.target.value)}
                placeholder="e.g. 1234567890123456789"
                className="w-full rounded-xl border border-slate-700 bg-slate-950 py-2.5 pl-10 pr-4 text-sm text-white placeholder:text-slate-600 focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>
          <div className="flex items-end">
            <button
              onClick={saveConfig}
              disabled={saving}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 px-5 py-2.5 text-sm font-bold text-slate-950 transition hover:bg-emerald-400 disabled:opacity-60 sm:w-auto"
            >
              <Save className="h-4 w-4" />
              {saving ? 'Saving…' : 'Save Channel'}
            </button>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-4">
          <label className="flex cursor-pointer items-center gap-2.5 text-sm font-bold text-slate-300">
            <span
              className={`relative h-6 w-11 rounded-full transition ${config.enabled ? 'bg-emerald-500' : 'bg-slate-700'}`}
              onClick={() => setConfig(p => ({ ...p, enabled: !p.enabled }))}
            >
              <span
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${config.enabled ? 'left-[22px]' : 'left-0.5'}`}
              />
            </span>
            System Enabled
          </label>
          <label className="flex cursor-pointer items-center gap-2.5 text-sm font-bold text-slate-300">
            <span
              className={`relative h-6 w-11 rounded-full transition ${config.auto_response_enabled ? 'bg-emerald-500' : 'bg-slate-700'}`}
              onClick={() => setConfig(p => ({ ...p, auto_response_enabled: !p.auto_response_enabled }))}
            >
              <span
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${config.auto_response_enabled ? 'left-[22px]' : 'left-0.5'}`}
              />
            </span>
            Auto Response to Reporter
          </label>
        </div>
      </div>

      {/* Auto Response Template Preview */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-blue-400" />
            <h2 className="font-black text-white">Staff Notification Template</h2>
          </div>
          <button
            onClick={copyTemplate}
            className="flex items-center gap-1.5 rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-bold text-slate-300 hover:bg-slate-700"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? 'Copied' : 'Copy Template'}
          </button>
        </div>
        <div className="max-h-48 overflow-y-auto rounded-xl bg-slate-950 p-4 font-mono text-xs leading-relaxed text-slate-400">
          🚨 WONDER MC | NEW PLAYER COMPLAINT<br /><br />
          A new complaint has been submitted…<br />
          🆔 Complaint ID • 👤 Reported By • 🎮 Minecraft Username<br />
          ⚔️ Category • 🌍 Mode • 📝 Description • 📸 Evidence<br />
          📊 Status: 🟡 Pending Review
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {(['all', 'pending', 'claimed', 'investigating', 'resolved', 'rejected'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-xl px-3.5 py-2 text-sm font-bold transition ${
              filter === f
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {f === 'all' ? 'All' : STATUS_LABELS[f]}
            {f !== 'all' && (
              <span className="ml-1.5 opacity-70">
                ({complaints.filter(c => c.status === f).length})
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Complaints List + Staff Panel Preview */}
      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        {/* List */}
        <div className="space-y-3">
          {loading ? (
            <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-500">
              Loading complaints…
            </div>
          ) : filtered.length === 0 ? (
            <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-12 text-center">
              <ClipboardList className="mx-auto h-10 w-10 text-slate-600" />
              <p className="mt-3 font-bold text-slate-400">No complaints found</p>
            </div>
          ) : (
            filtered.map(c => (
              <div
                key={c.id}
                onClick={() => setSelected(c)}
                className={`cursor-pointer rounded-2xl border p-4 transition ${
                  selected?.id === c.id
                    ? 'border-emerald-500/50 bg-emerald-950/20'
                    : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-white">Report #{c.id}</span>
                      <span
                        className={`rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase ${STATUS_COLORS[c.status]}`}
                      >
                        {STATUS_LABELS[c.status]}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-slate-400">
                      <Gamepad2 className="mr-1 inline h-3.5 w-3.5" />
                      {c.minecraft_username}
                      <span className="mx-2 text-slate-600">•</span>
                      {c.complaint_type}
                      <span className="mx-2 text-slate-600">•</span>
                      {c.server_mode}
                    </p>
                  </div>
                  <span className="flex items-center gap-1 text-xs text-slate-500">
                    <Clock className="h-3.5 w-3.5" />
                    {new Date(c.submitted_at).toLocaleString()}
                  </span>
                </div>
                <p className="mt-2 line-clamp-2 text-sm text-slate-300">{c.description}</p>
              </div>
            ))
          )}
        </div>

        {/* Staff Panel (matches the design user shared) */}
        <div className="lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-xl">
            <div className="mb-4 flex items-center gap-2">
              <Shield className="h-5 w-5 text-amber-400" />
              <h3 className="font-black text-white">Staff Complaint Panel</h3>
            </div>

            {selected ? (
              <>
                <div className="mb-4 space-y-2 rounded-xl bg-slate-950/80 p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-white">Report #{selected.id}</span>
                    <span
                      className={`rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase ${STATUS_COLORS[selected.status]}`}
                    >
                      {STATUS_LABELS[selected.status]}
                    </span>
                  </div>
                  <p className="text-sm text-slate-400">
                    Minecraft Player: <span className="font-bold text-slate-200">{selected.minecraft_username}</span>
                  </p>
                  <p className="text-sm">
                    <span className="text-slate-500">Type:</span>{' '}
                    <span className="font-bold text-white">{selected.complaint_type}</span>
                  </p>
                  <p className="text-sm">
                    <span className="text-slate-500">Mode:</span>{' '}
                    <span className="font-bold text-white">{selected.server_mode}</span>
                  </p>
                  {selected.evidence && (
                    <p className="text-sm">
                      <span className="text-slate-500">Evidence:</span>{' '}
                      <a
                        href={selected.evidence}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 font-bold text-emerald-400 hover:underline"
                      >
                        <Link2 className="h-3.5 w-3.5" /> View Evidence
                      </a>
                    </p>
                  )}
                  <p className="mt-2 text-sm text-slate-300">{selected.description}</p>
                </div>

                {(selected.status === 'resolved' || selected.status === 'rejected') && selected.reason && (
                  <div className="mb-4 rounded-xl border border-slate-700 bg-slate-950/50 p-3 text-sm text-slate-300">
                    <span className="font-bold text-slate-400">Reason:</span> {selected.reason}
                  </div>
                )}

                {selected.status !== 'resolved' && selected.status !== 'rejected' && (
                  <>
                    <input
                      value={actionReason}
                      onChange={e => setActionReason(e.target.value)}
                      placeholder="Reason (optional for claim/investigate)"
                      className="mb-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white placeholder:text-slate-600 focus:border-emerald-500 focus:outline-none"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => updateStatus(selected.id, 'claimed')}
                        className="flex flex-col items-center gap-1.5 rounded-xl bg-slate-800 py-3 text-sm font-bold text-slate-200 transition hover:bg-blue-600/30 hover:text-blue-300"
                      >
                        <UserCheck className="h-5 w-5" />
                        Claim Report
                      </button>
                      <button
                        onClick={() => updateStatus(selected.id, 'investigating')}
                        className="flex flex-col items-center gap-1.5 rounded-xl bg-slate-800 py-3 text-sm font-bold text-slate-200 transition hover:bg-purple-600/30 hover:text-purple-300"
                      >
                        <Search className="h-5 w-5" />
                        Investigate
                      </button>
                      <button
                        onClick={() => updateStatus(selected.id, 'resolved', actionReason || 'Resolved by staff')}
                        className="flex flex-col items-center gap-1.5 rounded-xl bg-slate-800 py-3 text-sm font-bold text-slate-200 transition hover:bg-emerald-600/30 hover:text-emerald-300"
                      >
                        <CheckCircle2 className="h-5 w-5" />
                        Resolve
                      </button>
                      <button
                        onClick={() => updateStatus(selected.id, 'rejected', actionReason || 'Rejected')}
                        className="flex flex-col items-center gap-1.5 rounded-xl bg-slate-800 py-3 text-sm font-bold text-slate-200 transition hover:bg-rose-600/30 hover:text-rose-300"
                      >
                        <XCircle className="h-5 w-5" />
                        Reject
                      </button>
                    </div>
                  </>
                )}
              </>
            ) : (
              <div className="py-10 text-center text-slate-500">
                <Eye className="mx-auto h-8 w-8 opacity-40" />
                <p className="mt-2 text-sm">Select a complaint to view the staff panel</p>
              </div>
            )}
          </div>

          {/* Discord Panel Preview note */}
          <p className="mt-3 text-center text-xs text-slate-500">
            Yehi panel Discord channel pe buttons ke saath aayega jab naya complaint submit hoga.
          </p>
        </div>
      </div>

      {/* Command Reference */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
        <h3 className="mb-3 font-black text-white">Player Command</h3>
        <div className="rounded-xl bg-slate-950 p-4 font-mono text-sm text-emerald-300">
          /complain
        </div>
        <ul className="mt-3 space-y-1.5 text-sm text-slate-400">
          <li>• <strong className="text-slate-200">Minecraft Username</strong> — jis player ki report karni hai</li>
          <li>• <strong className="text-slate-200">Complaint Type</strong> — Hacking, Cheating, Abusing, Scamming, Bug Abuse, Teaming, Other</li>
          <li>• <strong className="text-slate-200">Evidence</strong> — video / screenshot link (optional ya required)</li>
          <li>• <strong className="text-slate-200">Description</strong> — kya hua aur kab hua</li>
          <li>• <strong className="text-slate-200">Server Mode</strong> — Lifesteal, Practice, Other</li>
        </ul>
      </div>
    </div>
  );
};
