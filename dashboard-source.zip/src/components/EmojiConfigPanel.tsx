import React, { useState, useEffect } from 'react';
import {
  Smile,
  Save,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Coins,
  Ticket,
  ShoppingCart,
  Scale,
  Flag,
  Sparkles,
  HelpCircle,
  ExternalLink
} from 'lucide-react';

interface EmojiItem {
  key: string;
  name: string;
  description: string;
  category: 'economy' | 'tickets' | 'server';
  fallback: string;
  value: string;
}

const DEFAULT_EMOJIS: Record<string, string> = {
  cash: "<a:cash:1547257472862003271>",
  crystal: "<a:cash:1547257472862003271>",
  alt_currency: "💸",
  bank: "🏦",
  ticket: "<a:ticket:1547256687264538794>",
  cart: "<:cart:1547256912972611694>",
  store: "🛍️",
  appeal: "<a:appeal:1547256684592763031>",
  report: "<a:report:1547257467325649016>",
  shield: "<a:report:1547257467325649016>",
  gift: "<a:gift:1547257528352509953>",
  sparkles: "<a:gift:1547257528352509953>",
  trophy: "<a:trophy:1547257832146079815>",
  announce: "<a:ticket:1547256687264538794>",
  book: "<a:cash:1547257472862003271>",
  bug: "🐛"
};

export const EmojiConfigPanel: React.FC = () => {
  const [emojis, setEmojis] = useState<Record<string, string>>(DEFAULT_EMOJIS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<{ success: boolean; message: string } | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'all' | 'economy' | 'tickets' | 'server'>('all');

  useEffect(() => {
    fetchEmojis();
  }, []);

  const fetchEmojis = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/data/emojis');
      const json = await res.json();
      if (json.success && json.data) {
        setEmojis({ ...DEFAULT_EMOJIS, ...json.data });
      }
    } catch (e) {
      console.error("Failed to load emojis:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setSaveStatus(null);
    try {
      const res = await fetch('/api/data/emojis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(emojis)
      });
      const json = await res.json();
      if (json.success) {
        setSaveStatus({ success: true, message: 'Custom emojis saved and synced with Python bot!' });
        setTimeout(() => setSaveStatus(null), 4000);
      } else {
        setSaveStatus({ success: false, message: json.error || 'Failed to save emojis' });
      }
    } catch (e: any) {
      setSaveStatus({ success: false, message: e.message || 'Network error saving emojis' });
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (key: string, val: string) => {
    setEmojis(prev => ({ ...prev, [key]: val.trim() }));
  };

  // Helper to extract Discord CDN image if custom emoji format <:name:id> or <a:name:id>
  const renderEmojiVisual = (val: string, fallback: string) => {
    const match = val.match(/<(a)?:([a-zA-Z0-9_]+):([0-9]+)>/);
    if (match) {
      const emojiId = match[3];
      const isAnimated = match[1] === 'a' || [
        '1547256687264538794',
        '1547256684592763031',
        '1547257467325649016',
        '1547257528352509953',
        '1547257832146079815',
        '1547257472862003271'
      ].includes(emojiId);
      const ext = isAnimated ? 'gif' : 'webp';
      const cdnUrl = `https://cdn.discordapp.com/emojis/${emojiId}.${ext}?size=48&quality=lossless`;
      return (
        <img
          src={cdnUrl}
          alt={match[2]}
          className="w-6 h-6 object-contain inline-block align-middle"
          onError={(e) => {
            // If custom emoji fails to load in browser, fall back to fallback text
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      );
    }
    return <span className="text-lg">{val || fallback}</span>;
  };

  const emojiDefinitions: EmojiItem[] = [
    {
      key: "blue_orb",
      name: "Blue Crystal Orb (1000611904)",
      description: "Glowing blue crystal/orb uploaded in Developer Portal. Used for staff application bullet points and requirements.",
      category: "server",
      fallback: "🔹",
      value: emojis.blue_orb || "<a:1000611904:1551154796445040720>"
    },
    {
      key: "blue_quill",
      name: "Blue Feather Quill / Pen (1000611902)",
      description: "Blue writing quill uploaded in Developer Portal. Used for application headers, review cards, and apply button.",
      category: "server",
      fallback: "🖋️",
      value: emojis.blue_quill || "<a:1000611902:1551154801008443474>"
    },
    {
      key: "question",
      name: "Glowing Question Mark (1000611903)",
      description: "Golden question mark uploaded in Developer Portal. Used in staff application questions and prompt cards.",
      category: "server",
      fallback: "❓",
      value: emojis.question || "<a:1000611903:1551154798655569930>"
    },
    {
      key: "book",
      name: "Purple Enchanted Book (1000611263)",
      description: "Purple book uploaded in Developer Portal. Used for server rules and guides.",
      category: "server",
      fallback: "📖",
      value: emojis.book || "<a:1000611263:1550711518629339207>"
    },
    {
      key: "cash",
      name: "Cash / Main Currency (Animated Crystal)",
      description: "Used in /balance, /daily, /work, embeds, balance fields, and transactions.",
      category: "economy",
      fallback: "💵",
      value: emojis.cash || "<a:cash:1547257472862003271>"
    },
    {
      key: "crystal",
      name: "Crystal / Gem Bullet Icon",
      description: "Used for list bullet points, staff application requirements, and diamond embeds.",
      category: "server",
      fallback: "🔮",
      value: emojis.crystal || "<a:cash:1547257472862003271>"
    },
    {
      key: "alt_currency",
      name: "Secondary Cash / Flow",
      description: "Used for quick deposits, earnings, and payout alerts.",
      category: "economy",
      fallback: "💸",
      value: emojis.alt_currency || "💸"
    },
    {
      key: "bank",
      name: "Bank Vault Icon",
      description: "Used in bank balances, deposits, and vaults.",
      category: "economy",
      fallback: "🏦",
      value: emojis.bank || "🏦"
    },
    {
      key: "announce",
      name: "Announcement / Header Icon",
      description: "Used in staff application panels, server announcements, and broadcast headers.",
      category: "server",
      fallback: "📢",
      value: emojis.announce || "<a:ticket:1547256687264538794>"
    },
    {
      key: "trophy",
      name: "Trophy / Leaderboard (Animated)",
      description: "Used in economy rankings, rewards, and giveaway winner announcements.",
      category: "server",
      fallback: "🏆",
      value: emojis.trophy || "<a:trophy:1547257832146079815>"
    },
    {
      key: "gift",
      name: "Gift / Reward (Animated)",
      description: "Used in giveaways, level-up rewards, and donation perks.",
      category: "server",
      fallback: "🎁",
      value: emojis.gift || "<a:gift:1547257528352509953>"
    },
    {
      key: "sparkles",
      name: "Sparkles / Highlight (Animated)",
      description: "Used in application embeds, congratulations notices, and welcome cards.",
      category: "server",
      fallback: "✨",
      value: emojis.sparkles || "<a:gift:1547257528352509953>"
    },
    {
      key: "shield",
      name: "Security Shield (Animated)",
      description: "Used in staff application title, anti-nuke notices, and moderation embeds.",
      category: "server",
      fallback: "🛡️",
      value: emojis.shield || "<a:report:1547257467325649016>"
    },
    {
      key: "book",
      name: "Rules & Guidelines Icon",
      description: "Used in application question listings, rules, and documentation.",
      category: "server",
      fallback: "📖",
      value: emojis.book || "<a:cash:1547257472862003271>"
    },
    {
      key: "cart",
      name: "Store & Shopping Cart",
      description: "Custom shopping cart emoji used in Ticket Category select menu and Store Panel button.",
      category: "tickets",
      fallback: "🛒",
      value: emojis.cart || "<:cart:1547256912972611694>"
    },
    {
      key: "ticket",
      name: "General Ticket / Support (Animated)",
      description: "Animated custom emoji used in ticket panel description, embed headers, and select menu.",
      category: "tickets",
      fallback: "📓",
      value: emojis.ticket || "<a:ticket:1547256687264538794>"
    },
    {
      key: "appeal",
      name: "Appeal Category (Animated Hammer)",
      description: "Animated hammer emoji used in Appeal category in ticket selection menu and appeal ticket embeds.",
      category: "tickets",
      fallback: "🔨",
      value: emojis.appeal || "<a:appeal:1547256684592763031>"
    },
    {
      key: "report",
      name: "Report Category (Animated Red Shield)",
      description: "Animated red shield emoji used in Player Report category and report ticket embeds.",
      category: "tickets",
      fallback: "🚨",
      value: emojis.report || "<a:report:1547257467325649016>"
    },
    {
      key: "bug",
      name: "Bug Report Category",
      description: "Used in Bug Report ticket category, dropdown menus, and bug ticket embeds.",
      category: "tickets",
      fallback: "🐛",
      value: emojis.bug || "🐛"
    }
  ];

  const filteredItems = activeSubTab === 'all'
    ? emojiDefinitions
    : emojiDefinitions.filter(e => e.category === activeSubTab);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-2xl p-5 sm:p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Smile className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Custom Discord Emojis Manager
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  LIVE SYNC
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Paste your server custom emojis (<code className="text-emerald-300">&lt;:name:id&gt;</code> or <code className="text-emerald-300">&lt;a:name:id&gt;</code>) to replace default unicode emojis in the ticket panel & economy embeds.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                const standard = {
                  cash: "💵",
                  alt_currency: "💸",
                  bank: "🏦",
                  ticket: "📓",
                  cart: "🛒",
                  store: "🛍️",
                  appeal: "🔨",
                  report: "🚨",
                  bug: "🐛"
                };
                setEmojis(standard);
              }}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
              title="Reset all emojis to clean standard emojis that work without external emoji permissions"
            >
              Reset to Standard
            </button>
            <button
              onClick={fetchEmojis}
              disabled={loading}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Reload
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              {saving ? 'Saving...' : 'Save & Sync Bot'}
            </button>
          </div>
        </div>

        {saveStatus && (
          <div className={`mt-4 p-3 rounded-xl border text-xs flex items-center gap-2 ${
            saveStatus.success
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}>
            {saveStatus.success ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{saveStatus.message}</span>
          </div>
        )}
      </div>

      {/* Discord Emoji Permission & Troubleshooting Banner */}
      <div className="bg-amber-950/30 border border-amber-500/40 rounded-xl p-4 text-xs text-amber-200/90 space-y-2">
        <div className="flex items-center gap-2 font-bold text-amber-300 text-sm">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Why are custom emojis showing as text like <code className="bg-amber-950/80 px-1 py-0.5 rounded text-amber-200">:cash:</code> instead of images?</span>
        </div>
        <p className="leading-relaxed text-slate-300">
          In Discord, if an emoji is uploaded to the Discord Developer Portal (Application Emojis) or an external server, 
          the bot <strong>must have the "Use External Emojis" permission</strong> in your Discord server. Without this permission, Discord hides the emoji image and prints raw text.
        </p>
        <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800/80 space-y-1.5 font-mono text-[11px] text-slate-300">
          <p className="text-emerald-400 font-bold font-sans">Quick Fix in 2 Steps:</p>
          <p>1. Go to <strong>Server Settings &gt; Roles &gt; WONDER MC</strong> (bot role) &gt; <strong>Permissions</strong> &gt; Enable <strong>"Use External Emojis"</strong>.</p>
          <p>2. Or use emojis uploaded to your own server! Type <code className="text-cyan-300">wm scan</code> in Discord to list all emojis in your server, then set them with <code className="text-cyan-300">wm setemoji cash &lt;paste emoji&gt;</code>.</p>
        </div>
      </div>

      {/* How to get Discord Custom Emojis Quick Hint */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 text-xs text-slate-400 flex items-start gap-3">
        <HelpCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-slate-200 font-semibold">How to get your Discord Custom Emoji code:</p>
          <p>
            In any Discord channel, type a backslash followed by your custom emoji, e.g. <code className="bg-slate-950 px-1.5 py-0.5 rounded text-cyan-300">\:cash:</code> or <code className="bg-slate-950 px-1.5 py-0.5 rounded text-cyan-300">\:wondermc_cart:</code> and send it. Discord will output the exact code like <code className="bg-slate-950 px-1.5 py-0.5 rounded text-emerald-300">&lt;:cash:123456789012345678&gt;</code>. Copy and paste that string into the field below!
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveSubTab('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
            activeSubTab === 'all'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          All Emojis ({emojiDefinitions.length})
        </button>
        <button
          onClick={() => setActiveSubTab('economy')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
            activeSubTab === 'economy'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Economy & Cash ({emojiDefinitions.filter(e => e.category === 'economy').length})
        </button>
        <button
          onClick={() => setActiveSubTab('tickets')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
            activeSubTab === 'tickets'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Ticket Panel & Support ({emojiDefinitions.filter(e => e.category === 'tickets').length})
        </button>
        <button
          onClick={() => setActiveSubTab('server')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
            activeSubTab === 'server'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Staff & Announcements ({emojiDefinitions.filter(e => e.category === 'server').length})
        </button>
      </div>

      {/* Emojis Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredItems.map(item => (
          <div
            key={item.key}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between hover:border-slate-700 transition space-y-3"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  {item.name}
                  <code className="text-[10px] text-slate-500 font-mono">({item.key})</code>
                </span>
                <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{item.description}</p>
              </div>

              {/* Preview badge */}
              <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center shrink-0 shadow-inner">
                {renderEmojiVisual(emojis[item.key] || item.fallback, item.fallback)}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                Emoji Value (Custom &lt;:name:id&gt; or standard emoji)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={emojis[item.key] || ""}
                  placeholder={item.fallback}
                  onChange={(e) => handleChange(item.key, e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => handleChange(item.key, item.fallback)}
                  className="px-2.5 py-2 bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-400 hover:text-white rounded-xl border border-slate-700 transition cursor-pointer"
                  title="Reset to default"
                >
                  Reset
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Live Previews of Discord Embeds */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
        
        {/* Economy Embed Preview */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
              <Coins className="w-4 h-4 text-emerald-400" />
              Discord Preview: /balance & Economy Embed
            </span>
            <span className="text-[10px] text-slate-500 font-mono">WonderMc Economy</span>
          </div>

          <div className="bg-[#2B2D31] rounded-xl p-4 border-l-4 border-[#2ECC71] text-slate-200 space-y-3 text-xs shadow-inner">
            <div className="flex items-center gap-2 font-bold text-white text-sm">
              <span>{renderEmojiVisual(emojis.cash || "💵", "💵")} Avihaan's WonderMc Balance</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Rank: <span className="text-[#00FFFF] font-semibold">#1 (Immortal)</span> • Status: <span className="text-emerald-400">Wealth Titan</span>
            </p>

            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-700/50">
              <div className="bg-[#1E1F22] p-2 rounded-lg">
                <span className="text-[10px] text-slate-400 flex items-center gap-1 font-semibold">
                  {renderEmojiVisual(emojis.cash || "💵", "💵")} Cash in Wallet
                </span>
                <p className="text-sm font-bold text-white mt-0.5 flex items-center gap-1">
                  {renderEmojiVisual(emojis.cash || "💵", "💵")} 1,450,000
                </p>
              </div>

              <div className="bg-[#1E1F22] p-2 rounded-lg">
                <span className="text-[10px] text-slate-400 flex items-center gap-1 font-semibold">
                  {renderEmojiVisual(emojis.bank || "🏦", "🏦")} Bank Vault
                </span>
                <p className="text-sm font-bold text-white mt-0.5 flex items-center gap-1">
                  {renderEmojiVisual(emojis.cash || "💵", "💵")} 8,200,000
                </p>
              </div>
            </div>

            <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1">
              <span>WonderMc Economy • play.wondermc.fun</span>
              <span className="text-emerald-400 font-semibold">Net: 9.65M</span>
            </div>
          </div>
        </div>

        {/* Ticket Panel Preview */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
              <Ticket className="w-4 h-4 text-cyan-400" />
              Discord Preview: /ticket panel Category Menu
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Interactive Panel</span>
          </div>

          <div className="bg-[#2B2D31] rounded-xl p-4 border-l-4 border-[#00FFFF] text-slate-200 space-y-3 text-xs shadow-inner">
            <div className="flex items-center gap-2 font-bold text-white text-sm">
              <span className="text-base">🎫</span>
              <span>WonderMc Support Ticket</span>
            </div>
            <div className="flex items-center gap-2 font-semibold text-white text-xs">
              {renderEmojiVisual(emojis.ticket || "📓", "📓")}
              <span>WonderMc Support Ticket</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Need help with the Minecraft server, store ranks, or billing? Select a category below to open a private ticket with our staff team.
            </p>
            <div className="space-y-1 text-[11px] bg-slate-900/40 p-2.5 rounded-lg border border-slate-700/40">
              <div className="font-semibold text-slate-300 mb-1">Categories:</div>
              <div className="flex items-center gap-1.5 text-slate-300">
                • {renderEmojiVisual(emojis.cart || "🛒", "🛒")} <span className="font-medium text-white">Store / Purchase</span> — Ranks, keys & checkout
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                • {renderEmojiVisual(emojis.ticket || "📓", "📓")} <span className="font-medium text-white">General Support</span> — Server questions & help
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                • {renderEmojiVisual(emojis.cash || "💰", "💰")} <span className="font-medium text-white">Billing</span> — Payment issues & receipts
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                • {renderEmojiVisual(emojis.bug || "<:1222721330659463188:1547589871202476184>", "🐛")} <span className="font-medium text-white">Bug Report</span> — In-game glitches or exploits
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                • {renderEmojiVisual(emojis.appeal || "🔨", "🔨")} <span className="font-medium text-white">Appeal</span> — Ban & mute pardon requests
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                • {renderEmojiVisual(emojis.report || "🚨", "🚨")} <span className="font-medium text-white">Report</span> — Player & rule violation reports
              </div>
            </div>

            {/* Select dropdown simulation */}
            <div className="bg-[#1E1F22] border border-slate-700/60 rounded-lg p-2.5 space-y-2">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Select a category to open ticket</span>
                <span>▼</span>
              </div>
              
              <div className="pt-1.5 border-t border-slate-800 space-y-1.5 text-[11px]">
                <div className="flex items-center gap-2 p-1.5 rounded bg-slate-800/60 text-slate-200 font-medium">
                  {renderEmojiVisual(emojis.cart || "🛒", "🛒")}
                  <span>Store / Purchase (Ranks, Crate Keys & Checkout)</span>
                </div>
                <div className="flex items-center gap-2 p-1.5 rounded hover:bg-slate-800/40 text-slate-300">
                  {renderEmojiVisual(emojis.ticket || "📓", "📓")}
                  <span>General (Server & Network Help)</span>
                </div>
                <div className="flex items-center gap-2 p-1.5 rounded hover:bg-slate-800/40 text-slate-300">
                  {renderEmojiVisual(emojis.cash || "💰", "💰")}
                  <span>Billing (Store Payments & Receipts)</span>
                </div>
                <div className="flex items-center gap-2 p-1.5 rounded hover:bg-slate-800/40 text-slate-300">
                  {renderEmojiVisual(emojis.bug || "<:1222721330659463188:1547589871202476184>", "🐛")}
                  <span>Bug Report (In-Game Glitches & Exploits)</span>
                </div>
                <div className="flex items-center gap-2 p-1.5 rounded hover:bg-slate-800/40 text-slate-300">
                  {renderEmojiVisual(emojis.appeal || "🔨", "🔨")}
                  <span>Appeal (Bans & Mutes)</span>
                </div>
                <div className="flex items-center gap-2 p-1.5 rounded hover:bg-slate-800/40 text-slate-300">
                  {renderEmojiVisual(emojis.report || "🚨", "🚨")}
                  <span>Report (Player & Rule Violations)</span>
                </div>
              </div>
            </div>

            {/* Ticket Panel Footer Image */}
            <div className="pt-2">
              <img
                src="https://cdn.discordapp.com/attachments/1517143210667937914/1531959687380074546/Screenshot_2026_0729_151017.png?ex=6aa3cca3&is=6aa27b23&hm=ac46eea2cfb7f3b588d5826c69a41fc19b0645c6a4348e8e44d8b77965f6e62a&"
                alt="Ticket Panel Footer"
                className="w-full rounded-lg border border-slate-700/50 object-cover max-h-48"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1">
              <span className="flex items-center gap-1.5">
                <img
                  src="https://cdn.discordapp.com/attachments/1517143210667937914/1531959687380074546/Screenshot_2026_0729_151017.png?ex=6aa3cca3&is=6aa27b23&hm=ac46eea2cfb7f3b588d5826c69a41fc19b0645c6a4348e8e44d8b77965f6e62a&"
                  alt="icon"
                  className="w-3.5 h-3.5 rounded-full object-cover"
                  referrerPolicy="no-referrer"
                />
                WonderMc Ticket System • Select a category to open a ticket
              </span>
              <span className="text-cyan-400 font-semibold">Active Panel</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
