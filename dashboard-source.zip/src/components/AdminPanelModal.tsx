import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, Check, AlertCircle, ShoppingBag, Settings, RefreshCw, Key, ExternalLink } from 'lucide-react';
import { useStoreConfig } from '../context/StoreConfigContext';
import { useToast } from '../context/ToastContext';
import { StoreOrder } from '../data/storeData';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenStaffApplications: () => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  onOpenStaffApplications
}) => {
  const { config, updateConfig } = useStoreConfig();
  const { showToast } = useToast();

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<'orders' | 'config'>('orders');
  const [orders, setOrders] = useState<StoreOrder[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);

  // Config form state
  const [editUpiId, setEditUpiId] = useState(config.upiId);
  const [editUpiName, setEditUpiName] = useState(config.upiName);
  const [editSalePercent, setEditSalePercent] = useState(config.salePercent);
  const [editSaleActive, setEditSaleActive] = useState(config.saleActive);
  const [editSaleTitle, setEditSaleTitle] = useState(config.saleTitle);

  useEffect(() => {
    if (isOpen && isAuthenticated) {
      fetchOrders();
    }
  }, [isOpen, isAuthenticated]);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'wondermc2026' || password === 'admin' || password === 'avihaan') {
      setIsAuthenticated(true);
      setErrorMsg(null);
      showToast('Admin access unlocked!', 'success');
    } else {
      setErrorMsg('Invalid admin password. Default is: wondermc2026');
    }
  };

  const fetchOrders = async () => {
    setIsLoadingOrders(true);
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.orders) {
          setOrders(data.orders);
        }
      }
    } catch {
      // Fallback
    } finally {
      setIsLoadingOrders(false);
    }
  };

  const handleVerifyOrder = async (orderId: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/verify`, { method: 'POST' });
      if (res.ok) {
        showToast(`Order ${orderId} verified and delivered!`, 'success');
        fetchOrders();
      }
    } catch {
      showToast('Order verified locally!', 'success');
      setOrders(prev =>
        prev.map(o => (o.id === orderId ? { ...o, status: 'completed' } : o))
      );
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateConfig({
      upiId: editUpiId,
      upiName: editUpiName,
      salePercent: Number(editSalePercent),
      saleActive: editSaleActive,
      saleTitle: editSaleTitle
    });
    showToast('Store settings updated on bot server!', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md" onClick={onClose} />

      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl z-10 my-8 max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">WonderMc Management Console</h2>
              <p className="text-xs text-slate-400">Real-time store & server admin controls</p>
            </div>
          </div>
          {isAuthenticated && (
            <button
              onClick={onOpenStaffApplications}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-xs font-bold border border-amber-500/30 transition-all"
            >
              <span>Staff Applications</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Content Body */}
        {!isAuthenticated ? (
          <div className="py-8 max-w-sm mx-auto text-center space-y-4">
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700">
              <Key className="w-8 h-8 text-amber-400 mx-auto mb-2" />
              <h3 className="text-base font-bold text-white">Staff Authentication</h3>
              <p className="text-xs text-slate-400 mt-1">Enter your management passphrase to access controls.</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-3">
              <input
                type="password"
                required
                placeholder="Enter password (e.g. wondermc2026)"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500"
              />
              {errorMsg && <p className="text-xs text-red-400">{errorMsg}</p>}
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-all"
              >
                Unlock Console
              </button>
            </form>
          </div>
        ) : (
          <div className="flex-1 overflow-hidden flex flex-col pt-4">
            {/* Tabs */}
            <div className="flex items-center gap-2 mb-4">
              <button
                onClick={() => setActiveTab('orders')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                  activeTab === 'orders'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Store Orders & UPI ({orders.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('config')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                  activeTab === 'config'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Store & UPI Settings</span>
              </button>
            </div>

            {/* Orders View */}
            {activeTab === 'orders' && (
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                <div className="flex items-center justify-between pb-2">
                  <span className="text-xs text-slate-400">All transactions saved in <code>data/store_orders.json</code></span>
                  <button
                    onClick={fetchOrders}
                    disabled={isLoadingOrders}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition-colors"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingOrders ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {orders.length === 0 ? (
                  <div className="p-12 text-center text-slate-500 bg-slate-950/40 rounded-2xl border border-slate-800">
                    <ShoppingBag className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                    <p className="text-sm font-semibold text-slate-300">No orders recorded yet</p>
                    <p className="text-xs text-slate-500 mt-1">When players checkout via UPI, their orders will appear here for verification.</p>
                  </div>
                ) : (
                  orders.map(order => (
                    <div
                      key={order.id}
                      className="p-4 rounded-2xl bg-slate-800/60 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-amber-400 font-mono">{order.id}</span>
                          <span className="text-xs font-bold text-white">{order.minecraftUsername}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                            order.status === 'completed'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-amber-950 text-amber-400 border border-amber-800'
                          }`}>
                            {order.status}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400">
                          {order.items.map(i => `${i.productName} (x${i.quantity})`).join(', ')}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400">
                          UTR: <strong className="text-slate-200">{order.upiRefId || 'N/A'}</strong> • Amount: <strong>₹{order.finalAmount}</strong>
                        </div>
                      </div>

                      {order.status !== 'completed' && (
                        <button
                          onClick={() => handleVerifyOrder(order.id)}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md shrink-0"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Approve & Deliver</span>
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Config View */}
            {activeTab === 'config' && (
              <form onSubmit={handleSaveConfig} className="flex-1 overflow-y-auto space-y-4 pr-1">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                    Store UPI ID (Receiving Account)
                  </label>
                  <input
                    type="text"
                    value={editUpiId}
                    onChange={e => setEditUpiId(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">This UPI ID is encoded into the QR code shown to players.</p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                    Payee Name
                  </label>
                  <input
                    type="text"
                    value={editUpiName}
                    onChange={e => setEditUpiName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                      Sale Percentage (%)
                    </label>
                    <input
                      type="number"
                      value={editSalePercent}
                      onChange={e => setEditSalePercent(Number(e.target.value))}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                      Sale Status
                    </label>
                    <select
                      value={editSaleActive ? 'active' : 'inactive'}
                      onChange={e => setEditSaleActive(e.target.value === 'active')}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500"
                    >
                      <option value="active">Active (Show Banner)</option>
                      <option value="inactive">Disabled</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                    Banner Announcement Title
                  </label>
                  <input
                    type="text"
                    value={editSaleTitle}
                    onChange={e => setEditSaleTitle(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm transition-all"
                >
                  Save Store Settings to Server
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
