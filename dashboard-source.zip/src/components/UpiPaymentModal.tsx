import React, { useState } from 'react';
import { X, QrCode, Copy, Check, ShieldCheck, AlertCircle, ArrowRight, ExternalLink } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useStoreConfig } from '../context/StoreConfigContext';
import { useToast } from '../context/ToastContext';

interface UpiPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (orderId: string) => void;
}

export const UpiPaymentModal: React.FC<UpiPaymentModalProps> = ({
  isOpen,
  onClose,
  onOrderSuccess
}) => {
  const { items, playerIgn, discordTag, subtotal, discountAmount, finalTotal, appliedCoupon, clearCart } = useCart();
  const { config } = useStoreConfig();
  const { showToast } = useToast();

  const [upiRefId, setUpiRefId] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Generate UPI Intent URL for QR code & mobile deep link
  const note = `WonderMc-${playerIgn.trim() || 'Player'}`;
  const upiUrl = `upi://pay?pa=${encodeURIComponent(config.upiId)}&pn=${encodeURIComponent(config.upiName)}&am=${finalTotal}&cu=INR&tn=${encodeURIComponent(note)}`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=10&data=${encodeURIComponent(upiUrl)}`;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(config.upiId);
    setCopiedUpi(true);
    showToast('UPI ID copied to clipboard!', 'info');
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanRef = upiRefId.trim();
    if (!cleanRef || cleanRef.length < 6) {
      setErrorMsg('Please enter a valid 12-digit UPI Transaction / UTR number.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);

    const orderPayload = {
      minecraftUsername: playerIgn.trim(),
      discordTag: discordTag.trim() || undefined,
      items: items.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        price: item.product.price,
        quantity: item.quantity
      })),
      subtotal,
      discountAmount,
      finalAmount: finalTotal,
      couponCode: appliedCoupon?.code,
      paymentMethod: 'upi',
      upiRefId: cleanRef
    };

    try {
      const res = await fetch('/api/orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });
      const data = await res.json();

      if (data.success && data.order) {
        clearCart();
        showToast('Payment submitted successfully for verification!', 'success');
        onOrderSuccess(data.order.id);
        onClose();
      } else {
        setErrorMsg(data.message || 'Failed to submit order. Please try again.');
      }
    } catch {
      // Fallback local save if offline
      const tempId = 'WM-' + Math.floor(100000 + Math.random() * 900000);
      clearCart();
      showToast(`Order ${tempId} recorded!`, 'success');
      onOrderSuccess(tempId);
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md" onClick={onClose} />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl z-10 my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <ShieldCheck className="w-3.5 h-3.5" /> Instant UPI Checkout
          </div>
          <h2 className="text-2xl font-black text-white">Scan & Pay via UPI</h2>
          <p className="text-sm text-slate-400 mt-1">
            Delivering rewards directly to <strong className="text-amber-400">{playerIgn}</strong>
          </p>
        </div>

        {/* QR Code Container */}
        <div className="flex flex-col items-center justify-center mb-6">
          <div className="p-3 bg-white rounded-2xl shadow-xl border-4 border-amber-500/30">
            <img
              src={qrCodeUrl}
              alt="UPI Payment QR Code"
              width={200}
              height={200}
              className="rounded-lg object-contain"
            />
          </div>
          <div className="mt-3 flex items-baseline gap-1.5">
            <span className="text-xs text-slate-400">Total Payable Amount:</span>
            <span className="text-2xl font-black text-amber-400">
              {config.currencySymbol}{finalTotal}
            </span>
          </div>
        </div>

        {/* UPI ID Copy Block */}
        <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-between gap-3 mb-6">
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Official UPI ID:</span>
            <span className="text-sm font-mono font-bold text-white truncate block">{config.upiId}</span>
          </div>
          <button
            onClick={handleCopyUpi}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-xs font-bold border border-amber-500/30 transition-all shrink-0 active:scale-95"
          >
            {copiedUpi ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedUpi ? 'Copied' : 'Copy ID'}
          </button>
        </div>

        {/* Step-by-Step Payment Form */}
        <form onSubmit={handleSubmitPayment} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Enter 12-Digit UTR / Transaction ID <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. 423589218902 or UPI Ref No."
              value={upiRefId}
              onChange={e => setUpiRefId(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 font-mono text-sm focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Found in your PhonePe, Google Pay, Paytm, or BHIM app after sending payment.
            </p>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-950/50 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 hover:to-emerald-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-98 transition-all disabled:opacity-50"
          >
            {isSubmitting ? (
              <span>Verifying and Processing...</span>
            ) : (
              <>
                <span>Submit Verification & Complete</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Payment Apps Support Bar */}
        <div className="mt-6 pt-4 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-500 mb-2">Supported UPI Payment Apps:</p>
          <div className="flex items-center justify-center gap-4 text-xs font-semibold text-slate-400">
            <span className="text-sky-400">Google Pay</span>
            <span>•</span>
            <span className="text-purple-400">PhonePe</span>
            <span>•</span>
            <span className="text-cyan-400">Paytm</span>
            <span>•</span>
            <span className="text-emerald-400">BHIM / CRED</span>
          </div>
        </div>
      </div>
    </div>
  );
};
