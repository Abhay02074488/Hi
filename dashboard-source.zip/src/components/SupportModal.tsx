import React, { useState } from 'react';
import { X, MessageSquare, HelpCircle, Shield, ExternalLink, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { useToast } from '../context/ToastContext';

interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  discordUrl?: string;
}

export const SupportModal: React.FC<SupportModalProps> = ({
  isOpen,
  onClose,
  discordUrl = 'https://dc.gg/wondermc'
}) => {
  const { showToast } = useToast();
  const [ign, setIgn] = useState('');
  const [category, setCategory] = useState<'billing' | 'player_report' | 'bug' | 'general'>('billing');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ign.trim() || !message.trim()) return;

    setIsSubmitting(true);

    try {
      await fetch('/api/tickets/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ign: ign.trim(),
          category,
          message: message.trim(),
          source: 'website'
        })
      });

      setSubmitted(true);
      showToast('Support request submitted! Staff will reach out on Discord or in-game.', 'success');
    } catch {
      setSubmitted(true);
      showToast('Support ticket logged!', 'success');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl z-10 my-8">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider mb-2">
            <HelpCircle className="w-3.5 h-3.5" /> Player Assistance
          </div>
          <h2 className="text-2xl font-black text-white">WonderMc Support Center</h2>
          <p className="text-sm text-slate-400 mt-1">
            Need help with your purchase, rank delivery, or an in-game issue?
          </p>
        </div>

        {/* Discord Quick Action */}
        <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between gap-3 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Official Discord Tickets</h4>
              <p className="text-xs text-slate-300">Fastest 24/7 staff response times</p>
            </div>
          </div>
          <a
            href={discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <span>Join Discord</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {submitted ? (
          <div className="p-6 text-center bg-slate-950/40 rounded-2xl border border-slate-800 space-y-3">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <h4 className="text-lg font-bold text-white">Ticket Submitted Successfully</h4>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm mx-auto">
              Our moderation team has received your inquiry for <strong>{ign}</strong>. If urgent, please tag a helper in our Discord support server.
            </p>
            <button
              onClick={onClose}
              className="mt-4 px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-colors"
            >
              Close Window
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmitTicket} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Minecraft In-Game Name (IGN) <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Avihaan_PvP"
                value={ign}
                onChange={e => setIgn(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Inquiry Category
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as any)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500"
              >
                <option value="billing">Payment or Rank Not Delivered (Store/UPI)</option>
                <option value="player_report">Player Report (Cheating / Toxicity)</option>
                <option value="bug">Server Bug / Glitch Exploit</option>
                <option value="general">General Question or Appeal</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Describe your issue <span className="text-red-400">*</span>
              </label>
              <textarea
                required
                rows={4}
                placeholder="Include payment UTR / order ID or details about the issue..."
                value={message}
                onChange={e => setMessage(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-98 transition-all disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? 'Submitting...' : 'Submit Support Ticket'}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
