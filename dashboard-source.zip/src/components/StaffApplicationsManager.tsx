import React, { useState, useEffect } from 'react';
import {
  FileText,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  CheckCircle2,
  XCircle,
  Clock,
  Send,
  Eye,
  Settings,
  HelpCircle,
  AlertTriangle,
  RefreshCw,
  Sparkles,
  MessageSquare,
  Shield,
  User,
  Hash,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  RotateCcw
} from 'lucide-react';
import {
  StaffApplicationConfig,
  StaffApplicationSubmission,
  AuthUser
} from '../types';

interface StaffApplicationsManagerProps {
  user?: AuthUser;
  initialSubmissionId?: string | null;
}

export const StaffApplicationsManager: React.FC<StaffApplicationsManagerProps> = ({ user, initialSubmissionId }) => {
  const [activeSubTab, setActiveSubTab] = useState<'questions' | 'submissions' | 'simulator' | 'settings'>('questions');
  const [config, setConfig] = useState<StaffApplicationConfig>({
    enabled: true,
    review_channel_id: null,
    staff_role_id: null,
    max_questions: 15,
    title: 'WonderMc Staff Recruitment',
    description: 'Welcome to the official WonderMc Staff Application. Please answer all questions honestly and thoroughly.',
    questions: [
      'What is your Minecraft in-game name (IGN) and Discord username?',
      'How old are you and what timezone/region are you located in?',
      'Why do you want to join the WonderMc Staff Team instead of other servers?',
      'Do you have any previous moderation or staff experience? (Please list servers/roles if applicable)',
      'How many hours per week can you actively dedicate to moderating chat and assisting players?',
      'Scenario: A player is accused of using illegal hacks in PvP but denies it. How would you investigate and handle the situation?',
      'Is there anything else you would like our senior management team to know about you?'
    ],
    cooldown_days: 7
  });

  const [submissions, setSubmissions] = useState<StaffApplicationSubmission[]>([]);
  const [loading, setLoading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // New question input state
  const [newQuestionText, setNewQuestionText] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'accepted' | 'denied'>('all');
  const [expandedSubmissionId, setExpandedSubmissionId] = useState<string | null>('1001');

  // Staff Review Modal state
  const [reviewModalData, setReviewModalData] = useState<{
    submissionId: string;
    action: 'accepted' | 'denied';
    applicantName: string;
    reason: string;
  } | null>(null);

  // DM Simulator state
  const [simIndex, setSimIndex] = useState(0);
  const [simAnswers, setSimAnswers] = useState<Record<number, string>>({
    0: 'IGN: SteveMiner / Discord: steve_mc'
  });
  const [simCurrentInput, setSimCurrentInput] = useState('');

  const MAX_ALLOWED_QUESTIONS = 15;

  useEffect(() => {
    fetchConfig();
    fetchSubmissions();
    if (initialSubmissionId) {
      setActiveSubTab('submissions');
      setExpandedSubmissionId(initialSubmissionId);
    }
  }, [initialSubmissionId]);

  const fetchConfig = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/applications/config');
      const data = await res.json();
      if (data.success && data.config) {
        setConfig(data.config);
      }
    } catch (e: any) {
      console.error('Error fetching application config:', e);
    } finally {
      setLoading(false);
    }
  };

  const fetchSubmissions = async () => {
    try {
      const res = await fetch('/api/applications/submissions');
      const data = await res.json();
      if (data.success && Array.isArray(data.submissions)) {
        setSubmissions(data.submissions);
      }
    } catch (e: any) {
      console.error('Error fetching submissions:', e);
    }
  };

  const handleSaveConfig = async (newCfg = config) => {
    try {
      setSaveSuccess(null);
      setErrorMsg(null);
      const res = await fetch('/api/applications/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config: newCfg })
      });
      const data = await res.json();
      if (data.success) {
        setConfig(data.config);
        setSaveSuccess('Staff application questions & settings saved successfully!');
        setTimeout(() => setSaveSuccess(null), 4000);
      } else {
        setErrorMsg(data.error || 'Failed to save configuration.');
      }
    } catch (e: any) {
      setErrorMsg(e.message || 'Error communicating with server.');
    }
  };

  const handleAddQuestion = () => {
    if (!newQuestionText.trim()) return;
    if (config.questions.length >= MAX_ALLOWED_QUESTIONS) {
      setErrorMsg(`Maximum question limit of ${MAX_ALLOWED_QUESTIONS} reached. Please delete a question first.`);
      return;
    }

    const updated = {
      ...config,
      questions: [...config.questions, newQuestionText.trim()]
    };
    setConfig(updated);
    setNewQuestionText('');
    handleSaveConfig(updated);
  };

  const handleRemoveQuestion = (index: number) => {
    const updatedQuestions = config.questions.filter((_, i) => i !== index);
    const updated = { ...config, questions: updatedQuestions };
    setConfig(updated);
    handleSaveConfig(updated);
  };

  const handleMoveQuestion = (index: number, direction: 'up' | 'down') => {
    const newIdx = direction === 'up' ? index - 1 : index + 1;
    if (newIdx < 0 || newIdx >= config.questions.length) return;

    const list = [...config.questions];
    const temp = list[index];
    list[index] = list[newIdx];
    list[newIdx] = temp;

    const updated = { ...config, questions: list };
    setConfig(updated);
    handleSaveConfig(updated);
  };

  const handleEditQuestion = (index: number, val: string) => {
    const list = [...config.questions];
    list[index] = val;
    setConfig({ ...config, questions: list });
  };

  const handleResetDefaults = () => {
    if (window.confirm('Reset questions back to the WonderMc standard 7 questions?')) {
      const defaultQuestions = [
        'What is your Minecraft in-game name (IGN) and Discord username?',
        'How old are you and what timezone/region are you located in?',
        'Why do you want to join the WonderMc Staff Team instead of other servers?',
        'Do you have any previous moderation or staff experience? (Please list servers/roles if applicable)',
        'How many hours per week can you actively dedicate to moderating chat and assisting players?',
        'Scenario: A player is accused of using illegal hacks in PvP but denies it. How would you investigate and handle the situation?',
        'Is there anything else you would like our senior management team to know about you?'
      ];
      const updated = { ...config, questions: defaultQuestions };
      setConfig(updated);
      handleSaveConfig(updated);
    }
  };

  // Staff Review Action (Accept / Deny Modal submit)
  const handleSubmitReview = async () => {
    if (!reviewModalData) return;
    try {
      const res = await fetch(`/api/applications/submissions/${reviewModalData.submissionId}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: reviewModalData.action,
          reviewer: user?.email ? `Staff (${user.email})` : 'WonderMc Staff Lead',
          reason: reviewModalData.reason.trim()
        })
      });
      const data = await res.json();
      if (data.success) {
        fetchSubmissions();
        setReviewModalData(null);
        setSaveSuccess(`Application #${reviewModalData.submissionId} marked as ${reviewModalData.action.toUpperCase()}!`);
        setTimeout(() => setSaveSuccess(null), 4000);
      } else {
        alert(data.error || 'Failed to submit review.');
      }
    } catch (e) {
      console.error('Error submitting review:', e);
    }
  };

  // DM Simulator step
  const handleSimSubmitAnswer = () => {
    if (!simCurrentInput.trim()) return;
    setSimAnswers({
      ...simAnswers,
      [simIndex]: simCurrentInput.trim()
    });
    setSimCurrentInput('');
    if (simIndex < config.questions.length - 1) {
      setSimIndex(simIndex + 1);
    } else {
      setSimIndex(config.questions.length); // review stage
    }
  };

  const handleSimReset = () => {
    setSimIndex(0);
    setSimAnswers({});
    setSimCurrentInput('');
  };

  const filteredSubmissions = submissions.filter((s) => {
    if (filterStatus === 'all') return true;
    return s.status === filterStatus;
  });

  const pendingCount = submissions.filter((s) => s.status === 'pending').length;
  const acceptedCount = submissions.filter((s) => s.status === 'accepted').length;
  const deniedCount = submissions.filter((s) => s.status === 'denied').length;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center gap-1.5">
                <Shield className="w-3 h-3" />
                WonderMc Staff Application System
              </span>
              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Max 15 Questions Allowed
              </span>
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Staff Recruitment & Applications Portal</h1>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Configure recruitment questions (up to 15), preview the live Discord DM applicant interface,
              and review previous submissions with Appy-style Accept & Deny modals.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                fetchConfig();
                fetchSubmissions();
              }}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium border border-slate-700 transition flex items-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            <button
              onClick={() => handleSaveConfig()}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium transition shadow-lg shadow-indigo-600/20 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              Save Questions
            </button>
          </div>
        </div>

        {/* Notifications */}
        {saveSuccess && (
          <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-sm flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{saveSuccess}</span>
          </div>
        )}

        {errorMsg && (
          <div className="mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400 text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Quick Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800/80">
          <div className="bg-slate-800/50 border border-slate-800 rounded-xl p-3">
            <div className="text-xs text-slate-400 font-medium">Configured Questions</div>
            <div className="text-xl font-bold text-white mt-0.5 flex items-baseline gap-1.5">
              <span>{config.questions.length}</span>
              <span className="text-xs font-normal text-slate-500">/ {MAX_ALLOWED_QUESTIONS} Max</span>
            </div>
          </div>
          <div className="bg-slate-800/50 border border-slate-800 rounded-xl p-3">
            <div className="text-xs text-amber-400 font-medium">Pending Review</div>
            <div className="text-xl font-bold text-amber-300 mt-0.5">{pendingCount}</div>
          </div>
          <div className="bg-slate-800/50 border border-slate-800 rounded-xl p-3">
            <div className="text-xs text-emerald-400 font-medium">Accepted Staff</div>
            <div className="text-xl font-bold text-emerald-400 mt-0.5">{acceptedCount}</div>
          </div>
          <div className="bg-slate-800/50 border border-slate-800 rounded-xl p-3">
            <div className="text-xs text-rose-400 font-medium">Denied Applications</div>
            <div className="text-xl font-bold text-rose-400 mt-0.5">{deniedCount}</div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveSubTab('questions')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition flex items-center gap-2 ${
            activeSubTab === 'questions'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <FileText className="w-4 h-4" />
          Question Builder ({config.questions.length}/{MAX_ALLOWED_QUESTIONS})
        </button>

        <button
          onClick={() => setActiveSubTab('submissions')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition flex items-center gap-2 relative ${
            activeSubTab === 'submissions'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <User className="w-4 h-4" />
          Previous Submissions ({submissions.length})
          {pendingCount > 0 && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          )}
        </button>

        <button
          onClick={() => setActiveSubTab('simulator')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition flex items-center gap-2 ${
            activeSubTab === 'simulator'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          Discord DM Simulator
        </button>

        <button
          onClick={() => setActiveSubTab('settings')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition flex items-center gap-2 ${
            activeSubTab === 'settings'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Settings className="w-4 h-4" />
          Discord Setup & Panel
        </button>
      </div>

      {/* TAB 1: QUESTION BUILDER */}
      {activeSubTab === 'questions' && (
        <div className="space-y-6">
          {/* Real-time Discord Bot Sync Banner */}
          <div className="bg-gradient-to-r from-indigo-950/60 via-slate-900 to-emerald-950/40 border border-indigo-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  <span>Direct Discord Bot Synchronization</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    LIVE SYNC
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">
                  Any questions added, reordered, or edited here are directly linked to the Discord bot. 
                  The bot dynamically re-reads this configuration on every interaction without needing a bot restart.
                </p>
              </div>
            </div>
            <button
              onClick={() => handleSaveConfig()}
              className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shrink-0 transition flex items-center gap-1.5 shadow-sm"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Sync Now
            </button>
          </div>

          {/* Add Question Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-semibold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-indigo-400" />
                Add Desired Question
              </h3>
              <div className="text-xs font-medium text-slate-400">
                {config.questions.length} of {MAX_ALLOWED_QUESTIONS} questions used
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                placeholder={
                  config.questions.length >= MAX_ALLOWED_QUESTIONS
                    ? 'Maximum limit of 15 questions reached'
                    : 'Type your custom question here (e.g. How would you handle toxicity in chat?)...'
                }
                value={newQuestionText}
                onChange={(e) => setNewQuestionText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddQuestion()}
                disabled={config.questions.length >= MAX_ALLOWED_QUESTIONS}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
              />
              <button
                onClick={handleAddQuestion}
                disabled={!newQuestionText.trim() || config.questions.length >= MAX_ALLOWED_QUESTIONS}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-sm font-medium transition shrink-0 flex items-center justify-center gap-2 shadow-sm"
              >
                <Plus className="w-4 h-4" />
                Add Question
              </button>
            </div>
          </div>

          {/* Questions List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Configured Application Questions (Presented in order to applicant)
              </div>
              <button
                onClick={handleResetDefaults}
                className="text-xs text-slate-400 hover:text-indigo-400 transition flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                Reset to Standard 7 Questions
              </button>
            </div>

            {config.questions.map((q, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 transition rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm"
              >
                <div className="flex items-start sm:items-center gap-3 w-full sm:w-auto flex-1">
                  <span className="w-7 h-7 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 sm:mt-0">
                    #{idx + 1}
                  </span>
                  <input
                    type="text"
                    value={q}
                    onChange={(e) => handleEditQuestion(idx, e.target.value)}
                    onBlur={() => handleSaveConfig()}
                    className="w-full bg-transparent text-sm text-slate-200 border-b border-transparent focus:border-indigo-500 focus:bg-slate-950/40 rounded px-2 py-1 focus:outline-none transition"
                  />
                </div>

                <div className="flex items-center gap-1 self-end sm:self-center shrink-0">
                  <button
                    onClick={() => handleMoveQuestion(idx, 'up')}
                    disabled={idx === 0}
                    title="Move Question Up"
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed transition"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleMoveQuestion(idx, 'down')}
                    disabled={idx === config.questions.length - 1}
                    title="Move Question Down"
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed transition"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleRemoveQuestion(idx)}
                    title="Delete Question"
                    className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 transition ml-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}

            {config.questions.length === 0 && (
              <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-2xl text-slate-500">
                <FileText className="w-8 h-8 mx-auto mb-2 opacity-40" />
                No questions configured yet. Click above to add questions or reset to defaults.
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: PREVIOUS SUBMISSIONS */}
      {activeSubTab === 'submissions' && (
        <div className="space-y-4">
          {/* Submissions Filter */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl p-3">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setFilterStatus('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                  filterStatus === 'all'
                    ? 'bg-slate-700 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                All ({submissions.length})
              </button>
              <button
                onClick={() => setFilterStatus('pending')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                  filterStatus === 'pending'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'text-slate-400 hover:text-amber-300'
                }`}
              >
                <Clock className="w-3 h-3" />
                Pending ({pendingCount})
              </button>
              <button
                onClick={() => setFilterStatus('accepted')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                  filterStatus === 'accepted'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'text-slate-400 hover:text-emerald-300'
                }`}
              >
                <CheckCircle2 className="w-3 h-3" />
                Accepted ({acceptedCount})
              </button>
              <button
                onClick={() => setFilterStatus('denied')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                  filterStatus === 'denied'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : 'text-slate-400 hover:text-rose-300'
                }`}
              >
                <XCircle className="w-3 h-3" />
                Denied ({deniedCount})
              </button>
            </div>

            <div className="text-xs text-slate-400">
              Showing {filteredSubmissions.length} of {submissions.length} submissions
            </div>
          </div>

          {/* Submissions List */}
          <div className="space-y-4">
            {filteredSubmissions.map((sub) => {
              const isExpanded = expandedSubmissionId === sub.id;
              const isPending = sub.status === 'pending';

              return (
                <div
                  key={sub.id}
                  className={`bg-slate-900 border rounded-2xl transition overflow-hidden shadow-sm ${
                    sub.status === 'accepted'
                      ? 'border-emerald-500/30'
                      : sub.status === 'denied'
                      ? 'border-rose-500/30'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Submission Header Row */}
                  <div className="p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-indigo-400 shrink-0">
                        {sub.user_name.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-white text-base">{sub.user_name}</span>
                          <span className="text-xs text-slate-500 font-mono">ID: {sub.user_id}</span>
                          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                            #{sub.id}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                          <span>Submitted {new Date(sub.submitted_at).toLocaleString()}</span>
                          <span>•</span>
                          <span>{sub.answers?.length || 0} questions answered</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end md:self-center">
                      {/* Status Badge */}
                      {sub.status === 'pending' && (
                        <span className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5" />
                          Pending Review
                        </span>
                      )}
                      {sub.status === 'accepted' && (
                        <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Accepted
                        </span>
                      )}
                      {sub.status === 'denied' && (
                        <span className="px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-1.5">
                          <XCircle className="w-3.5 h-3.5" />
                          Denied
                        </span>
                      )}

                      {/* Expand / Collapse Button */}
                      <button
                        onClick={() => setExpandedSubmissionId(isExpanded ? null : sub.id)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition flex items-center gap-1"
                      >
                        {isExpanded ? (
                          <>
                            <span>Hide Details</span>
                            <ChevronUp className="w-3.5 h-3.5" />
                          </>
                        ) : (
                          <>
                            <span>View Q&A ({sub.answers?.length || 0})</span>
                            <ChevronDown className="w-3.5 h-3.5" />
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Q&A Content */}
                  {isExpanded && (
                    <div className="border-t border-slate-800/80 bg-slate-950/60 p-5 space-y-4">
                      {/* Staff Verdict Bar if already decided */}
                      {sub.reviewed_by && (
                        <div className={`p-4 rounded-xl border text-xs ${
                          sub.status === 'accepted'
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                            : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                        }`}>
                          <div className="font-semibold text-sm mb-1 flex items-center gap-1.5">
                            {sub.status === 'accepted' ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                            Staff Review Verdict: {sub.status.toUpperCase()}
                          </div>
                          <div><strong>Reviewed By:</strong> {sub.reviewed_by} on {sub.reviewed_at ? new Date(sub.reviewed_at).toLocaleString() : 'N/A'}</div>
                          <div className="mt-1"><strong>Reason / Feedback:</strong> {sub.review_reason || 'None provided'}</div>
                        </div>
                      )}

                      {/* Questions and Answers Underneath */}
                      <div className="space-y-3">
                        <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                          Applicant Answers Under Each Desired Question:
                        </div>

                        {sub.answers?.map((qa, aIdx) => (
                          <div
                            key={aIdx}
                            className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 space-y-2"
                          >
                            <div className="text-xs font-semibold text-indigo-400 flex items-start gap-2">
                              <span className="px-1.5 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/20 shrink-0">
                                Q{aIdx + 1}
                              </span>
                              <span>{qa.question}</span>
                            </div>

                            {/* Answer written underneath */}
                            <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3 text-sm text-slate-200 font-mono whitespace-pre-wrap leading-relaxed">
                              {qa.answer || '*No answer provided*'}
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Staff Action Buttons (Appy style) */}
                      {isPending && (
                        <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
                          <div className="text-xs text-slate-400">
                            Perform staff review action. The applicant will be notified with your custom reason.
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              onClick={() =>
                                setReviewModalData({
                                  submissionId: sub.id,
                                  action: 'accepted',
                                  applicantName: sub.user_name,
                                  reason: 'Great experience and thoughtful scenario answers. Welcome to the WonderMc staff team! Check your discord roles.'
                                })
                              }
                              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md shadow-emerald-600/20 transition flex items-center gap-1.5"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Accept Application
                            </button>

                            <button
                              onClick={() =>
                                setReviewModalData({
                                  submissionId: sub.id,
                                  action: 'denied',
                                  applicantName: sub.user_name,
                                  reason: 'Insufficient detail in scenario questions. You may reapply in 14 days.'
                                })
                              }
                              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-md shadow-rose-600/20 transition flex items-center gap-1.5"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              Deny Application
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}

            {filteredSubmissions.length === 0 && (
              <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-2xl text-slate-500">
                <User className="w-8 h-8 mx-auto mb-2 opacity-40" />
                No applications matching this filter.
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: DISCORD DM LIVE SIMULATOR */}
      {activeSubTab === 'simulator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Simulator Controls */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  Interactive DM Test Sandbox
                </h3>
                <button
                  onClick={handleSimReset}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition"
                >
                  <RotateCcw className="w-3 h-3" />
                  Reset Demo
                </button>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                Experience the application flow exactly as a Discord applicant would in their Direct Messages.
                Type an answer below and click &quot;Simulate Answer&quot; to watch the embed update dynamically!
              </p>

              {simIndex < config.questions.length ? (
                <div className="space-y-2 pt-2">
                  <div className="text-xs font-medium text-slate-300">
                    Active Question {simIndex + 1} of {config.questions.length}:
                  </div>
                  <div className="p-3 bg-slate-950 border border-indigo-500/30 rounded-xl text-xs text-indigo-200 font-medium">
                    {config.questions[simIndex]}
                  </div>

                  <textarea
                    rows={3}
                    placeholder="Type sample applicant answer here..."
                    value={simCurrentInput}
                    onChange={(e) => setSimCurrentInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 mt-2"
                  />

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={handleSimSubmitAnswer}
                      disabled={!simCurrentInput.trim()}
                      className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-semibold transition flex items-center justify-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      Send Answer & Advance
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs space-y-2">
                  <div className="font-semibold text-sm flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    All {config.questions.length} Questions Answered!
                  </div>
                  <p>
                    The applicant now sees the confirmation screen with &quot;✅ Submit Application&quot; or &quot;❌ Cancel Application&quot;.
                  </p>
                  <button
                    onClick={handleSimReset}
                    className="mt-2 px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-medium text-xs hover:bg-emerald-500 transition"
                  >
                    Restart DM Flow Demo
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Right: Realistic Discord DM Client Window */}
          <div className="lg:col-span-7">
            <div className="bg-[#313338] rounded-2xl border border-slate-700/60 overflow-hidden shadow-2xl">
              {/* Discord Top Window Bar */}
              <div className="bg-[#2B2D31] px-4 py-2.5 border-b border-[#1F2023] flex items-center justify-between text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white">@WonderMc Network</span>
                  <span className="px-1.5 py-0.2 bg-[#5865F2] text-white text-[10px] rounded font-bold">BOT</span>
                  <span className="text-slate-400">• Direct Messages</span>
                </div>
                <div className="text-[11px] text-emerald-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  Online
                </div>
              </div>

              {/* Discord Message Feed */}
              <div className="p-4 space-y-4 font-sans text-sm max-h-[650px] overflow-y-auto">
                {/* 1. Bot Intro Message */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-full bg-[#5865F2] flex items-center justify-center text-white font-bold text-xs shrink-0 shadow">
                    WM
                  </div>
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white text-sm">WonderMc Network</span>
                      <span className="px-1 py-0.2 bg-[#5865F2] text-white text-[10px] rounded font-bold">BOT</span>
                      <span className="text-xs text-slate-400">Today at 12:00 PM</span>
                    </div>

                    {/* Intro Embed */}
                    <div className="bg-[#2B2D31] border-l-4 border-[#5865F2] rounded p-3.5 space-y-2 max-w-xl text-xs shadow-md">
                      <div className="font-bold text-white text-sm">
                        📝 Staff Application — {config.title}
                      </div>
                      <p className="text-slate-300 text-xs leading-relaxed">
                        Welcome to the official **WonderMc Staff Recruitment Process**! 
                        You will be asked **{config.questions.length} questions** one at a time.
                      </p>
                      <div className="bg-[#1E1F22] rounded p-2 text-[11px] text-slate-300 border border-slate-700/40">
                        💬 <strong>How it works:</strong> Type your answer directly in this DM chat. The bot will automatically record it and immediately dispatch your next question embed.
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. Dispatched & Answered Question Embeds (Edited in place with answers) */}
                {Array.from({ length: simIndex }).map((_, aIdx) => (
                  <div key={aIdx} className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#5865F2] flex items-center justify-center text-white font-bold text-xs shrink-0 shadow">
                      WM
                    </div>
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white text-sm">WonderMc Network</span>
                        <span className="px-1 py-0.2 bg-[#5865F2] text-white text-[10px] rounded font-bold">BOT</span>
                        <span className="text-[11px] text-slate-400">Edited just now</span>
                        <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 text-[9px] rounded font-bold uppercase">
                          Answered
                        </span>
                      </div>

                      {/* Answered Question Embed (Emerald border) */}
                      <div className="bg-[#2B2D31] border-l-4 border-[#2ECC71] rounded p-3.5 space-y-2.5 max-w-xl text-xs shadow-md">
                        <div className="font-bold text-emerald-400 text-xs flex items-center justify-between">
                          <span>✅ Question #{aIdx + 1} of {config.questions.length}</span>
                          <span className="text-[10px] text-slate-400 font-normal">Recorded</span>
                        </div>
                        <div className="text-white font-medium text-xs">
                          {config.questions[aIdx]}
                        </div>
                        <div className="bg-[#1E1F22] border border-emerald-500/30 rounded p-2 text-emerald-300 font-mono text-[11px] whitespace-pre-wrap">
                          {simAnswers[aIdx] || 'Answer submitted.'}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                {/* 3. Active Question Embed (Dispatched as a brand-new card) */}
                {simIndex < config.questions.length && (
                  <div className="flex items-start gap-3 animate-fadeIn">
                    <div className="w-9 h-9 rounded-full bg-[#5865F2] flex items-center justify-center text-white font-bold text-xs shrink-0 shadow ring-2 ring-indigo-500/40">
                      WM
                    </div>
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white text-sm">WonderMc Network</span>
                        <span className="px-1 py-0.2 bg-[#5865F2] text-white text-[10px] rounded font-bold">BOT</span>
                        <span className="text-xs text-slate-400">Just now</span>
                        <span className="px-1.5 py-0.2 bg-indigo-500/20 text-indigo-400 text-[9px] rounded font-bold uppercase animate-pulse">
                          Active Question
                        </span>
                      </div>

                      {/* Active Embed */}
                      <div className="bg-[#2B2D31] border-l-4 border-[#5865F2] rounded p-3.5 space-y-2.5 max-w-xl text-xs shadow-md">
                        <div className="font-bold text-indigo-400 text-xs">
                          ▶️ Question #{simIndex + 1} of {config.questions.length}
                        </div>
                        <div className="text-white font-medium text-sm">
                          {config.questions[simIndex]}
                        </div>
                        <div className="p-2 bg-[#232428] rounded border border-indigo-500/20 text-[11px] text-slate-300 flex items-center gap-1.5">
                          <MessageSquare className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                          <span>Type your response below and press enter to record your answer.</span>
                        </div>
                      </div>

                      {/* Interactive cancel button */}
                      <div className="pt-1">
                        <button
                          onClick={handleSimReset}
                          className="px-2.5 py-1 rounded bg-[#4E5058] hover:bg-[#6D6F78] text-slate-200 text-[11px] font-medium transition flex items-center gap-1"
                        >
                          <XCircle className="w-3 h-3" />
                          Cancel Application
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* 4. Final Review & Confirmation Embed */}
                {simIndex >= config.questions.length && (
                  <div className="flex items-start gap-3 animate-fadeIn">
                    <div className="w-9 h-9 rounded-full bg-[#F1C40F] flex items-center justify-center text-slate-950 font-bold text-xs shrink-0 shadow">
                      WM
                    </div>
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white text-sm">WonderMc Network</span>
                        <span className="px-1 py-0.2 bg-[#5865F2] text-white text-[10px] rounded font-bold">BOT</span>
                        <span className="text-xs text-slate-400">Just now</span>
                      </div>

                      <div className="bg-[#2B2D31] border-l-4 border-[#F1C40F] rounded p-4 space-y-3 max-w-xl text-xs shadow-md">
                        <div className="font-bold text-amber-300 text-sm flex items-center gap-1.5">
                          <Sparkles className="w-4 h-4 text-amber-400" />
                          📋 Staff Application Review — Ready to Submit
                        </div>
                        <p className="text-slate-300 text-xs">
                          You have answered all **{config.questions.length} questions**! 
                          Please review your answers before submitting to the senior administration team.
                        </p>
                        
                        <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-700/60 flex items-center justify-between">
                          <span>WonderMc Staff Recruitment System</span>
                          <span>{new Date().toLocaleDateString()}</span>
                        </div>
                      </div>

                      {/* Discord Interactive Buttons */}
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          onClick={() => {
                            alert('Application submitted! Dispatched to Discord staff review channel and synchronized to web portal.');
                            handleSimReset();
                          }}
                          className="px-3.5 py-1.5 rounded bg-[#248046] hover:bg-[#1A6334] text-white text-xs font-semibold flex items-center gap-1.5 transition shadow"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Submit Application
                        </button>
                        <button
                          onClick={handleSimReset}
                          className="px-3 py-1.5 rounded bg-[#DA373C] hover:bg-[#A12828] text-white text-xs font-medium flex items-center gap-1.5 transition"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          Cancel Application
                        </button>
                        <a
                          href="/?view=applications"
                          target="_blank"
                          rel="noreferrer"
                          className="px-3 py-1.5 rounded bg-[#4E5058] hover:bg-[#6D6F78] text-white text-xs font-medium flex items-center gap-1.5 transition"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          WonderMc Staff Portal
                        </a>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: DISCORD SETUP & COMMANDS */}
      {activeSubTab === 'settings' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* General Config */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm">
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <Settings className="w-4 h-4 text-indigo-400" />
              Recruitment Configuration
            </h3>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Application Name / Title
                </label>
                <input
                  type="text"
                  value={config.title}
                  onChange={(e) => setConfig({ ...config, title: e.target.value })}
                  placeholder="e.g. Staff Application, Media Team, Builder Application..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
                <p className="mt-1.5 text-[11px] text-slate-500">
                  Is naam ko kuch bhi rakh sakte ho — Staff Application, Media Application, Helper, Event Team, etc. Yehi naam Discord panel aur DMs mein dikhega.
                </p>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Welcome Description (Shown on Apply Panel)
                </label>
                <textarea
                  rows={3}
                  value={config.description}
                  onChange={(e) => setConfig({ ...config, description: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Panel Message (replaces the 'How it works' text — use {'{questions}'} and {'{cooldown}'})
                </label>
                <textarea
                  rows={3}
                  placeholder="Leave empty for the default text"
                  value={config.panel_message || ''}
                  onChange={(e) => setConfig({ ...config, panel_message: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Panel Image URL (big banner)
                </label>
                <input
                  type="text"
                  placeholder="https://..."
                  value={config.panel_image || ''}
                  onChange={(e) => setConfig({ ...config, panel_image: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Panel Thumbnail (server / bot / none / image URL)
                </label>
                <input
                  type="text"
                  placeholder="server"
                  value={config.panel_thumbnail || ''}
                  onChange={(e) => setConfig({ ...config, panel_thumbnail: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Panel Footer
                </label>
                <input
                  type="text"
                  placeholder="WonderMc Staff Management"
                  value={config.panel_footer || ''}
                  onChange={(e) => setConfig({ ...config, panel_footer: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Apply Button Label
                </label>
                <input
                  type="text"
                  placeholder="Apply for Staff"
                  value={config.button_label || ''}
                  onChange={(e) => setConfig({ ...config, button_label: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Staff Review Text Channel ID
                </label>
                <input
                  type="text"
                  placeholder="e.g. 123456789012345678"
                  value={config.review_channel_id || ''}
                  onChange={(e) => setConfig({ ...config, review_channel_id: e.target.value || null })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white font-mono focus:outline-none focus:border-indigo-500"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Can also be configured via Discord with <code>/applysetup channel #staff-apps</code>.
                </p>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => handleSaveConfig()}
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium transition shadow-sm flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Save Settings
                </button>
              </div>
            </div>
          </div>

          {/* Discord Commands Reference */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm">
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-indigo-400" />
              Discord Commands Reference
            </h3>

            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1 font-mono">
                <div className="text-indigo-400 font-bold">/applypanel [channel]</div>
                <div className="text-slate-400 font-sans text-[11px]">
                  Deploys the public &quot;Apply for Staff&quot; panel with the interactive button into any server channel.
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1 font-mono">
                <div className="text-indigo-400 font-bold">/applysetup channel #channel</div>
                <div className="text-slate-400 font-sans text-[11px]">
                  Sets the private staff channel where completed applications are delivered for review.
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1 font-mono">
                <div className="text-indigo-400 font-bold">/applysetup addquestion &lt;question&gt;</div>
                <div className="text-slate-400 font-sans text-[11px]">
                  Adds a desired question to the application (enforces max 15 limit).
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1 font-mono">
                <div className="text-indigo-400 font-bold">/applysetup removequestion &lt;number&gt;</div>
                <div className="text-slate-400 font-sans text-[11px]">
                  Removes a question by its number (e.g. 1 to 15).
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1 font-mono">
                <div className="text-indigo-400 font-bold">/applysetup panel</div>
                <div className="text-slate-400 font-sans text-[11px]">
                  Opens the interactive Discord Staff Console to add, preview, or deploy the recruitment system.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: STAFF REVIEW (ACCEPT / DENY WITH REASON) */}
      {reviewModalData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                {reviewModalData.action === 'accepted' ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    Accept Staff Application
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5 text-rose-400" />
                    Deny Staff Application
                  </>
                )}
              </h3>
              <button
                onClick={() => setReviewModalData(null)}
                className="text-slate-400 hover:text-white transition"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Applicant: <strong>{reviewModalData.applicantName}</strong> (App #{reviewModalData.submissionId})<br />
              This feedback will be recorded on their application dossier and delivered via Direct Message.
            </p>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-200">
                {reviewModalData.action === 'accepted' ? 'Acceptance Note / Onboarding Steps:' : 'Denial Reason / Constructive Feedback:'}
              </label>
              <textarea
                rows={4}
                value={reviewModalData.reason}
                onChange={(e) =>
                  setReviewModalData({ ...reviewModalData, reason: e.target.value })
                }
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setReviewModalData(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitReview}
                className={`px-4 py-2 rounded-xl text-white text-xs font-semibold shadow-md transition flex items-center gap-1.5 ${
                  reviewModalData.action === 'accepted'
                    ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/20'
                    : 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/20'
                }`}
              >
                {reviewModalData.action === 'accepted' ? 'Confirm Acceptance' : 'Confirm Denial'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
