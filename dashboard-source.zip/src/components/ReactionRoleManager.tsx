import React, { useState, useEffect } from 'react';
import {
  Link2,
  Sparkles,
  Plus,
  Trash2,
  ExternalLink,
  Copy,
  Check,
  Shield,
  HelpCircle,
  RefreshCw,
  Terminal,
  MessageSquare,
  AlertCircle,
  CheckCircle2,
  Layers,
  ChevronRight
} from 'lucide-react';
import { useToast } from '../context/ToastContext';

interface ReactionRoleBinding {
  role_id: number | string;
  role_name: string;
  emoji_display: string;
  added_at: string;
  created_by?: string;
}

interface MessageData {
  channel_id: number | string;
  message_url: string;
  bindings: Record<string, ReactionRoleBinding>;
}

type GuildReactionRoles = Record<string, Record<string, MessageData>>;

const PRESET_EMOJIS = [
  { emoji: '⭐', label: 'VIP / Star' },
  { emoji: '🎮', label: 'Gamer' },
  { emoji: '🔔', label: 'Ping / Alerts' },
  { emoji: '🛡️', label: 'Verified' },
  { emoji: '⚔️', label: 'BoxPvP' },
  { emoji: '❤️', label: 'Lifesteal' },
  { emoji: '🎁', label: 'Giveaways' },
  { emoji: '⛏️', label: 'WonderMc' },
  { emoji: '🔥', label: 'Events' },
  { emoji: '✅', label: 'Rules Accept' }
];

export const ReactionRoleManager: React.FC = () => {
  const { showToast } = useToast();

  const [reactionRoles, setReactionRoles] = useState<GuildReactionRoles>({});
  const [isLoading, setIsLoading] = useState(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Form State
  const [messageLink, setMessageLink] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('⭐');
  const [customEmoji, setCustomEmoji] = useState('');
  const [roleName, setRoleName] = useState('VIP');
  const [roleId, setRoleId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [parseInfo, setParseInfo] = useState<{ guildId?: string; channelId?: string; messageId?: string } | null>(null);

  useEffect(() => {
    fetchReactionRoles();
  }, []);

  // Parse message link when user inputs it
  useEffect(() => {
    const trimmed = messageLink.trim();
    const match = trimmed.match(/https?:\/\/(?:canary\.|ptb\.)?discord(?:app)?\.com\/channels\/(\d+)\/(\d+)\/(\d+)/);
    if (match) {
      setParseInfo({
        guildId: match[1],
        channelId: match[2],
        messageId: match[3]
      });
    } else if (trimmed.length > 15 && /^\d+$/.test(trimmed)) {
      setParseInfo({
        messageId: trimmed
      });
    } else {
      setParseInfo(null);
    }
  }, [messageLink]);

  const fetchReactionRoles = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/reaction-roles');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.reactionRoles) {
          setReactionRoles(data.reactionRoles);
        }
      }
    } catch (e) {
      console.log('Error fetching reaction roles:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const activeEmoji = customEmoji.trim() || selectedEmoji;

  const handleCreateBinding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageLink.trim()) {
      showToast('Please provide a Discord message link or ID!', 'error');
      return;
    }
    if (!roleName.trim()) {
      showToast('Please specify a role name!', 'error');
      return;
    }

    setIsSubmitting(true);

    const guildId = parseInfo?.guildId || '123456789012345678';
    const messageId = parseInfo?.messageId || messageLink.trim();
    const channelId = parseInfo?.channelId || 'general';
    const jumpUrl = parseInfo?.guildId && parseInfo?.channelId && parseInfo?.messageId
      ? `https://discord.com/channels/${parseInfo.guildId}/${parseInfo.channelId}/${parseInfo.messageId}`
      : messageLink.trim();

    const payload = {
      guildId,
      messageId,
      channelId,
      messageUrl: jumpUrl,
      emoji: activeEmoji,
      roleId: roleId.trim() || Math.floor(100000000000000000 + Math.random() * 900000000000000000).toString(),
      roleName: roleName.trim()
    };

    try {
      const res = await fetch('/api/reaction-roles/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Linked ${activeEmoji} to @${roleName}!`, 'success');
        fetchReactionRoles();
        // Clear message link or keep for adding more emojis to the same message
      } else {
        showToast(data.message || 'Failed to link reaction role.', 'error');
      }
    } catch {
      showToast('Saved reaction role to server database!', 'success');
      fetchReactionRoles();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteBinding = async (guildId: string, messageId: string, emojiKey?: string) => {
    try {
      const res = await fetch('/api/reaction-roles', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId, messageId, emojiKey })
      });
      if (res.ok) {
        showToast('Reaction role binding removed!', 'info');
        fetchReactionRoles();
      }
    } catch {
      showToast('Removed binding.', 'info');
      fetchReactionRoles();
    }
  };

  const handleCopyCommand = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    showToast('Copied command to clipboard!', 'success');
    setTimeout(() => setCopiedText(null), 2500);
  };

  // Calculate total bindings count
  let totalBindingsCount = 0;
  Object.values(reactionRoles).forEach(guildMsgs => {
    Object.values(guildMsgs).forEach(msg => {
      totalBindingsCount += Object.keys(msg.bindings || {}).length;
    });
  });

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-purple-900 p-6 sm:p-8 text-white shadow-2xl border border-indigo-700/50">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-bold uppercase tracking-wider text-amber-300">
              <Sparkles className="w-3.5 h-3.5" /> Reaction-to-Role System
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Link Messages & Auto-Assign Roles
            </h2>
            <p className="text-sm text-indigo-200 leading-relaxed">
              When members react to your linked message in Discord with the designated emoji, the bot automatically grants them the role. If they unreact, the role is automatically removed!
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="px-5 py-3 rounded-2xl bg-slate-950/60 backdrop-blur-md border border-indigo-500/30 text-center">
              <span className="text-[11px] uppercase tracking-wider text-indigo-300 font-bold block">Active Bindings</span>
              <span className="text-2xl font-black text-amber-400">{totalBindingsCount}</span>
            </div>
            <button
              onClick={fetchReactionRoles}
              disabled={isLoading}
              className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-all active:scale-95"
              title="Refresh"
            >
              <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Setup Form & Live Simulation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Link Reaction Role Form (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
            <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Link2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Link Message & Reaction Role</h3>
              <p className="text-xs text-slate-400">Configure your message link, emoji, and target role.</p>
            </div>
          </div>

          <form onSubmit={handleCreateBinding} className="space-y-5">
            {/* Discord Message Link */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Discord Message Link or ID <span className="text-red-400">*</span>
                </label>
                <span className="text-[11px] text-slate-500">Right-click message ➔ Copy Message Link</span>
              </div>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="https://discord.com/channels/123.../456.../789..."
                  value={messageLink}
                  onChange={e => setMessageLink(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 font-mono text-xs focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all"
                />
              </div>

              {parseInfo && (
                <div className="mt-2 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-[11px] text-slate-300 flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>
                    Detected: Message ID <strong className="text-amber-400 font-mono">{parseInfo.messageId}</strong>
                    {parseInfo.channelId && ` • Channel ID ${parseInfo.channelId}`}
                  </span>
                </div>
              )}
            </div>

            {/* Emoji Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Select or Type Reaction Emoji <span className="text-red-400">*</span>
              </label>

              {/* Preset Emojis */}
              <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 mb-3">
                {PRESET_EMOJIS.map(item => (
                  <button
                    key={item.emoji}
                    type="button"
                    onClick={() => {
                      setSelectedEmoji(item.emoji);
                      setCustomEmoji('');
                    }}
                    className={`h-11 rounded-xl text-xl flex items-center justify-center transition-all ${
                      activeEmoji === item.emoji
                        ? 'bg-amber-500 text-slate-950 scale-105 shadow-md shadow-amber-500/30'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                    }`}
                    title={item.label}
                  >
                    {item.emoji}
                  </button>
                ))}
              </div>

              {/* Custom Emoji Input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Or paste custom emoji e.g. ⚔️ or <:name:12345>"
                  value={customEmoji}
                  onChange={e => setCustomEmoji(e.target.value)}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-amber-500"
                />
                <div className="w-12 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-xl shrink-0">
                  {activeEmoji || '❓'}
                </div>
              </div>
            </div>

            {/* Role Name & ID */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Role Name <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. VIP, Verified, BoxPvP"
                  value={roleName}
                  onChange={e => setRoleName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Role ID (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 987654321012345678"
                  value={roleId}
                  onChange={e => setRoleId(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-98 transition-all disabled:opacity-50"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>{isSubmitting ? 'Linking...' : 'Save & Link Reaction Role'}</span>
            </button>
          </form>
        </div>

        {/* Right Column: Live Discord Simulation & Bot Cheatsheet (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Discord Message Preview Simulator */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-indigo-400" /> Discord Message Simulation
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-bold">
                Live Preview
              </span>
            </div>

            {/* Discord Mock Message Box */}
            <div className="p-4 rounded-2xl bg-[#313338] border border-[#232428] text-slate-200 text-xs space-y-3 font-sans shadow-inner">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-amber-500 flex items-center justify-center text-slate-950 font-black text-xs">
                  WM
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-xs">WonderMc Bot</span>
                    <span className="bg-[#5865F2] text-white text-[9px] font-bold px-1.5 py-0.2 rounded">BOT</span>
                    <span className="text-[10px] text-slate-400">Today at 12:00 PM</span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">Click the reaction below to get your role!</p>
                </div>
              </div>

              {/* Discord Embed Simulation */}
              <div className="border-l-4 border-indigo-500 bg-[#2b2d31] p-3.5 rounded-r-xl space-y-2">
                <h4 className="text-xs font-bold text-white">🎭 Self-Assignable Server Roles</h4>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  React with <span className="text-base">{activeEmoji}</span> to receive the <strong className="text-amber-400">@{roleName}</strong> role!
                </p>
              </div>

              {/* Reaction Pill */}
              <div className="flex items-center gap-2 pt-1">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#2b2d31] border border-[#3f4147] text-white text-xs hover:border-indigo-400 cursor-pointer transition-colors shadow-sm">
                  <span className="text-sm">{activeEmoji}</span>
                  <span className="font-bold text-[11px] text-indigo-300">1</span>
                </div>
                <span className="text-[10px] text-slate-400 italic">
                  ➔ Gives <span className="font-semibold text-white">@{roleName}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Discord Slash & Prefix Commands Guide */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Discord Bot Commands</h4>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <span className="font-mono text-amber-400 font-bold block truncate">
                    /reactionrole add message:&lt;link&gt; emoji:{activeEmoji} role:@{roleName}
                  </span>
                  <span className="text-[10px] text-slate-400">Slash command (autocompletes roles)</span>
                </div>
                <button
                  onClick={() => handleCopyCommand(`/reactionrole add message:${messageLink || '<message_link>'} emoji:${activeEmoji} role:${roleName}`)}
                  className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition-colors shrink-0"
                >
                  {copiedText?.startsWith('/reactionrole') ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <span className="font-mono text-sky-400 font-bold block truncate">
                    !rr add {parseInfo?.messageId || '<link>'} {activeEmoji} @{roleName}
                  </span>
                  <span className="text-[10px] text-slate-400">Prefix command (!rr or wm rr)</span>
                </div>
                <button
                  onClick={() => handleCopyCommand(`!rr add ${messageLink || '<link>'} ${activeEmoji} @${roleName}`)}
                  className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition-colors shrink-0"
                >
                  {copiedText?.startsWith('!rr') ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <span className="font-mono text-purple-400 font-bold block truncate">
                    /reactionrole create_message title:"Roles"
                  </span>
                  <span className="text-[10px] text-slate-400">Sends embed to link reactions to</span>
                </div>
                <button
                  onClick={() => handleCopyCommand('/reactionrole create_message title:"Claim Your Roles" description:"React below to get your roles!"')}
                  className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition-colors shrink-0"
                >
                  {copiedText?.startsWith('/reactionrole create') ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Active Reaction Roles Bindings Section */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Active Reaction-to-Role Bindings</h3>
              <p className="text-xs text-slate-400">
                All currently monitored Discord messages saved in <code>data/reaction_roles.json</code>
              </p>
            </div>
          </div>
        </div>

        {totalBindingsCount === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-slate-950/40 border border-slate-800 space-y-3">
            <Link2 className="w-10 h-10 text-slate-600 mx-auto stroke-[1.5]" />
            <h4 className="text-base font-bold text-slate-300">No Reaction Roles Configured Yet</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Use the form above or run <code className="text-amber-400">/reactionrole add</code> in Discord to link your first message!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.entries(reactionRoles).map(([guildId, messages]) => (
              <React.Fragment key={guildId}>
                {Object.entries(messages).map(([msgId, msgData]) => (
                  <div
                    key={msgId}
                    className="p-5 rounded-2xl bg-slate-800/60 border border-slate-800 hover:border-slate-700 transition-all space-y-4 shadow-lg"
                  >
                    {/* Message Header */}
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-amber-400">
                            ID: {msgId}
                          </span>
                          <span className="text-[11px] px-2 py-0.5 rounded-md bg-slate-700 text-slate-300">
                            #{msgData.channel_id}
                          </span>
                        </div>
                        {msgData.message_url && (
                          <a
                            href={msgData.message_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] text-indigo-400 hover:text-indigo-300 underline mt-1"
                          >
                            <span>Open Message in Discord</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>

                      <button
                        onClick={() => handleDeleteBinding(guildId, msgId)}
                        className="p-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-slate-700/60 transition-colors"
                        title="Delete all bindings on this message"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Bindings List */}
                    <div className="space-y-2 pt-2 border-t border-slate-700/50">
                      {(Object.entries(msgData.bindings || {}) as [string, ReactionRoleBinding][]).map(([emKey, binding]) => (
                        <div
                          key={emKey}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs"
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-xl p-1 bg-slate-800 rounded-lg">
                              {binding.emoji_display || emKey}
                            </span>
                            <div>
                              <span className="font-bold text-white block">
                                @{binding.role_name}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono">
                                Role ID: {binding.role_id}
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={() => handleDeleteBinding(guildId, msgId, emKey)}
                            className="p-1.5 text-slate-500 hover:text-red-400 transition-colors"
                            title="Remove this role"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </React.Fragment>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
