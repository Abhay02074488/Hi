import React, { useState, useMemo } from 'react';
import { Search, Sparkles, Flame, Crown, Key, Coins, Shield, Tag, Zap, Filter } from 'lucide-react';
import { Product, STORE_CATEGORIES, DEFAULT_PRODUCTS } from '../data/storeData';
import { ProductCard } from './ProductCard';
import { useStoreConfig } from '../context/StoreConfigContext';
import { TopBuyers } from './TopBuyers';

interface StoreViewProps {
  onInstantBuyProduct?: (product: Product) => void;
}

export const StoreView: React.FC<StoreViewProps> = ({ onInstantBuyProduct }) => {
  const { config } = useStoreConfig();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredProducts = useMemo(() => {
    return DEFAULT_PRODUCTS.filter(prod => {
      const matchCategory = selectedCategory === 'all' || prod.category === selectedCategory;
      const matchSearch =
        !searchQuery.trim() ||
        prod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prod.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prod.features.some(f => f.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCategory && matchSearch;
    });
  }, [selectedCategory, searchQuery]);

  return (
    <div className="space-y-8">
      {/* Featured Promotional Banner */}
      {config.saleActive && (
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 p-6 sm:p-8 text-slate-950 shadow-2xl shadow-amber-500/10">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center md:text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/20 text-xs font-black uppercase tracking-wider">
                <Flame className="w-3.5 h-3.5 fill-slate-950" /> Limited Time Event
              </div>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-950">
                {config.saleTitle}
              </h2>
              <p className="text-sm font-semibold text-slate-900/90 max-w-xl">
                Use code <span className="font-black underline bg-white/40 px-2 py-0.5 rounded">WONDER20</span> at checkout for an instant {config.salePercent}% discount on all ranks & crate keys!
              </p>
            </div>

            <div className="shrink-0 flex items-center gap-3">
              <div className="px-5 py-3 rounded-2xl bg-slate-950 text-amber-400 font-black text-center shadow-lg">
                <span className="text-xs uppercase tracking-wider block text-slate-400 font-bold">Discount</span>
                <span className="text-2xl font-black">{config.salePercent}% OFF</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Category Pills & Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-slate-900/60 p-3 sm:p-4 rounded-2xl border border-slate-800">
        {/* Category Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
          {STORE_CATEGORIES.map(cat => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                    : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/50'
                }`}
              >
                <span>{cat.name}</span>
              </button>
            );
          })}
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search perks, ranks, keys..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-800/90 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="p-12 text-center bg-slate-900/40 rounded-3xl border border-slate-800">
          <Filter className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white">No products found</h3>
          <p className="text-xs text-slate-400 mt-1">Try choosing another category or clearing your search filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onInstantBuy={onInstantBuyProduct}
            />
          ))}
        </div>
      )}

      {/* Top Supporters / Buyers Section */}
      <TopBuyers />
    </div>
  );
};
