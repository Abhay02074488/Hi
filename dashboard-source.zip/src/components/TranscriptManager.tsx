import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  Mail,
  RefreshCw,
  Search,
  CheckCircle2,
  Clock,
  HardDrive,
  User,
  Plus,
  UploadCloud,
  Trash2,
  X,
  FileCode,
  Check,
  AlertCircle,
  Eye,
  Bot
} from 'lucide-react';
import { TranscriptFile } from '../types';
import { TranscriptViewer } from './TranscriptViewer';

interface TranscriptManagerProps {
  files: TranscriptFile[];
  onRefresh: () => void;
  onSendDm: (filename: string, targetUser: string) => Promise<void>;
  onCreateCustomTranscript: (data: {
    channelName: string;
    openerUser: string;
    category: string;
    targetDmUser: string;
    messages?: Array<{ author: string; content: string; timestamp: string }>;
  }) => Promise<void>;
}

export const TranscriptManager: React.FC<TranscriptManagerProps> = ({
  files,
  onRefresh,
  onSendDm,
  onCreateCustomTranscript
}) => {
  const [selectedFile, setSelectedFile] = useState<string | null>(files[0]?.filename || null);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [isLoadingContent, setIsLoadingContent] = useState(false);
  const [targetDmUser, setTargetDmUser] = useState("");
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  // Upload Transcript Modal State
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadFilename, setUploadFilename] = useState("");
  const [uploadContent, setUploadContent] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  // Quick Generate Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newChName, setNewChName] = useState("ticket-vip-issue-101");
  const [newOpener, setNewOpener] = useState("Avihaan_PvP");
  const [newCategory, setNewCategory] = useState("Store & VIP Support");
  const [newDmTarget, setNewDmTarget] = useState("Avihaan_PvP#0001");
  const [rawMessages, setRawMessages] = useState(
    `[2026-08-21 14:10:05] Avihaan_PvP#0001 (987654321012): Hello! I purchased the Netherite VIP rank on the server, but it's not synced yet.\n[2026-08-21 14:11:20] WonderMc • core [BOT] (102938475611): Ticket opened! A staff member will assist you shortly.\n[2026-08-21 14:11:45] ModTeam_Alex (112233445566): Hey Avihaan! Let me check the transaction database for play.wondermc.fun.\n[2026-08-21 14:12:30] ModTeam_Alex (112233445566): Transaction verified! Synced your VIP perks and ingame prefix. Please relog on play.wondermc.fun!\n[2026-08-21 14:13:40] Avihaan_PvP#0001 (987654321012): Awesome, relogged and I have the VIP prefix and fly access now! Thanks so much!\n[2026-08-21 14:14:15] ModTeam_Alex (112233445566): You're very welcome! Have fun playing on WonderMc!\n[2026-08-21 14:14:45] WonderMc • core [BOT] (102938475611): Ticket closed by ModTeam_Alex. Transcript exported to dashboard and DM sent.`
  );

  // Fetch File Content when selected
  const handleSelectFile = async (filename: string) => {
    setSelectedFile(filename);
    setIsLoadingContent(true);
    try {
      const res = await fetch(`/api/transcripts/${encodeURIComponent(filename)}`);
      const data = await res.json();
      if (data.success) {
        setFileContent(data.content);
      } else {
        setFileContent("⚠️ Failed to load transcript file content.");
      }
    } catch (e) {
      setFileContent("⚠️ Error connecting to server.");
    } finally {
      setIsLoadingContent(false);
    }
  };

  useEffect(() => {
    if (files.length > 0 && !selectedFile) {
      handleSelectFile(files[0].filename);
    }
  }, [files]);

  // Handle DM Send
  const handleSendDm = async () => {
    if (!selectedFile) return;
    const user = targetDmUser.trim() || "Ticket Opener";
    try {
      await onSendDm(selectedFile, user);
      setStatusMsg(`✅ Transcript "${selectedFile}" successfully sent to ${user}'s DM & logged!`);
      setTimeout(() => setStatusMsg(null), 5000);
    } catch (e: any) {
      setStatusMsg(`❌ Failed to send DM: ${e.message}`);
    }
  };

  // Handle Delete File
  const handleDeleteFile = async (filename: string) => {
    if (!confirm(`Are you sure you want to delete "${filename}"?`)) return;
    try {
      const res = await fetch(`/api/transcripts/${encodeURIComponent(filename)}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        setStatusMsg(`🗑️ Transcript "${filename}" deleted.`);
        onRefresh();
        if (selectedFile === filename) {
          setSelectedFile(null);
          setFileContent(null);
        }
      }
    } catch (e: any) {
      setStatusMsg(`❌ Failed to delete: ${e.message}`);
    }
  };

  // Handle Direct Upload from Local Computer
  const handleFileUploadInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadFilename(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      setUploadContent((event.target?.result as string) || "");
    };
    reader.readAsText(file);
  };

  // Submit Uploaded Transcript to Server
  const handleSubmitUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadContent.trim()) {
      alert("Please provide transcript content or select a file.");
      return;
    }

    setIsUploading(true);
    try {
      const res = await fetch('/api/transcripts/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: uploadFilename || `transcript-upload-${Date.now()}.txt`,
          content: uploadContent
        })
      });
      const data = await res.json();
      if (data.success) {
        setStatusMsg(`✅ ${data.message}`);
        setShowUploadModal(false);
        setUploadFilename("");
        setUploadContent("");
        onRefresh();
        handleSelectFile(data.filename);
      } else {
        alert(data.error || "Failed to upload transcript.");
      }
    } catch (e: any) {
      alert(e.message || "Upload error.");
    } finally {
      setIsUploading(false);
    }
  };

  // Handle Create from Simulator
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const lines = rawMessages.split("\n").filter(l => l.trim().length > 0);
      const parsedMsgs = lines.map(line => {
        const match = line.match(/^\[(.*?)\]\s*(.*?):\s*(.*)$/);
        if (match) {
          return { timestamp: match[1], author: match[2], content: match[3] };
        }
        return { timestamp: new Date().toISOString(), author: newOpener, content: line };
      });

      await onCreateCustomTranscript({
        channelName: newChName,
        openerUser: newOpener,
        category: newCategory,
        targetDmUser: newDmTarget,
        messages: parsedMsgs
      });

      setShowCreateModal(false);
      setStatusMsg(`✅ New transcript created and saved to server machine transcripts folder!`);
      onRefresh();
    } catch (e: any) {
      alert(`Error creating transcript: ${e.message}`);
    }
  };

  // Handle Download File
  const handleDownload = () => {
    if (!selectedFile || !fileContent) return;
    const element = document.createElement("a");
    const file = new Blob([fileContent], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = selectedFile;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const filteredFiles = files.filter(f =>
    f.filename.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Top Action & Status Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                WonderMc Transcript & Ticket Archive
                <span className="text-[10px] px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-mono rounded">
                  EXACT DISCORD TAB
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Direct panel upload, live Discord visual screenshot renderer, and local storage in <code className="text-indigo-400">/transcripts</code>
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-emerald-900/30 transition cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload Transcript</span>
          </button>

          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-indigo-900/30 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Generate New</span>
          </button>

          <button
            onClick={onRefresh}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition cursor-pointer"
            title="Refresh transcript files"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {statusMsg && (
        <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      {/* Main Grid: Left Files List & Right Discord Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: File Directory (4 Cols) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg flex flex-col h-[680px]">
          
          {/* Search bar */}
          <div className="relative mb-3">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search transcripts..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-500 pointer-events-none" />
          </div>

          <div className="text-[11px] font-semibold text-slate-400 px-1 mb-2 flex items-center justify-between">
            <span>SAVED TRANSCRIPTS ({filteredFiles.length})</span>
            <span className="text-indigo-400">LOCAL HOST</span>
          </div>

          {/* Files List */}
          <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
            {filteredFiles.length === 0 ? (
              <div className="text-center py-12 text-xs text-slate-500">
                No transcripts match your search.
              </div>
            ) : (
              filteredFiles.map((file) => {
                const isSelected = selectedFile === file.filename;
                return (
                  <div
                    key={file.filename}
                    onClick={() => handleSelectFile(file.filename)}
                    className={`group p-2.5 rounded-xl text-xs cursor-pointer border transition flex items-center justify-between ${
                      isSelected
                        ? 'bg-indigo-600/20 border-indigo-500/50 text-white shadow-sm'
                        : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <FileText className={`w-4 h-4 shrink-0 ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`} />
                      <div className="truncate">
                        <div className="font-mono text-xs font-medium truncate">{file.filename}</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          {(file.size / 1024).toFixed(1)} KB • {new Date(file.modifiedAt).toLocaleDateString()}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteFile(file.filename);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 rounded transition"
                      title="Delete transcript"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Discord Visual Tab Viewer (8 Cols) */}
        <div className="lg:col-span-8 flex flex-col h-[680px]">
          {selectedFile && fileContent ? (
            <TranscriptViewer
              filename={selectedFile}
              rawContent={fileContent}
              onDownloadRaw={handleDownload}
            />
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl flex flex-col items-center justify-center h-full text-slate-500 space-y-3">
              <FileText className="w-12 h-12 text-slate-700" />
              <p className="text-sm">Select a transcript from the left to view the exact Discord screenshot tab.</p>
            </div>
          )}
        </div>

      </div>

      {/* MODAL 1: UPLOAD TRANSCRIPT FILE / PASTE */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 font-bold text-base">
                <UploadCloud className="w-5 h-5 text-emerald-400" />
                <span>Upload Transcript Directly into Panel</span>
              </div>
              <button
                onClick={() => setShowUploadModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitUpload} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  1. Choose .txt transcript file:
                </label>
                <input
                  type="file"
                  accept=".txt,.log"
                  onChange={handleFileUploadInput}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-slate-300 file:mr-3 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  2. Filename:
                </label>
                <input
                  type="text"
                  required
                  value={uploadFilename}
                  onChange={(e) => setUploadFilename(e.target.value)}
                  placeholder="e.g. transcript-ticket-vip-101.txt"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  3. Transcript Log / Text:
                </label>
                <textarea
                  rows={6}
                  required
                  value={uploadContent}
                  onChange={(e) => setUploadContent(e.target.value)}
                  placeholder="Paste or write transcript text here..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploading}
                  className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-semibold shadow-lg shadow-emerald-900/30 cursor-pointer disabled:opacity-50"
                >
                  {isUploading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <UploadCloud className="w-4 h-4" />}
                  <span>Save to Panel & Local Host</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* MODAL 2: QUICK GENERATE TRANSCRIPT */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 font-bold text-base">
                <Plus className="w-5 h-5 text-indigo-400" />
                <span>Generate New Ticket Transcript</span>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Channel Name</label>
                  <input
                    type="text"
                    value={newChName}
                    onChange={(e) => setNewChName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Ticket Opener</label>
                  <input
                    type="text"
                    value={newOpener}
                    onChange={(e) => setNewOpener(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Chat Messages (Format: [timestamp] author: message)</label>
                <textarea
                  rows={6}
                  value={rawMessages}
                  onChange={(e) => setRawMessages(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 font-mono focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold shadow-lg shadow-indigo-900/30 cursor-pointer"
                >
                  Export & Save
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
