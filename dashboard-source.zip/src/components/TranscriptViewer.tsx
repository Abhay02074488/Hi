import React, { useState } from 'react';
import {
  Hash,
  Bell,
  Pin,
  Users,
  Search,
  Inbox,
  HelpCircle,
  Download,
  Copy,
  Check,
  Code,
  Eye,
  Shield,
  Bot,
  Sparkles,
  ExternalLink,
  MessageSquare,
  FileText
} from 'lucide-react';
import { ParsedTranscript, ParsedTranscriptMessage } from '../types';

interface TranscriptViewerProps {
  filename: string;
  rawContent: string;
  onDownloadRaw?: () => void;
}

export const TranscriptViewer: React.FC<TranscriptViewerProps> = ({
  filename,
  rawContent,
  onDownloadRaw
}) => {
  const [viewMode, setViewMode] = useState<'discord' | 'raw'>('discord');
  const [copied, setCopied] = useState(false);

  // Parse raw text into structured WonderMc styled messages
  const parseTranscript = (text: string): ParsedTranscript => {
    const lines = text.split('\n');
    let channelName = 'ticket-channel';
    let guildName = 'WonderMc Support';
    let openerUser = 'User';
    let claimedBy = 'Staff';
    let category = 'Support';
    let exportedAt = new Date().toUTCString();
    let serverIp = 'play.wondermc.fun';

    const messages: ParsedTranscriptMessage[] = [];

    // Header extraction
    lines.forEach(line => {
      if (line.includes('Channel Name :')) channelName = line.split(':')[1]?.trim() || channelName;
      if (line.includes('Guild        :')) guildName = line.split(':')[1]?.trim() || guildName;
      if (line.includes('Ticket Opener:')) openerUser = line.split(':')[1]?.trim() || openerUser;
      if (line.includes('Claimed By   :')) claimedBy = line.split(':')[1]?.trim() || claimedBy;
      if (line.includes('Category     :')) category = line.split(':')[1]?.trim() || category;
      if (line.includes('Exported At  :')) exportedAt = line.split(':')[1]?.trim() || exportedAt;
      if (line.includes('Server IP    :')) serverIp = line.split(':')[1]?.trim() || serverIp;
    });

    // Message extraction regex: [timestamp] author (id): content
    const msgRegex = /^\[(.*?)\]\s*(.*?)(?:\s*\((.*?)\))?:\s*(.*)$/;

    lines.forEach((line, index) => {
      const match = line.match(msgRegex);
      if (match) {
        const timestamp = match[1];
        const rawAuthor = match[2].trim();
        const content = match[4].trim();

        const isBot = rawAuthor.toLowerCase().includes('bot') || rawAuthor.toLowerCase().includes('core');
        const isStaff = rawAuthor.toLowerCase().includes('mod') || rawAuthor.toLowerCase().includes('admin') || rawAuthor.toLowerCase().includes('team');
        const isOwner = rawAuthor.toLowerCase().includes('avihaan') || rawAuthor.toLowerCase().includes('owner');

        let avatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80';
        let roleColor = 'text-slate-200';
        let badge = '';

        if (isBot) {
          avatar = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&auto=format&fit=crop&q=80';
          roleColor = 'text-indigo-400';
          badge = 'BOT';
        } else if (isOwner) {
          avatar = 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=100&auto=format&fit=crop&q=80';
          roleColor = 'text-emerald-400';
          badge = 'OWNER';
        } else if (isStaff) {
          avatar = 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&auto=format&fit=crop&q=80';
          roleColor = 'text-cyan-400';
          badge = 'STAFF';
        }

        // Check if message is a ticket embed or close event
        let embeds = undefined;
        if (content.toLowerCase().includes('ticket opened') || content.toLowerCase().includes('ticket closed') || content.toLowerCase().includes('welcome')) {
          embeds = [{
            title: isBot ? "🎫 Support Ticket System" : undefined,
            description: content,
            color: isBot ? "border-indigo-500" : "border-emerald-500",
            fields: [
              { name: "Server IP", value: "`play.wondermc.fun`", inline: true },
              { name: "Discord", value: "dc.gg/wondermc", inline: true }
            ],
            footer: "WonderMc Network • Transcript Engine"
          }];
        }

        messages.push({
          id: `msg-${index}`,
          timestamp,
          author: rawAuthor.replace(/\[BOT\]/g, '').trim(),
          avatar,
          isBot,
          roleColor,
          badge,
          content,
          embeds
        });
      }
    });

    if (messages.length === 0) {
      // Fallback message
      messages.push({
        id: 'msg-0',
        timestamp: exportedAt,
        author: openerUser,
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80',
        content: text.slice(0, 500)
      });
    }

    return {
      channelName: channelName.replace('#', ''),
      guildName,
      openerUser,
      claimedBy,
      category,
      exportedAt,
      serverIp,
      messages
    };
  };

  const parsed = parseTranscript(rawContent);

  const handleCopyRaw = () => {
    navigator.clipboard.writeText(rawContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-[#313338] text-[#dbdee1] rounded-2xl overflow-hidden border border-[#1e1f22] shadow-2xl font-sans">
      
      {/* Top Discord Client Titlebar & Controls */}
      <div className="bg-[#1e1f22] px-4 py-2.5 flex items-center justify-between border-b border-[#2b2d31] select-none text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-full bg-[#ed4245] cursor-pointer hover:opacity-80" />
            <div className="w-3 h-3 rounded-full bg-[#fee75c] cursor-pointer hover:opacity-80" />
            <div className="w-3 h-3 rounded-full bg-[#57f287] cursor-pointer hover:opacity-80" />
          </div>

          <div className="h-4 w-[1px] bg-[#35363c]" />

          <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
            <Bot className="w-4 h-4 text-[#5865f2]" />
            <span className="text-white">Transcript Viewer</span>
            <span className="text-[10px] px-1.5 py-0.2 bg-[#5865f2]/20 text-[#5865f2] rounded font-bold">
              DISCORD EXACT TAB
            </span>
          </div>
        </div>

        {/* View Switcher & Actions */}
        <div className="flex items-center gap-2">
          <div className="bg-[#2b2d31] p-0.5 rounded-lg flex items-center text-[11px]">
            <button
              onClick={() => setViewMode('discord')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-semibold transition cursor-pointer ${
                viewMode === 'discord' ? 'bg-[#5865f2] text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Eye className="w-3 h-3" />
              <span>Discord View</span>
            </button>
            <button
              onClick={() => setViewMode('raw')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-semibold transition cursor-pointer ${
                viewMode === 'raw' ? 'bg-[#5865f2] text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Code className="w-3 h-3" />
              <span>Raw Text</span>
            </button>
          </div>

          <button
            onClick={handleCopyRaw}
            className="p-1.5 bg-[#2b2d31] hover:bg-[#35363c] text-slate-300 hover:text-white rounded-lg transition"
            title="Copy Raw Transcript"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          {onDownloadRaw && (
            <button
              onClick={onDownloadRaw}
              className="p-1.5 bg-[#2b2d31] hover:bg-[#35363c] text-slate-300 hover:text-white rounded-lg transition"
              title="Download Transcript File"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* DISCORD VIEW: Discord View */}
      {viewMode === 'discord' ? (
        <div className="flex-1 flex flex-col overflow-hidden bg-[#313338]">
          
          {/* Discord Channel Header */}
          <div className="bg-[#313338] px-4 py-3 border-b border-[#2b2d31] flex items-center justify-between shadow-sm z-10">
            <div className="flex items-center gap-2">
              <Hash className="w-5 h-5 text-[#80848e]" />
              <span className="font-bold text-white text-sm">{parsed.channelName}</span>
              <div className="h-4 w-[1px] bg-[#3f4147] mx-1" />
              <span className="text-xs text-[#949ba4] truncate max-w-xs sm:max-w-md">
                {parsed.guildName} • Category: <strong className="text-slate-200">{parsed.category}</strong>
              </span>
            </div>

            <div className="hidden sm:flex items-center gap-3 text-[#b5bac1]">
              <Bell className="w-4 h-4 hover:text-white cursor-pointer" />
              <Pin className="w-4 h-4 hover:text-white cursor-pointer" />
              <Users className="w-4 h-4 hover:text-white cursor-pointer" />
              <div className="relative">
                <input
                  type="text"
                  readOnly
                  placeholder="Search in ticket"
                  className="bg-[#1e1f22] text-xs px-2 py-1 rounded w-36 text-slate-300 focus:outline-none placeholder-[#80848e]"
                />
                <Search className="w-3 h-3 text-[#80848e] absolute right-2 top-2 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Transcript Info Banner */}
          <div className="bg-[#2b2d31]/80 px-4 py-2.5 border-b border-[#1e1f22] flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex flex-wrap items-center gap-4 text-[#949ba4]">
              <span>Opener: <strong className="text-white">{parsed.openerUser}</strong></span>
              <span>Claimed: <strong className="text-emerald-400">{parsed.claimedBy}</strong></span>
              <span>Server: <code className="text-[#5865f2] bg-[#1e1f22] px-1.5 py-0.5 rounded">{parsed.serverIp}</code></span>
            </div>
            <div className="text-[11px] text-[#80848e]">
              Exported: {parsed.exportedAt}
            </div>
          </div>

          {/* Discord Messages Feed (Exact Discord chat layout) */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-[#313338]">
            
            {/* Welcome Channel Banner */}
            <div className="mb-6 space-y-2">
              <div className="w-16 h-16 rounded-full bg-[#2b2d31] flex items-center justify-center text-[#dbdee1] mb-3">
                <Hash className="w-10 h-10" />
              </div>
              <h2 className="text-2xl font-bold text-white">Welcome to #{parsed.channelName}!</h2>
              <p className="text-xs text-[#949ba4]">
                This is the start of the #{parsed.channelName} ticket channel recorded by WonderMc / WonderMc transcript recorder.
              </p>
              <div className="h-[1px] bg-[#3f4147] my-4" />
            </div>

            {/* Messages */}
            {parsed.messages.map((msg, idx) => (
              <div
                key={msg.id || idx}
                className="group flex items-start gap-4 hover:bg-[#2e3035] -mx-4 px-4 py-1.5 rounded transition"
              >
                {/* Avatar */}
                <img
                  src={msg.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80"}
                  alt={msg.author}
                  className="w-10 h-10 rounded-full object-cover shrink-0 cursor-pointer hover:opacity-90"
                />

                {/* Message Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`font-semibold text-sm cursor-pointer hover:underline ${msg.roleColor || 'text-white'}`}>
                      {msg.author}
                    </span>

                    {msg.badge && (
                      <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold uppercase tracking-wider ${
                        msg.badge === 'BOT'
                          ? 'bg-[#5865f2] text-white'
                          : msg.badge === 'OWNER'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-cyan-600 text-white'
                      }`}>
                        {msg.badge}
                      </span>
                    )}

                    <span className="text-[11px] text-[#949ba4]">
                      {msg.timestamp}
                    </span>
                  </div>

                  {/* Text Content */}
                  <div className="text-sm text-[#dbdee1] mt-0.5 leading-relaxed break-words whitespace-pre-wrap">
                    {msg.content}
                  </div>

                  {/* Embeds if any */}
                  {msg.embeds?.map((embed, eIdx) => (
                    <div
                      key={eIdx}
                      className={`mt-2 bg-[#2b2d31] border-l-4 ${embed.color || 'border-[#5865f2]'} rounded-r-lg p-3.5 max-w-lg space-y-2 text-xs shadow-md`}
                    >
                      {embed.title && (
                        <div className="font-bold text-white text-sm">{embed.title}</div>
                      )}
                      {embed.description && (
                        <div className="text-[#dbdee1]">{embed.description}</div>
                      )}
                      {embed.fields && (
                        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[#3f4147]">
                          {embed.fields.map((f, fIdx) => (
                            <div key={fIdx}>
                              <div className="text-[11px] font-semibold text-[#949ba4]">{f.name}</div>
                              <div className="text-xs text-white">{f.value}</div>
                            </div>
                          ))}
                        </div>
                      )}
                      {embed.footer && (
                        <div className="text-[10px] text-[#80848e] pt-1">{embed.footer}</div>
                      )}
                    </div>
                  ))}

                </div>
              </div>
            ))}

          </div>

          {/* Mock Discord Chat Input Bar */}
          <div className="p-4 bg-[#313338]">
            <div className="bg-[#383a40] rounded-lg px-4 py-2.5 flex items-center justify-between text-xs text-[#80848e] select-none">
              <span>Transcript closed and archived. Read-only channel.</span>
              <span className="text-[10px] bg-[#2b2d31] px-2 py-0.5 rounded text-slate-300 font-mono">
                play.wondermc.fun
              </span>
            </div>
          </div>

        </div>
      ) : (
        /* RAW TEXT VIEW */
        <div className="flex-1 bg-[#1e1f22] p-4 overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed custom-scrollbar whitespace-pre-wrap select-text">
          {rawContent}
        </div>
      )}

    </div>
  );
};
