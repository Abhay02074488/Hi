import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Trophy,
  RotateCcw,
  Sparkles,
  Zap,
  CheckCircle2,
  Circle,
  X as XIcon,
  Coins,
  Shield,
  Bot,
  User,
  Flame,
  ArrowRight
} from 'lucide-react';
import { GameStats } from '../types';

export const GamesHub: React.FC = () => {
  const [activeGame, setActiveGame] = useState<'tictactoe' | 'chess' | 'blackjack'>('tictactoe');
  const [stats, setStats] = useState<GameStats>({
    tictactoe: { played: 142, wins: 89, losses: 38, draws: 15 },
    chess: { played: 64, wins: 38, losses: 21, draws: 5 },
    blackjack: { played: 320, wins: 172, losses: 135, pushes: 13, chips_won: 48500 }
  });

  useEffect(() => {
    fetchGameStats();
  }, []);

  const fetchGameStats = async () => {
    try {
      const res = await fetch('/api/games/stats');
      const data = await res.json();
      if (data.success && data.stats) {
        setStats(data.stats);
      }
    } catch (_) {}
  };

  const recordGameResult = async (game: 'tictactoe' | 'chess' | 'blackjack', result: 'win' | 'loss' | 'draw' | 'push', chipsDelta?: number) => {
    try {
      const res = await fetch('/api/games/record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ game, result, chipsDelta })
      });
      const data = await res.json();
      if (data.success && data.stats) {
        setStats(data.stats);
      }
    } catch (_) {}
  };

  // ==========================================
  // 1. TIC TAC TOE ENGINE
  // ==========================================
  const [tttBoard, setTttBoard] = useState<(string | null)[]>(Array(9).fill(null));
  const [tttTurn, setTttTurn] = useState<'X' | 'O'>('X');
  const [tttWinner, setTttWinner] = useState<string | null>(null);
  const [tttWinningLine, setTttWinningLine] = useState<number[] | null>(null);
  const [tttMode, setTttMode] = useState<'ai' | 'pvp'>('ai');

  const checkWinner = (board: (string | null)[]) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // Cols
      [0, 4, 8], [2, 4, 6]             // Diagonals
    ];
    for (const [a, b, c] of lines) {
      if (board[a] && board[a] === board[b] && board[a] === board[c]) {
        return { winner: board[a], line: [a, b, c] };
      }
    }
    if (board.every(cell => cell !== null)) {
      return { winner: 'draw', line: [] };
    }
    return null;
  };

  const handleTttClick = (index: number) => {
    if (tttBoard[index] || tttWinner) return;

    const newBoard = [...tttBoard];
    newBoard[index] = tttTurn;
    setTttBoard(newBoard);

    const winResult = checkWinner(newBoard);
    if (winResult) {
      setTttWinner(winResult.winner);
      setTttWinningLine(winResult.line);
      if (winResult.winner === 'X') recordGameResult('tictactoe', 'win');
      else if (winResult.winner === 'O') recordGameResult('tictactoe', 'loss');
      else recordGameResult('tictactoe', 'draw');
      return;
    }

    if (tttMode === 'ai' && tttTurn === 'X') {
      setTttTurn('O');
      setTimeout(() => {
        makeAiMove(newBoard);
      }, 350);
    } else {
      setTttTurn(tttTurn === 'X' ? 'O' : 'X');
    }
  };

  const makeAiMove = (currentBoard: (string | null)[]) => {
    // Simple smart AI
    const available = currentBoard.map((val, idx) => (val === null ? idx : null)).filter(val => val !== null) as number[];
    if (available.length === 0) return;

    // Check if AI can win
    for (const idx of available) {
      const b = [...currentBoard];
      b[idx] = 'O';
      if (checkWinner(b)?.winner === 'O') {
        currentBoard[idx] = 'O';
        setTttBoard(currentBoard);
        setTttWinner('O');
        setTttWinningLine(checkWinner(currentBoard)!.line);
        recordGameResult('tictactoe', 'loss');
        setTttTurn('X');
        return;
      }
    }

    // Check if AI must block X
    for (const idx of available) {
      const b = [...currentBoard];
      b[idx] = 'X';
      if (checkWinner(b)?.winner === 'X') {
        currentBoard[idx] = 'O';
        setTttBoard(currentBoard);
        const win = checkWinner(currentBoard);
        if (win) {
          setTttWinner(win.winner);
          setTttWinningLine(win.line);
        } else {
          setTttTurn('X');
        }
        return;
      }
    }

    // Take center or random
    const move = available.includes(4) ? 4 : available[Math.floor(Math.random() * available.length)];
    currentBoard[move] = 'O';
    setTttBoard(currentBoard);

    const res = checkWinner(currentBoard);
    if (res) {
      setTttWinner(res.winner);
      setTttWinningLine(res.line);
      if (res.winner === 'draw') recordGameResult('tictactoe', 'draw');
    } else {
      setTttTurn('X');
    }
  };

  const resetTtt = () => {
    setTttBoard(Array(9).fill(null));
    setTttTurn('X');
    setTttWinner(null);
    setTttWinningLine(null);
  };

  // ==========================================
  // 2. CHESS ENGINE (Interactive Board)
  // ==========================================
  const initialChessBoard = [
    ['♜', '♞', '♝', '♛', '♚', '♝', '♞', '♜'],
    ['♟', '♟', '♟', '♟', '♟', '♟', '♟', '♟'],
    Array(8).fill(''),
    Array(8).fill(''),
    Array(8).fill(''),
    Array(8).fill(''),
    ['♙', '♙', '♙', '♙', '♙', '♙', '♙', '♙'],
    ['♖', '♘', '♗', '♕', '♔', '♗', '♘', '♖']
  ];

  const [chessBoard, setChessBoard] = useState<string[][]>(initialChessBoard);
  const [selectedPiece, setSelectedPiece] = useState<{ r: number; c: number } | null>(null);
  const [chessTurn, setChessTurn] = useState<'white' | 'black'>('white');
  const [moveHistory, setMoveHistory] = useState<string[]>([]);
  const [capturedWhite, setCapturedWhite] = useState<string[]>([]);
  const [capturedBlack, setCapturedBlack] = useState<string[]>([]);

  const isWhitePiece = (p: string) => ['♔', '♕', '♖', '♗', '♘', '♙'].includes(p);
  const isBlackPiece = (p: string) => ['♚', '♛', '♜', '♝', '♞', '♟'].includes(p);

  const handleChessSquareClick = (r: number, c: number) => {
    const piece = chessBoard[r][c];

    if (selectedPiece) {
      if (selectedPiece.r === r && selectedPiece.c === c) {
        setSelectedPiece(null);
        return;
      }

      const fromPiece = chessBoard[selectedPiece.r][selectedPiece.c];
      const targetPiece = piece;

      // Cannot capture own piece
      if (targetPiece && ((isWhitePiece(fromPiece) && isWhitePiece(targetPiece)) || (isBlackPiece(fromPiece) && isBlackPiece(targetPiece)))) {
        setSelectedPiece({ r, c });
        return;
      }

      // Execute Move
      const newBoard = chessBoard.map(row => [...row]);
      newBoard[selectedPiece.r][selectedPiece.c] = '';
      newBoard[r][c] = fromPiece;

      if (targetPiece) {
        if (isWhitePiece(targetPiece)) setCapturedWhite(prev => [...prev, targetPiece]);
        else setCapturedBlack(prev => [...prev, targetPiece]);
      }

      const notation = `${fromPiece} ${String.fromCharCode(97 + selectedPiece.c)}${8 - selectedPiece.r} → ${String.fromCharCode(97 + c)}${8 - r}`;
      setMoveHistory(prev => [notation, ...prev].slice(0, 10));

      setChessBoard(newBoard);
      setSelectedPiece(null);
      setChessTurn(chessTurn === 'white' ? 'black' : 'white');

      if (targetPiece === '♚') {
        alert('🎉 Checkmate! White wins the match!');
        recordGameResult('chess', 'win');
      } else if (targetPiece === '♔') {
        alert('⚠️ Checkmate! Black wins the match!');
        recordGameResult('chess', 'loss');
      }
    } else {
      if (piece) {
        if ((chessTurn === 'white' && isWhitePiece(piece)) || (chessTurn === 'black' && isBlackPiece(piece))) {
          setSelectedPiece({ r, c });
        }
      }
    }
  };

  const resetChess = () => {
    setChessBoard(initialChessBoard);
    setSelectedPiece(null);
    setChessTurn('white');
    setMoveHistory([]);
    setCapturedWhite([]);
    setCapturedBlack([]);
  };

  // ==========================================
  // 3. BLACKJACK (21) ENGINE
  // ==========================================
  interface Card {
    suit: '♠' | '♥' | '♦' | '♣';
    value: string;
    score: number;
    color: string;
  }

  const createDeck = (): Card[] => {
    const suits: Array<'♠' | '♥' | '♦' | '♣'> = ['♠', '♥', '♦', '♣'];
    const values = [
      { val: 'A', score: 11 },
      { val: '2', score: 2 },
      { val: '3', score: 3 },
      { val: '4', score: 4 },
      { val: '5', score: 5 },
      { val: '6', score: 6 },
      { val: '7', score: 7 },
      { val: '8', score: 8 },
      { val: '9', score: 9 },
      { val: '10', score: 10 },
      { val: 'J', score: 10 },
      { val: 'Q', score: 10 },
      { val: 'K', score: 10 }
    ];

    const deck: Card[] = [];
    for (const suit of suits) {
      const color = suit === '♥' || suit === '♦' ? 'text-rose-500' : 'text-slate-900';
      for (const v of values) {
        deck.push({ suit, value: v.val, score: v.score, color });
      }
    }
    // Shuffle
    return deck.sort(() => Math.random() - 0.5);
  };

  const calculateHandScore = (hand: Card[]) => {
    let score = hand.reduce((sum, card) => sum + card.score, 0);
    let aces = hand.filter(card => card.value === 'A').length;
    while (score > 21 && aces > 0) {
      score -= 10;
      aces -= 1;
    }
    return score;
  };

  const [deck, setDeck] = useState<Card[]>(createDeck());
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [bjGameState, setBjGameState] = useState<'betting' | 'playing' | 'dealer_turn' | 'game_over'>('betting');
  const [bet, setBet] = useState(100);
  const [chips, setChips] = useState(2500);
  const [bjResultMsg, setBjResultMsg] = useState<string | null>(null);

  const startBlackjack = () => {
    if (chips < bet) {
      alert("Not enough chips! Resetting bankroll to 1000.");
      setChips(1000);
      return;
    }

    const newDeck = createDeck();
    const pHand = [newDeck.pop()!, newDeck.pop()!];
    const dHand = [newDeck.pop()!, newDeck.pop()!];

    setDeck(newDeck);
    setPlayerHand(pHand);
    setDealerHand(dHand);
    setChips(prev => prev - bet);
    setBjGameState('playing');
    setBjResultMsg(null);

    const pScore = calculateHandScore(pHand);
    if (pScore === 21) {
      // Natural Blackjack!
      endBlackjack(pHand, dHand, 'blackjack');
    }
  };

  const handleHit = () => {
    if (bjGameState !== 'playing') return;
    const newDeck = [...deck];
    const card = newDeck.pop()!;
    const newHand = [...playerHand, card];

    setDeck(newDeck);
    setPlayerHand(newHand);

    const score = calculateHandScore(newHand);
    if (score > 21) {
      endBlackjack(newHand, dealerHand, 'bust');
    }
  };

  const handleStand = () => {
    if (bjGameState !== 'playing') return;
    setBjGameState('dealer_turn');

    let currentDealerHand = [...dealerHand];
    let currentDeck = [...deck];

    // Dealer AI: hits until 17 or higher
    while (calculateHandScore(currentDealerHand) < 17) {
      const card = currentDeck.pop()!;
      currentDealerHand.push(card);
    }

    setDeck(currentDeck);
    setDealerHand(currentDealerHand);

    const pScore = calculateHandScore(playerHand);
    const dScore = calculateHandScore(currentDealerHand);

    if (dScore > 21) {
      endBlackjack(playerHand, currentDealerHand, 'dealer_bust');
    } else if (pScore > dScore) {
      endBlackjack(playerHand, currentDealerHand, 'win');
    } else if (pScore < dScore) {
      endBlackjack(playerHand, currentDealerHand, 'loss');
    } else {
      endBlackjack(playerHand, currentDealerHand, 'push');
    }
  };

  const endBlackjack = (pHand: Card[], dHand: Card[], result: 'blackjack' | 'bust' | 'dealer_bust' | 'win' | 'loss' | 'push') => {
    setBjGameState('game_over');

    if (result === 'blackjack') {
      const winAmount = Math.floor(bet * 2.5);
      setChips(prev => prev + winAmount);
      setBjResultMsg(`🎉 BLACKJACK! You won ${winAmount} chips! (3:2 Payout)`);
      recordGameResult('blackjack', 'win', winAmount - bet);
    } else if (result === 'win' || result === 'dealer_bust') {
      const winAmount = bet * 2;
      setChips(prev => prev + winAmount);
      setBjResultMsg(result === 'dealer_bust' ? `💥 Dealer BUSTED! You won ${winAmount} chips!` : `🏆 You beat the dealer! Won ${winAmount} chips!`);
      recordGameResult('blackjack', 'win', bet);
    } else if (result === 'push') {
      setChips(prev => prev + bet);
      setBjResultMsg(`🤝 PUSH! Tie with dealer. ${bet} chips returned.`);
      recordGameResult('blackjack', 'push', 0);
    } else if (result === 'bust') {
      setBjResultMsg(`💥 BUST (Score ${calculateHandScore(pHand)})! Dealer wins.`);
      recordGameResult('blackjack', 'loss', -bet);
    } else {
      setBjResultMsg(`❌ Dealer had a higher score (${calculateHandScore(dHand)} vs ${calculateHandScore(pHand)}).`);
      recordGameResult('blackjack', 'loss', -bet);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-lg shadow-cyan-500/10 text-2xl">
              🎮
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                WonderMc Bot Minigames Hub
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  PLAYABLE ONLINE & DISCORD
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Play live <strong>Tic Tac Toe</strong>, <strong>Chess</strong>, and <strong>Blackjack (21)</strong>. All wins & scores persist to server stats!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-slate-950 px-4 py-2 rounded-2xl border border-slate-800">
            <Coins className="w-5 h-5 text-amber-400" />
            <div className="text-xs">
              <span className="text-slate-400 block text-[10px]">Casino Chips</span>
              <strong className="text-amber-400 font-mono text-sm">{chips.toLocaleString()}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Game Selector Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveGame('tictactoe')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeGame === 'tictactoe'
              ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-sm'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <span>❌⭕ Tic Tac Toe</span>
          <span className="text-[10px] opacity-70">({stats.tictactoe.wins}W)</span>
        </button>

        <button
          onClick={() => setActiveGame('chess')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeGame === 'chess'
              ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 shadow-sm'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <span>♟️ Interactive Chess</span>
          <span className="text-[10px] opacity-70">({stats.chess.wins}W)</span>
        </button>

        <button
          onClick={() => setActiveGame('blackjack')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeGame === 'blackjack'
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-sm'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <span>🃏 Blackjack (21)</span>
          <span className="text-[10px] opacity-70">({stats.blackjack.wins}W)</span>
        </button>
      </div>

      {/* 1. TIC TAC TOE */}
      {activeGame === 'tictactoe' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col items-center justify-center shadow-xl">
            <div className="flex items-center justify-between w-full max-w-xs mb-6">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Mode:</span>
                <select
                  value={tttMode}
                  onChange={(e) => { setTttMode(e.target.value as any); resetTtt(); }}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1 text-xs text-white"
                >
                  <option value="ai">🤖 vs Smart AI</option>
                  <option value="pvp">👥 2 Players (Local)</option>
                </select>
              </div>

              <button
                onClick={resetTtt}
                className="flex items-center gap-1 text-xs text-slate-400 hover:text-white bg-slate-800 px-3 py-1 rounded-xl transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            </div>

            {/* Turn or Winner Banner */}
            <div className="mb-6 text-center">
              {tttWinner ? (
                <div className="px-4 py-1.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 inline-flex items-center gap-1.5">
                  <Trophy className="w-4 h-4" />
                  <span>{tttWinner === 'draw' ? 'Game Draw!' : `Winner: ${tttWinner}! 🎉`}</span>
                </div>
              ) : (
                <div className="text-xs font-semibold text-slate-300">
                  Current Turn: <strong className={tttTurn === 'X' ? 'text-cyan-400' : 'text-rose-400'}>{tttTurn}</strong>
                </div>
              )}
            </div>

            {/* 3x3 Grid */}
            <div className="grid grid-cols-3 gap-3 bg-slate-950 p-4 rounded-2xl border border-slate-800 w-full max-w-xs shadow-inner">
              {tttBoard.map((cell, idx) => {
                const isWinningCell = tttWinningLine?.includes(idx);
                return (
                  <button
                    key={idx}
                    onClick={() => handleTttClick(idx)}
                    disabled={!!cell || !!tttWinner}
                    className={`h-20 sm:h-24 rounded-xl text-3xl font-black transition flex items-center justify-center border ${
                      isWinningCell
                        ? 'bg-emerald-500/30 border-emerald-500 text-emerald-400 scale-105'
                        : cell
                        ? 'bg-slate-900 border-slate-800 cursor-default'
                        : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/80 cursor-pointer'
                    }`}
                  >
                    {cell === 'X' && <span className="text-cyan-400">✕</span>}
                    {cell === 'O' && <span className="text-rose-400">◯</span>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Stats & Discord Command */}
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Trophy className="w-4 h-4 text-cyan-400" />
                TicTacToe Career Stats
              </h3>

              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400">Wins</div>
                  <div className="text-xl font-bold text-emerald-400">{stats.tictactoe.wins}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400">Losses</div>
                  <div className="text-xl font-bold text-rose-400">{stats.tictactoe.losses}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400">Draws</div>
                  <div className="text-xl font-bold text-amber-400">{stats.tictactoe.draws}</div>
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs space-y-2">
                <div className="font-semibold text-slate-300">💬 Play in Discord Server:</div>
                <code className="text-cyan-400 font-mono block bg-slate-900 p-2 rounded-lg">
                  /tictactoe opponent:@friend
                </code>
                <p className="text-[11px] text-slate-400">
                  Interactive button grid responds inside any text channel with instant win-line calculation.
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* 2. CHESS */}
      {activeGame === 'chess' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col items-center shadow-xl">
            <div className="flex items-center justify-between w-full max-w-md mb-4 text-xs">
              <div className="flex items-center gap-2">
                <span>Turn:</span>
                <span className={`px-2.5 py-0.5 rounded-full font-bold uppercase ${
                  chessTurn === 'white' ? 'bg-white text-slate-900' : 'bg-slate-800 text-white border border-slate-700'
                }`}>
                  {chessTurn}
                </span>
              </div>

              <button
                onClick={resetChess}
                className="flex items-center gap-1 text-slate-400 hover:text-white bg-slate-800 px-3 py-1 rounded-xl transition cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>New Chess Game</span>
              </button>
            </div>

            {/* 8x8 Chessboard */}
            <div className="border-4 border-slate-800 rounded-xl overflow-hidden shadow-2xl bg-slate-950">
              {chessBoard.map((row, r) => (
                <div key={r} className="flex">
                  {row.map((cell, c) => {
                    const isDark = (r + c) % 2 === 1;
                    const isSelected = selectedPiece?.r === r && selectedPiece?.c === c;
                    return (
                      <button
                        key={c}
                        onClick={() => handleChessSquareClick(r, c)}
                        className={`w-10 h-10 sm:w-14 sm:h-14 flex items-center justify-center text-2xl sm:text-3xl transition select-none cursor-pointer ${
                          isSelected
                            ? 'bg-amber-400/60 ring-2 ring-amber-400'
                            : isDark
                            ? 'bg-[#779952] hover:bg-[#88aa63]'
                            : 'bg-[#edeed1] hover:bg-[#f5f6e2]'
                        }`}
                      >
                        <span className={isWhitePiece(cell) ? 'text-white drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]' : 'text-slate-950'}>
                          {cell}
                        </span>
                      </button>
                    );
                  })}
                </div>
              ))}
            </div>

            {/* Captures */}
            <div className="mt-4 flex justify-between w-full max-w-md text-xs text-slate-400">
              <div>White Captures: <span className="text-white font-mono">{capturedBlack.join(' ') || 'None'}</span></div>
              <div>Black Captures: <span className="text-white font-mono">{capturedWhite.join(' ') || 'None'}</span></div>
            </div>
          </div>

          {/* Move Log & Bot Cog info */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                📜 Move History
              </h3>

              <div className="bg-slate-950 rounded-xl p-3 h-48 overflow-y-auto font-mono text-xs text-slate-300 space-y-1.5 custom-scrollbar">
                {moveHistory.length === 0 ? (
                  <span className="text-slate-500 text-[11px]">Click any piece to start playing...</span>
                ) : (
                  moveHistory.map((m, idx) => (
                    <div key={idx} className="flex justify-between border-b border-slate-800/60 pb-1">
                      <span className="text-slate-500">#{moveHistory.length - idx}</span>
                      <span className="text-emerald-400">{m}</span>
                    </div>
                  ))
                )}
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs space-y-2">
                <div className="font-semibold text-slate-300">💬 Discord Chess Command:</div>
                <code className="text-indigo-400 font-mono block bg-slate-900 p-2 rounded-lg">
                  /chess challenge:@opponent
                </code>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* 3. BLACKJACK (21) */}
      {activeGame === 'blackjack' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          <div className="lg:col-span-8 bg-gradient-to-b from-[#0b3b24] to-[#062617] border border-emerald-700/50 rounded-3xl p-6 sm:p-8 flex flex-col items-center shadow-2xl text-white relative overflow-hidden">
            <div className="absolute top-4 left-6 text-xs text-emerald-300/80 font-bold uppercase tracking-widest flex items-center gap-1.5">
              <span>♠ ♥ WONDER CASINO TABLE ♦ ♣</span>
            </div>

            {/* Dealer Area */}
            <div className="w-full text-center mt-6 mb-8">
              <div className="text-xs text-emerald-300 mb-2 font-semibold">
                DEALER {bjGameState === 'game_over' && `(Score: ${calculateHandScore(dealerHand)})`}
              </div>
              <div className="flex justify-center gap-3">
                {dealerHand.map((card, idx) => {
                  const hide = bjGameState === 'playing' && idx === 1;
                  return (
                    <div
                      key={idx}
                      className={`w-16 h-24 sm:w-20 sm:h-28 rounded-xl shadow-2xl flex flex-col justify-between p-2 font-bold text-base transition ${
                        hide ? 'bg-indigo-900 border-2 border-indigo-400 flex items-center justify-center' : 'bg-white'
                      }`}
                    >
                      {hide ? (
                        <div className="text-indigo-300 text-xl font-mono">🂠</div>
                      ) : (
                        <>
                          <div className={card.color}>{card.value}{card.suit}</div>
                          <div className={`text-2xl text-center ${card.color}`}>{card.suit}</div>
                          <div className={`text-right ${card.color}`}>{card.value}</div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Result Message */}
            {bjResultMsg && (
              <div className="my-4 px-6 py-2 bg-black/60 backdrop-blur border border-amber-400/40 rounded-2xl text-xs font-bold text-amber-300 shadow-xl text-center animate-bounce">
                {bjResultMsg}
              </div>
            )}

            {/* Player Area */}
            <div className="w-full text-center mt-4 mb-6">
              <div className="text-xs text-emerald-300 mb-2 font-semibold">
                YOUR HAND (Score: {calculateHandScore(playerHand)})
              </div>
              <div className="flex justify-center gap-3">
                {playerHand.map((card, idx) => (
                  <div
                    key={idx}
                    className="w-16 h-24 sm:w-20 sm:h-28 bg-white rounded-xl shadow-2xl flex flex-col justify-between p-2 font-bold text-base transition transform hover:-translate-y-1"
                  >
                    <div className={card.color}>{card.value}{card.suit}</div>
                    <div className={`text-2xl text-center ${card.color}`}>{card.suit}</div>
                    <div className={`text-right ${card.color}`}>{card.value}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Blackjack Action Controls */}
            {bjGameState === 'betting' || bjGameState === 'game_over' ? (
              <div className="flex flex-wrap items-center justify-center gap-3 mt-4">
                <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-xl border border-emerald-700/50 text-xs">
                  <span>Bet:</span>
                  {[50, 100, 250, 500].map(bVal => (
                    <button
                      key={bVal}
                      onClick={() => setBet(bVal)}
                      className={`px-2.5 py-1 rounded-lg font-mono font-bold cursor-pointer transition ${
                        bet === bVal ? 'bg-amber-500 text-black' : 'bg-slate-800 text-white'
                      }`}
                    >
                      {bVal}
                    </button>
                  ))}
                </div>

                <button
                  onClick={startBlackjack}
                  className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-black rounded-xl text-xs shadow-lg shadow-amber-500/20 transition cursor-pointer"
                >
                  Deal Cards (Bet {bet})
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-4 mt-4">
                <button
                  onClick={handleHit}
                  className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-xl text-xs shadow-lg transition cursor-pointer"
                >
                  Hit (+ Card)
                </button>

                <button
                  onClick={handleStand}
                  className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs shadow-lg transition cursor-pointer"
                >
                  Stand
                </button>
              </div>
            )}

          </div>

          {/* Stats & Discord blackjack command */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-400" />
                Blackjack Stats
              </h3>

              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400">Wins</div>
                  <div className="text-xl font-bold text-emerald-400">{stats.blackjack.wins}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400">Losses</div>
                  <div className="text-xl font-bold text-rose-400">{stats.blackjack.losses}</div>
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs space-y-2">
                <div className="font-semibold text-slate-300">💬 Discord Blackjack Command:</div>
                <code className="text-amber-400 font-mono block bg-slate-900 p-2 rounded-lg">
                  /blackjack bet:100
                </code>
                <p className="text-[11px] text-slate-400">
                  Play casino blackjack directly with your server XP & economy balance in Discord!
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
