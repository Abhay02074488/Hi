import React from 'react';
import { ShoppingCart, Zap, Check, Crown, Key, Coins, Shield, Tag, Sparkles } from 'lucide-react';
import { Product } from '../data/storeData';
import { useCart } from '../context/CartContext';
import { useStoreConfig } from '../context/StoreConfigContext';
import { useToast } from '../context/ToastContext';

interface ProductCardProps {
  product: Product;
  onInstantBuy?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onInstantBuy }) => {
  const { addItem } = useCart();
  const { config } = useStoreConfig();
  const { showToast } = useToast();

  const handleAddToCart = () => {
    addItem(product, 1);
    showToast(`Added ${product.name} to cart!`, 'success');
  };

  const handleInstantBuy = () => {
    addItem(product, 1);
    if (onInstantBuy) {
      onInstantBuy(product);
    }
  };

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'ranks': return <Crown className="w-4 h-4 text-amber-400" />;
      case 'keys': return <Key className="w-4 h-4 text-yellow-400" />;
      case 'coins': return <Coins className="w-4 h-4 text-emerald-400" />;
      case 'kits': return <Shield className="w-4 h-4 text-blue-400" />;
      case 'merch': return <Tag className="w-4 h-4 text-purple-400" />;
      default: return <Sparkles className="w-4 h-4 text-pink-400" />;
    }
  };

  return (
    <div className="relative group bg-slate-900/80 hover:bg-slate-900 rounded-2xl border border-slate-800 hover:border-amber-500/50 transition-all duration-300 flex flex-col justify-between overflow-hidden shadow-xl hover:shadow-2xl hover:shadow-amber-500/10 hover:-translate-y-1">
      {/* Top Banner / Badge */}
      {product.badge && (
        <div className="absolute top-3 right-3 z-10">
          <span className="px-2.5 py-1 text-xs font-bold uppercase tracking-wider rounded-full bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30">
            {product.badge}
          </span>
        </div>
      )}

      {/* Card Header & Visual Preview */}
      <div className="p-6 pb-4">
        <div className="flex items-center gap-2 mb-3">
          <span className="p-1.5 rounded-lg bg-slate-800/80 border border-slate-700/50">
            {getCategoryIcon(product.category)}
          </span>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            {product.category}
          </span>
        </div>

        <h3 className="text-xl font-bold text-white group-hover:text-amber-400 transition-colors mb-2">
          {product.name}
        </h3>

        <p className="text-sm text-slate-400 leading-relaxed min-h-[40px]">
          {product.description}
        </p>

        {/* Pricing Block */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-baseline gap-2">
          <span className="text-2xl font-extrabold text-amber-400">
            {config.currencySymbol}{product.price}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-slate-500 line-through">
              {config.currencySymbol}{product.originalPrice}
            </span>
          )}
          {product.originalPrice && (
            <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded-md">
              Save {config.currencySymbol}{product.originalPrice - product.price}
            </span>
          )}
        </div>

        {/* Features Checklist */}
        <div className="mt-4 space-y-2">
          {product.features.map((feat, idx) => (
            <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
              <span>{feat}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-6 pt-2 bg-slate-950/40 border-t border-slate-800/50 flex gap-2">
        <button
          onClick={handleAddToCart}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-sm font-semibold transition-all duration-200 border border-slate-700 hover:border-slate-600 active:scale-95"
        >
          <ShoppingCart className="w-4 h-4 text-amber-400" />
          Add to Cart
        </button>
        <button
          onClick={handleInstantBuy}
          className="flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-sm font-bold transition-all duration-200 shadow-md shadow-amber-500/20 active:scale-95"
        >
          <Zap className="w-4 h-4 fill-slate-950" />
          Buy
        </button>
      </div>
    </div>
  );
};
