import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Sparkles, Tag, AlertCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useStoreConfig } from '../context/StoreConfigContext';
import { MinecraftSkinImage } from './MinecraftSkinImage';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onProceedToPayment: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  onProceedToPayment
}) => {
  const {
    items,
    playerIgn,
    setPlayerIgn,
    discordTag,
    setDiscordTag,
    removeItem,
    updateQuantity,
    subtotal,
    discountAmount,
    finalTotal,
    appliedCoupon,
    applyCoupon,
    removeCoupon
  } = useCart();

  const { config } = useStoreConfig();
  const [couponInput, setCouponInput] = useState('');
  const [couponLoading, setCouponLoading] = useState(false);
  const [couponFeedback, setCouponFeedback] = useState<{ msg: string; error?: boolean } | null>(null);
  const [ignError, setIgnError] = useState(false);

  if (!isOpen) return null;

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    setCouponLoading(true);
    setCouponFeedback(null);
    const res = await applyCoupon(couponInput);
    setCouponLoading(false);
    setCouponFeedback({ msg: res.message, error: !res.success });
  };

  const handleCheckoutClick = () => {
    if (!playerIgn.trim()) {
      setIgnError(true);
      return;
    }
    setIgnError(false);
    onProceedToPayment();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity duration-300"
        onClick={onClose}
      />

      {/* Slide-out drawer */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-slate-900 border-l border-slate-800 flex flex-col shadow-2xl">
          {/* Drawer Header */}
          <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Your Cart</h2>
                <p className="text-xs text-slate-400">
                  {items.length} {items.length === 1 ? 'item' : 'items'} selected
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Minecraft IGN Input Section */}
          <div className="p-6 border-b border-slate-800 bg-slate-950/30">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Minecraft Username (IGN) <span className="text-red-400">*</span>
            </label>
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="e.g. Avihaan_PvP"
                  value={playerIgn}
                  onChange={e => {
                    setPlayerIgn(e.target.value);
                    if (ignError) setIgnError(false);
                  }}
                  className={`w-full px-4 py-2.5 rounded-xl bg-slate-800/90 border text-white text-sm focus:outline-none transition-all ${
                    ignError
                      ? 'border-red-500 focus:border-red-400 focus:ring-2 focus:ring-red-500/20'
                      : 'border-slate-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20'
                  }`}
                />
              </div>
              <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center overflow-hidden shrink-0">
                <MinecraftSkinImage username={playerIgn || 'Steve'} size={36} type="bust" />
              </div>
            </div>
            {ignError && (
              <p className="mt-1.5 text-xs text-red-400 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Please enter your in-game name for reward delivery!
              </p>
            )}

            {/* Optional Discord Tag */}
            <div className="mt-3">
              <label className="block text-xs font-medium text-slate-400 mb-1">
                Discord Tag (Optional for role sync):
              </label>
              <input
                type="text"
                placeholder="e.g. avihaan#0001 or @user"
                value={discordTag}
                onChange={e => setDiscordTag(e.target.value)}
                className="w-full px-3.5 py-1.5 rounded-lg bg-slate-800/60 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-slate-500"
              />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-500">
                <ShoppingBag className="w-12 h-12 text-slate-700 mb-3 stroke-[1.5]" />
                <p className="text-base font-semibold text-slate-300">Your cart is empty</p>
                <p className="text-xs text-slate-500 mt-1 max-w-xs">
                  Browse our ranks, crate keys, and kits to dominate the server!
                </p>
              </div>
            ) : (
              items.map(item => (
                <div
                  key={item.product.id}
                  className="p-4 rounded-xl bg-slate-800/50 border border-slate-800 flex items-center justify-between gap-3"
                >
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-bold text-white truncate">{item.product.name}</h4>
                    <span className="text-xs text-amber-400 font-semibold">
                      {config.currencySymbol}{item.product.price} each
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                      className="w-7 h-7 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 flex items-center justify-center transition-colors"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-6 text-center text-sm font-bold text-white">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                      className="w-7 h-7 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 flex items-center justify-center transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => removeItem(item.product.id)}
                      className="p-1.5 text-slate-500 hover:text-red-400 transition-colors ml-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Coupon Code Input */}
          {items.length > 0 && (
            <div className="px-6 py-3 border-t border-slate-800/80 bg-slate-950/20">
              {appliedCoupon ? (
                <div className="flex items-center justify-between bg-emerald-950/40 border border-emerald-500/30 px-3.5 py-2 rounded-xl text-xs text-emerald-300">
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4 text-emerald-400" />
                    <span>Coupon <strong>{appliedCoupon.code}</strong> ({appliedCoupon.discountPercent}% OFF)</span>
                  </div>
                  <button
                    onClick={removeCoupon}
                    className="text-slate-400 hover:text-white text-xs underline font-semibold"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Coupon code (e.g. WONDER20)"
                    value={couponInput}
                    onChange={e => setCouponInput(e.target.value)}
                    className="flex-1 px-3.5 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-white placeholder-slate-500 uppercase focus:outline-none focus:border-amber-500"
                  />
                  <button
                    type="submit"
                    disabled={couponLoading}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold border border-slate-700 transition-colors"
                  >
                    {couponLoading ? 'Checking...' : 'Apply'}
                  </button>
                </form>
              )}
              {couponFeedback && (
                <p className={`mt-1.5 text-xs ${couponFeedback.error ? 'text-red-400' : 'text-emerald-400'}`}>
                  {couponFeedback.msg}
                </p>
              )}
            </div>
          )}

          {/* Drawer Footer & Checkout Action */}
          {items.length > 0 && (
            <div className="p-6 border-t border-slate-800 bg-slate-950/60 space-y-3">
              <div className="space-y-1.5 text-sm">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal</span>
                  <span>{config.currencySymbol}{subtotal}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400 font-medium">
                    <span>Discount</span>
                    <span>-{config.currencySymbol}{discountAmount}</span>
                  </div>
                )}
                <div className="flex justify-between text-white font-extrabold text-base pt-2 border-t border-slate-800">
                  <span>Total Due</span>
                  <span className="text-amber-400 text-xl font-black">
                    {config.currencySymbol}{finalTotal}
                  </span>
                </div>
              </div>

              <button
                onClick={handleCheckoutClick}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-98 transition-all"
              >
                <span>Proceed to UPI Payment</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-center text-[11px] text-slate-500">
                Instant automatic in-game activation on WonderMc via Indian UPI
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
