import React from 'react';
import { Heart, ShieldCheck, MessageSquare, ExternalLink } from 'lucide-react';
import { useStoreConfig } from '../context/StoreConfigContext';

export const Footer: React.FC = () => {
  const { config } = useStoreConfig();

  return (
    <footer className="mt-20 border-t border-slate-800/80 bg-slate-950/80 py-12 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          <div className="space-y-2">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <span className="font-black text-white text-base tracking-tight">WONDERMC NETWORK</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                Online 24/7
              </span>
            </div>
            <p className="text-slate-500 max-w-md">
              The premier Minecraft Crossplay BoxPvP & Lifesteal SMP server. Join thousands of active warriors today.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 font-semibold">
            <a href={config.discordUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
              Discord
            </a>
            <span className="text-slate-700">•</span>
            <span className="text-slate-300">Java: <code>play.wondermc.fun</code></span>
            <span className="text-slate-700">•</span>
            <span className="text-slate-300">Bedrock Port: <code>19132</code></span>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-600 text-[11px] text-center sm:text-left">
          <p>
            © {new Date().getFullYear()} WonderMc Network. All rights reserved. Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.
          </p>
          <p className="flex items-center justify-center gap-1">
            Built with <Heart className="w-3 h-3 text-red-500 fill-red-500" /> for the WonderMc community
          </p>
        </div>
      </div>
    </footer>
  );
};
