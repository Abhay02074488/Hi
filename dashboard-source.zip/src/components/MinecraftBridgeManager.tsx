import React, { useState, useEffect } from 'react';
import {
  Link2,
  Sparkles,
  Shield,
  Copy,
  Check,
  RefreshCw,
  Terminal,
  ExternalLink,
  Trash2,
  Download,
  CheckCircle2,
  Users,
  MessageSquare,
  FileCode,
  Zap,
  ArrowRightLeft,
  Key,
  Globe
} from 'lucide-react';
import { useToast } from '../context/ToastContext';

interface LinkedAccount {
  discord_id: string;
  discord_tag: string;
  minecraft_uuid: string;
  minecraft_username: string;
  linked_at: string;
  verified: boolean;
}

interface PendingCode {
  code: string;
  minecraft_username: string;
  minecraft_uuid: string;
  created_at: string;
  expires_at: number;
}

interface BridgeConfig {
  secret_token: string;
  chat_channel_id: string | null;
  console_channel_id: string | null;
  link_role_name: string;
  link_role_id: string | null;
  auto_sync_roles: boolean;
}

interface ChatMessage {
  source: 'minecraft' | 'discord';
  username: string;
  message: string;
  timestamp: string;
}

export const MinecraftBridgeManager: React.FC = () => {
  const { showToast } = useToast();

  const [linkedAccounts, setLinkedAccounts] = useState<Record<string, LinkedAccount>>({});
  const [pendingCodes, setPendingCodes] = useState<Record<string, PendingCode>>({});
  const [bridgeConfig, setBridgeConfig] = useState<BridgeConfig>({
    secret_token: 'wondermc_srv_2026',
    chat_channel_id: null,
    console_channel_id: null,
    link_role_name: 'Linked',
    link_role_id: null,
    auto_sync_roles: true
  });
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [serverUrl, setServerUrl] = useState('Loading…');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Test Link Generator
  const [testPlayer, setTestPlayer] = useState('Avihaan_PvP');
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'linked' | 'installation' | 'chat'>('overview');

  useEffect(() => {
    fetch('/api/bridge/info').then(r => r.json()).then(d => { if (d?.url) setServerUrl(d.url); }).catch(() => {});
    fetchBridgeStatus();
    const interval = setInterval(fetchBridgeStatus, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchBridgeStatus = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/minecraft/bridge/status');
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setLinkedAccounts(data.linked_accounts || {});
          setPendingCodes(data.pending_codes || {});
          if (data.bridge_config) setBridgeConfig(data.bridge_config);
          if (data.chat_history) setChatHistory(data.chat_history);
          if (data.server_url) setServerUrl(data.server_url);
        }
      }
    } catch {
      // Keep state
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    showToast(`Copied ${label} to clipboard!`, 'success');
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleGenerateTestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testPlayer.trim()) return;

    try {
      const res = await fetch('/api/minecraft/bridge/link-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          secret: bridgeConfig.secret_token,
          username: testPlayer.trim(),
          uuid: '069a79f4-44e9-4726-a5be-fca90e38aaf5'
        })
      });
      const data = await res.json();
      if (data.success) {
        setGeneratedCode(data.code);
        showToast(`Generated code ${data.code} for ${testPlayer}!`, 'success');
        fetchBridgeStatus();
      }
    } catch {
      showToast('Error generating code', 'error');
    }
  };

  const handleUnlink = async (discord_id: string, ign: string) => {
    try {
      const res = await fetch('/api/minecraft/bridge/unlink', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ discord_id })
      });
      if (res.ok) {
        showToast(`Unlinked ${ign}`, 'info');
        fetchBridgeStatus();
      }
    } catch {
      showToast('Error unlinking', 'error');
    }
  };

  const linkedCount = Object.keys(linkedAccounts).length;
  const pendingCount = Object.keys(pendingCodes).length;

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 p-6 sm:p-8 text-white shadow-2xl border border-emerald-700/40">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 backdrop-blur-md border border-emerald-500/30 text-xs font-bold uppercase tracking-wider text-emerald-300">
              <Zap className="w-3.5 h-3.5" /> Minecraft 1.21.1 Direct DiscordSRV Bridge
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Unified Minecraft & Discord Bot Integration
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              No separate DiscordSRV bot or duplicate database! Both your Minecraft 1.21.1 server and your custom Discord Bot share the exact same database (<code>data/minecraft_linked.json</code>) with 2-way chat sync, in-game <code>/link</code>, and role grants.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="px-5 py-3 rounded-2xl bg-slate-950/70 backdrop-blur-md border border-emerald-500/30 text-center">
              <span className="text-[11px] uppercase tracking-wider text-emerald-400 font-bold block">Linked Players</span>
              <span className="text-2xl font-black text-white">{linkedCount}</span>
            </div>
            <div className="px-5 py-3 rounded-2xl bg-slate-950/70 backdrop-blur-md border border-slate-700 text-center">
              <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold block">Version</span>
              <span className="text-xl font-black text-amber-400">1.21.1+</span>
            </div>
            <button
              onClick={fetchBridgeStatus}
              disabled={isLoading}
              className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-all active:scale-95"
              title="Refresh"
            >
              <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'overview'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Zap className="w-4 h-4" />
          <span>Bridge Overview & Connection</span>
        </button>

        <button
          onClick={() => setActiveTab('linked')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'linked'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Linked Players ({linkedCount})</span>
        </button>

        <button
          onClick={() => setActiveTab('installation')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'installation'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Download className="w-4 h-4" />
          <span>Plugin Setup & Skript (1.21.1)</span>
        </button>

        <button
          onClick={() => setActiveTab('chat')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'chat'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Cross-Platform Chat Stream</span>
        </button>
      </div>

      {/* Tab 1: Overview & Connection */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Connection Details (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="p-2.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Bridge Server Connection Parameters</h3>
                <p className="text-xs text-slate-400">
                  Use these credentials in your Minecraft server's <code>WonderBridge.sk</code> or <code>config.yml</code>.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Bot URL */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Bot URL (your host's address + bridge port)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={serverUrl}
                    className="flex-1 px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-emerald-400 font-mono text-xs"
                  />
                  <button
                    onClick={() => handleCopy(serverUrl, 'Bot URL')}
                    className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition-colors"
                  >
                    {copiedKey === 'Bot URL' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Secret Key */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Secret Authentication Key
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={bridgeConfig.secret_token}
                    className="flex-1 px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-amber-400 font-mono text-xs"
                  />
                  <button
                    onClick={() => handleCopy(bridgeConfig.secret_token, 'Secret Key')}
                    className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition-colors"
                  >
                    {copiedKey === 'Secret Key' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Saved in <code>data/minecraft_linked.json</code>. Prevents unauthorized servers from sending fake chat.
                </p>
              </div>

              {/* Features Active */}
              <div className="pt-4 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-slate-300">2-Way Chat Synchronization</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-slate-300">In-Game <code>/link</code> 6-Digit Code</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-slate-300">Join, Quit & Death Discord Alerts</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-slate-300">Auto Role Grant on Verify</span>
                </div>
              </div>
            </div>
          </div>

          {/* Test Link Generator (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                <Key className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Test <code>/link</code> Flow</h3>
                <p className="text-xs text-slate-400">Simulate an in-game <code>/link</code> request.</p>
              </div>
            </div>

            <form onSubmit={handleGenerateTestCode} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Minecraft Username
                </label>
                <input
                  type="text"
                  value={testPlayer}
                  onChange={e => setTestPlayer(e.target.value)}
                  placeholder="e.g. Avihaan_PvP"
                  className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all active:scale-98"
              >
                <Zap className="w-4 h-4" />
                <span>Simulate In-Game /link</span>
              </button>
            </form>

            {generatedCode && (
              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-600/40 space-y-2">
                <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider block">
                  Generated Code for {testPlayer}:
                </span>
                <div className="flex items-center justify-between">
                  <span className="text-3xl font-black text-amber-400 font-mono tracking-widest">
                    {generatedCode}
                  </span>
                  <button
                    onClick={() => handleCopy(`/link code:${generatedCode}`, 'Discord Command')}
                    className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold"
                  >
                    Copy Discord Command
                  </button>
                </div>
                <p className="text-[11px] text-slate-300 mt-1">
                  In Discord, run: <code className="text-emerald-300 font-mono">/link code:{generatedCode}</code>
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Linked Players */}
      {activeTab === 'linked' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-lg font-bold text-white">Linked Players Directory</h3>
              <p className="text-xs text-slate-400">
                All players whose Minecraft account is paired with their Discord profile in <code>data/minecraft_linked.json</code>.
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold">
              {linkedCount} Total Verified
            </span>
          </div>

          {linkedCount === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-slate-950/40 border border-slate-800 space-y-2">
              <Users className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-slate-400 text-xs">No players linked yet. Join the server and run /link!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(Object.entries(linkedAccounts) as [string, LinkedAccount][]).map(([discordId, info]) => (
                <div
                  key={discordId}
                  className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between gap-3 shadow-md"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={`https://mc-heads.net/avatar/${info.minecraft_username}/64.png`}
                      alt={info.minecraft_username}
                      className="w-12 h-12 rounded-xl border border-slate-600 bg-slate-900 shrink-0"
                    />
                    <div className="min-w-0">
                      <h4 className="text-sm font-bold text-white truncate">{info.minecraft_username}</h4>
                      <p className="text-[11px] text-indigo-400 font-mono truncate">{info.discord_tag}</p>
                      <p className="text-[10px] text-slate-500">ID: {discordId}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleUnlink(discordId, info.minecraft_username)}
                    className="p-2 text-slate-500 hover:text-red-400 hover:bg-slate-700 rounded-xl transition-colors"
                    title="Unlink Account"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Installation & Skript */}
      {activeTab === 'installation' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-8">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
            <div className="p-2.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">How to Install WonderBridge on Minecraft 1.21.1</h3>
              <p className="text-xs text-slate-400">
                Choose the installation method that fits your server setup.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Method 1: Compiled WonderBridge.jar (Direct Download) */}
            <div className="p-6 rounded-2xl bg-slate-950/60 border border-emerald-500/40 space-y-4 shadow-lg shadow-emerald-950/20">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  COMPILED .JAR (1.21.1+)
                </span>
                <span className="text-[11px] text-emerald-400 font-bold">Paper / Purpur / Spigot</span>
              </div>

              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <span>WonderBridge.jar</span>
                <span className="text-xs text-slate-400 font-normal">(Compiled & Ready)</span>
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Directly drop this compiled <strong>.jar</strong> into your server's <code>plugins/</code> folder. Built with modern Java 21 async HTTP client for 0% server lag.
              </p>

              {/* Direct Download Button */}
              <div className="flex flex-col sm:flex-row gap-2 pt-2">
                <a
                  href="/WonderBridge.jar"
                  download="WonderBridge.jar"
                  className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all active:scale-98"
                >
                  <Download className="w-4 h-4 stroke-[2.5]" />
                  <span>Download WonderBridge.jar</span>
                </a>
              </div>

              {/* Fast Install Steps */}
              <div className="space-y-2 text-xs text-slate-300 pt-2 border-t border-slate-800">
                <div className="flex items-start gap-2">
                  <span className="font-bold text-emerald-400">1.</span>
                  <span>Place <code>WonderBridge.jar</code> into your server's <code>plugins/</code> folder.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-bold text-emerald-400">2.</span>
                  <span>Restart your Minecraft server.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-bold text-emerald-400">3.</span>
                  <span>In <code>plugins/WonderBridge/config.yml</code>, verify:
                    <div className="mt-1 p-2 rounded-lg bg-slate-900 border border-slate-800 font-mono text-[11px] text-amber-300">
                      bot-url: "{serverUrl}"<br/>
                      secret-token: "{bridgeConfig.secret_token}"
                    </div>
                  </span>
                </div>
              </div>
            </div>

            {/* Method 2: Discord Bot Prefix wm Commands */}
            <div className="p-6 rounded-2xl bg-slate-950/60 border border-indigo-500/40 space-y-4 shadow-lg shadow-indigo-950/20">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                  DISCORD BOT (PREFIX: wm)
                </span>
                <span className="text-[11px] text-indigo-400 font-bold">wm & / Slash</span>
              </div>

              <h4 className="text-base font-bold text-white">Bot Commands with Prefix <code className="text-amber-400 font-mono">wm</code></h4>

              <div className="space-y-2.5 text-xs">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <span className="font-mono font-bold text-emerald-400 block">wm link &lt;code&gt;</span>
                    <span className="text-slate-400 text-[11px]">Links Minecraft account (or <code>/link code:&lt;code&gt;</code>)</span>
                  </div>
                  <button
                    onClick={() => handleCopy('wm link 581942', 'Command')}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <span className="font-mono font-bold text-sky-400 block">wm whois &lt;player_or_@user&gt;</span>
                    <span className="text-slate-400 text-[11px]">Shows 3D skin, UUID, and Discord link profile</span>
                  </div>
                  <button
                    onClick={() => handleCopy('wm whois Avihaan_PvP', 'Command')}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <span className="font-mono font-bold text-amber-400 block">wm unlink</span>
                    <span className="text-slate-400 text-[11px]">Unlinks your Minecraft account from Discord</span>
                  </div>
                  <button
                    onClick={() => handleCopy('wm unlink', 'Command')}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <span className="font-mono font-bold text-purple-400 block">wm rcon &lt;command&gt;</span>
                    <span className="text-slate-400 text-[11px]">Execute console command (e.g. <code>wm rcon kick Steve</code>)</span>
                  </div>
                  <button
                    onClick={() => handleCopy('wm rcon say Hello WonderMc!', 'Command')}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <span className="font-mono font-bold text-emerald-300 block">/mcbridge set_channel #minecraft-chat</span>
                    <span className="text-slate-400 text-[11px]">Admin command to set two-way sync chat channel</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Live Chat Stream */}
      {activeTab === 'chat' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-lg font-bold text-white">Cross-Platform Live Chat Feed</h3>
              <p className="text-xs text-slate-400">
                Real-time messages sent between Minecraft in-game chat and Discord.
              </p>
            </div>
            <button
              onClick={fetchBridgeStatus}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
            {chatHistory.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-8">
                No chat messages recorded yet. Type in Minecraft or in your Discord chat channel to test!
              </p>
            ) : (
              chatHistory.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs"
                >
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    item.source === 'minecraft' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-indigo-500/20 text-indigo-400'
                  }`}>
                    {item.source === 'minecraft' ? 'MINECRAFT' : 'DISCORD'}
                  </span>
                  <span className="font-bold text-white">{item.username}:</span>
                  <span className="text-slate-200">{item.message}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
