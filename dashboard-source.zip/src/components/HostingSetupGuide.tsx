import React, { useState } from 'react';
import {
  Server,
  Terminal,
  Cpu,
  Copy,
  Check,
  Download,
  ExternalLink,
  Shield,
  Layers,
  Sparkles,
  Zap,
  HardDrive,
  Globe,
  Radio,
  FileCode,
  FolderTree,
  AlertCircle
} from 'lucide-react';

export const HostingSetupGuide: React.FC = () => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeGuideTab, setActiveGuideTab] = useState<'java_only' | 'pterodactyl' | 'vps_linux' | 'python_dc'>('java_only');

  const copyCode = (key: string, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const javaCompileCommand = `javac WonderWebServer.java
java WonderWebServer 3000`;

  const pterodactylStartup = `java -Xms128M -Xmx512M -jar WonderWebServer.jar {{SERVER_PORT}}`;

  const systemdService = `[Unit]
Description=WonderMc Web & Bot Panel
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/home/wondermc
ExecStart=/usr/bin/java WonderWebServer 3000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target`;

  const pythonBotRun = `# 1. Install dependencies
pip install discord.py requests

# 2. Run the bot with persistent cogs
python main.py`;

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Zero-Dependency Standalone Architecture</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              Host Setup & Deployment Guide
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Step-by-step instructions to run the web panel and Discord bot on machines with <strong className="text-emerald-400">only Java</strong>, Pterodactyl game panels, VPS Linux, or Python bot hosts.
            </p>
          </div>

          <div className="flex flex-col items-center justify-center p-4 bg-slate-950/80 border border-slate-800 rounded-2xl shrink-0 text-center">
            <div className="text-xs font-semibold text-slate-400">Target Server</div>
            <div className="text-base font-bold text-emerald-400 font-mono mt-0.5">play.wondermc.fun</div>
            <div className="text-[10px] text-slate-500 mt-1">Crossplay Java & Bedrock</div>
          </div>
        </div>
      </div>

      {/* Guide Tabs */}
      <div className="flex flex-wrap items-center gap-2 bg-slate-900 border border-slate-800 p-1.5 rounded-2xl">
        <button
          onClick={() => setActiveGuideTab('java_only')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeGuideTab === 'java_only'
              ? 'bg-emerald-500 text-black shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>1. Java-Only Machine</span>
        </button>

        <button
          onClick={() => setActiveGuideTab('pterodactyl')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeGuideTab === 'pterodactyl'
              ? 'bg-indigo-500 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>2. Pterodactyl / Bot Host Panel</span>
        </button>

        <button
          onClick={() => setActiveGuideTab('vps_linux')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeGuideTab === 'vps_linux'
              ? 'bg-cyan-500 text-black shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <HardDrive className="w-4 h-4" />
          <span>3. Linux VPS (24/7 Service)</span>
        </button>

        <button
          onClick={() => setActiveGuideTab('python_dc')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeGuideTab === 'python_dc'
              ? 'bg-purple-500 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Radio className="w-4 h-4" />
          <span>4. Python Discord Bot</span>
        </button>
      </div>

      {/* TAB 1: JAVA ONLY MACHINE */}
      {activeGuideTab === 'java_only' && (
        <div className="space-y-6 animate-in fade-in">
          
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-6">
            
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-black text-lg">
                ☕
              </div>
              <div>
                <h3 className="text-base font-bold text-white">How to Run on Machine with ONLY Java</h3>
                <p className="text-xs text-slate-400">Uses Java's built-in <code>com.sun.net.httpserver</code>. No NPM or Python needed!</p>
              </div>
            </div>

            {/* Folder Layout */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <FolderTree className="w-4 h-4 text-emerald-400" />
                <span>Recommended Server Directory Layout:</span>
              </div>
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto">
                <p className="text-emerald-400 font-bold">/your-server-folder/</p>
                <p className="pl-4">├── <span className="text-cyan-300">WonderWebServer.java</span> (or compiled WonderWebServer.jar)</p>
                <p className="pl-4">├── <span className="text-amber-300">dist/</span> (The built website HTML, JS, CSS files)</p>
                <p className="pl-4">│   ├── index.html</p>
                <p className="pl-4">│   └── assets/</p>
                <p className="pl-4">├── <span className="text-indigo-300">transcripts/</span> (Auto-created folder for WonderMc ticket .txt logs)</p>
                <p className="pl-4">└── <span className="text-purple-300">data/</span> (Auto-created folder for levels_data.json & tickets)</p>
              </div>
            </div>

            {/* Step-by-Step Instructions */}
            <div className="space-y-4">
              <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Step-by-Step Execution:
              </div>

              {/* Step 1 */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-[10px]">1</span>
                    <span>Download or create <code className="text-white">WonderWebServer.java</code> on your server</span>
                  </div>
                </div>
                <p className="text-xs text-slate-400">
                  This file is already included in your project root! It has zero external dependencies and runs on Java 8, 11, 17, 21+.
                </p>
              </div>

              {/* Step 2 */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-cyan-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-[10px]">2</span>
                    <span>Compile and Run via Terminal / SSH</span>
                  </div>
                  <button
                    onClick={() => copyCode('java_cmd', javaCompileCommand)}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-900 border border-slate-800 transition cursor-pointer flex items-center gap-1 text-[11px]"
                  >
                    {copiedKey === 'java_cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'java_cmd' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="bg-slate-900 p-3 rounded-xl font-mono text-xs text-emerald-400 overflow-x-auto">
                  {javaCompileCommand}
                </pre>
              </div>

              {/* Step 3 */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-amber-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center text-[10px]">3</span>
                    <span>Package as a runnable .JAR file (Optional)</span>
                  </div>
                </div>
                <pre className="bg-slate-900 p-3 rounded-xl font-mono text-xs text-slate-300 overflow-x-auto">
                  {`# Create manifest with Main-Class
echo "Main-Class: WonderWebServer" > manifest.txt
jar cfm WonderWebServer.jar manifest.txt WonderWebServer*.class
# Run with single command:
java -jar WonderWebServer.jar 3000`}
                </pre>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* TAB 2: PTERODACTYL / BOT HOSTING PANEL */}
      {activeGuideTab === 'pterodactyl' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-6">
            
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-black text-lg">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Pterodactyl / Discord Bot Hosting Panel Setup</h3>
                <p className="text-xs text-slate-400">For services like Bot-Hosting.net, FalixNodes, Pterodactyl, PebbleHost, BisectHosting</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <div className="text-xs font-bold text-indigo-400 flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  <span>1. Check Port Allocation</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Go to your Pterodactyl panel's <strong>"Network" / "Allocations"</strong> tab. Note the primary port assigned (e.g., <code className="text-emerald-400">25580</code> or <code className="text-cyan-400">19135</code>).
                </p>
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 text-[11px] text-slate-400">
                  Java automatically reads the <code>PORT</code> environment variable or port argument from startup.
                </div>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <div className="text-xs font-bold text-cyan-400 flex items-center gap-2">
                  <FileCode className="w-4 h-4" />
                  <span>2. Startup Command</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Set the startup command in your host panel:
                </p>
                <pre className="bg-slate-900 p-2.5 rounded-xl font-mono text-xs text-cyan-400 overflow-x-auto">
                  {pterodactylStartup}
                </pre>
              </div>

            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
              <div className="text-xs font-bold text-slate-200">How to Upload Files to Panel:</div>
              <ul className="text-xs text-slate-400 space-y-1.5 list-disc pl-5">
                <li>Use the panel's <strong>"File Manager"</strong> or connect via <strong>SFTP</strong> (FileZilla / WinSCP).</li>
                <li>Upload <code className="text-emerald-400">WonderWebServer.jar</code> into the root directory.</li>
                <li>Upload the <code className="text-cyan-400">dist/</code> folder containing the web assets.</li>
                <li>Click <strong>Start / Restart</strong> in your control panel.</li>
              </ul>
            </div>

          </div>
        </div>
      )}

      {/* TAB 3: LINUX VPS SERVICE (SYSTEMD) */}
      {activeGuideTab === 'vps_linux' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-6">
            
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-black text-lg">
                <HardDrive className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">24/7 Linux Systemd Background Service</h3>
                <p className="text-xs text-slate-400">Automatically boots on server start and auto-restarts on crash</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">
                  Create Service: <code className="text-cyan-300">/etc/systemd/system/wondermc.service</code>
                </span>
                <button
                  onClick={() => copyCode('service_file', systemdService)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-950 border border-slate-800 transition cursor-pointer flex items-center gap-1 text-[11px]"
                >
                  {copiedKey === 'service_file' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'service_file' ? 'Copied' : 'Copy Service File'}</span>
                </button>
              </div>
              <pre className="bg-slate-950 p-4 rounded-2xl font-mono text-xs text-cyan-300 border border-slate-800 overflow-x-auto">
                {systemdService}
              </pre>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-300">Enable and Start the Service:</div>
              <pre className="bg-slate-950 p-3.5 rounded-xl font-mono text-xs text-emerald-400 border border-slate-800 overflow-x-auto">
                {`sudo systemctl daemon-reload
sudo systemctl enable wondermc
sudo systemctl start wondermc
sudo systemctl status wondermc`}
              </pre>
            </div>

          </div>
        </div>
      )}

      {/* TAB 4: PYTHON DISCORD BOT */}
      {activeGuideTab === 'python_dc' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-6">
            
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400 font-black text-lg">
                🐍
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Running the Python Discord Bot Cogs</h3>
                <p className="text-xs text-slate-400">Includes Tickets, Transcripts, /web_panel, Leveling (+15 XP msg, +20 XP/min VC), and Minigames</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">Setup Commands:</span>
                <button
                  onClick={() => copyCode('py_cmd', pythonBotRun)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-950 border border-slate-800 transition cursor-pointer flex items-center gap-1 text-[11px]"
                >
                  {copiedKey === 'py_cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'py_cmd' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <pre className="bg-slate-950 p-4 rounded-2xl font-mono text-xs text-purple-300 border border-slate-800 overflow-x-auto">
                {pythonBotRun}
              </pre>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2 text-xs">
              <div className="font-bold text-emerald-400">Included Cogs in this project:</div>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300 pt-1">
                <li className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <strong className="text-indigo-300 font-mono">cogs/ticket.py</strong>: Button panels, WonderMc logs, restart persistent view
                </li>
                <li className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <strong className="text-emerald-300 font-mono">cogs/leveling.py</strong>: +15 XP chat, +20 XP/min VC tracking
                </li>
                <li className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <strong className="text-cyan-300 font-mono">cogs/web_panel.py</strong>: /web_panel interactive embed with status links
                </li>
                <li className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <strong className="text-amber-300 font-mono">cogs/minigames.py</strong> & <strong className="text-amber-300 font-mono">cogs/blackjack.py</strong>: Playable in-chat games
                </li>
              </ul>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
