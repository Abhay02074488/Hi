import React from 'react';
import { Calendar, Tag, Sparkles, CheckCircle2, ChevronRight } from 'lucide-react';
import { DEFAULT_SERVER_UPDATES } from '../data/storeData';

export const UpdatesPage: React.FC = () => {
  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Title */}
      <div className="text-center space-y-2 mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" /> Changelogs & Patch Notes
        </div>
        <h2 className="text-3xl font-black text-white">Server Updates</h2>
        <p className="text-sm text-slate-400">
          Stay up to date with the latest features, balance patches, and community additions on WonderMc.
        </p>
      </div>

      {/* Updates Timeline */}
      <div className="space-y-6">
        {DEFAULT_SERVER_UPDATES.map((update, idx) => (
          <div
            key={update.id}
            className="relative p-6 sm:p-8 rounded-3xl bg-slate-900/70 border border-slate-800 shadow-xl overflow-hidden"
          >
            {/* Version & Date */}
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-2.5">
                <span className="px-3 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono font-bold text-xs">
                  {update.version}
                </span>
                <span className="px-2.5 py-0.5 rounded-md bg-slate-800 text-slate-300 text-xs font-semibold uppercase tracking-wider">
                  {update.category}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                <span>{update.date}</span>
              </div>
            </div>

            {/* Title */}
            <h3 className="text-xl font-black text-white mb-2">{update.title}</h3>
            <p className="text-sm text-slate-400 leading-relaxed mb-6">{update.description}</p>

            {/* Feature Highlights */}
            <div className="space-y-2.5 pt-4 border-t border-slate-800/80">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Key Changes in this Update:
              </h4>
              <div className="grid grid-cols-1 gap-2">
                {update.highlights.map((item, hIdx) => (
                  <div key={hIdx} className="flex items-start gap-2.5 text-xs text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
