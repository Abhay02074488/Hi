import React, { useState } from 'react';
import {
  Ticket,
  Plus,
  Send,
  FileText,
  Lock,
  Unlock,
  UserCheck,
  Trash2,
  Mail,
  CheckCircle2,
  Server,
  FolderDown,
  AlertCircle,
  ShoppingCart
} from 'lucide-react';
import { TicketSystemState } from '../types';

interface TicketSimulatorProps {
  state: TicketSystemState;
  onUpdateState: (newState: TicketSystemState) => void;
  onSaveTranscript: (data: {
    channelName: string;
    openerUser: string;
    category: string;
    targetDmUser?: string;
    messages: Array<{ author: string; content: string; timestamp: string }>;
  }) => Promise<void>;
  onRefreshTranscripts: () => void;
}

export const TicketSimulator: React.FC<TicketSimulatorProps> = ({
  state,
  onUpdateState,
  onSaveTranscript,
  onRefreshTranscripts
}) => {
  // Setup panel form state
  const [panelTitle, setPanelTitle] = useState("WonderMc Support Ticket");
  const [panelChannel, setPanelChannel] = useState("support-tickets");
  const [panelCategory, setPanelCategory] = useState("Support");

  // Selected active ticket simulation
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [targetDmUser, setTargetDmUser] = useState("");
  const [actionStatus, setActionStatus] = useState<string | null>(null);
  const [showCart, setShowCart] = useState(false);
  const [cart, setCart] = useState<Array<{ id: string; name: string; price_inr: number; price_usd: number }>>([
    { id: "rank_immortal", name: "👑 Immortal Rank", price_inr: 899, price_usd: 11 }
  ]);

  // New ticket form
  const [openerName, setOpenerUser] = useState("Avihaan#911");
  const [ticketCategory, setSelectedCategory] = useState("General");
  const [customIssue, setCustomIssue] = useState("I need help restoring my rank permissions on the server.");
  const [embedPreviewTab, setEmbedPreviewTab] = useState<'ticket' | 'welcome'>('ticket');

  // Handle Create New Panel
  const handleCreatePanel = () => {
    const newPanel = {
      guild_id: "1029384756",
      channel_id: `ch_${Date.now()}`,
      message_id: `msg_${Date.now()}`,
      title: panelTitle,
      created_at: new Date().toISOString()
    };

    const updatedPanels = [newPanel, ...state.panels_log];
    const updatedDb = {
      ...state.ticket_db,
      [newPanel.channel_id]: {
        title: panelTitle,
        channel: panelChannel,
        category: panelCategory
      }
    };

    const newState = {
      ...state,
      ticket_db: updatedDb,
      panels_log: updatedPanels
    };

    onUpdateState(newState);
    setActionStatus(`✅ Registered new persistent ticket panel "${panelTitle}" in #${panelChannel} and saved to ./data/tickets_data.json!`);
    setTimeout(() => setActionStatus(null), 4000);
  };

  // Handle Open Ticket
  const handleOpenTicket = () => {
    const ticketId = `ch_ticket_${Date.now()}`;
    const newTicket = {
      user_id: openerName,
      guild_id: "1029384756",
      claimed_by: null,
      category: ticketCategory,
      created_at: new Date().toISOString(),
      channel_name: `${ticketCategory.toLowerCase()}-${openerName.toLowerCase().replace(/[^a-z0-9]/g, '')}-${Object.keys(state.open_tickets).length + 1}`,
      status: "OPEN",
      messages: [
        {
          author: openerName,
          content: customIssue || "Ticket opened automatically.",
          timestamp: new Date().toLocaleTimeString()
        }
      ]
    };

    const updatedOpen = {
      ...state.open_tickets,
      [ticketId]: newTicket
    };

    const newState = {
      ...state,
      open_tickets: updatedOpen
    };

    onUpdateState(newState);
    setSelectedTicketId(ticketId);
    setActionStatus(`🎉 Ticket #${newTicket.channel_name} opened! Open state persisted to disk.`);
    setTimeout(() => setActionStatus(null), 4000);
  };

  // Handle Claim Ticket
  const handleClaimTicket = (ticketId: string) => {
    const ticket = state.open_tickets[ticketId];
    if (!ticket) return;

    const updated = {
      ...state,
      open_tickets: {
        ...state.open_tickets,
        [ticketId]: {
          ...ticket,
          claimed_by: "ModTeam_Alex",
          messages: [
            ...ticket.messages,
            {
              author: "ModTeam_Alex",
              content: "Hello! I am claiming this ticket and will be assisting you shortly.",
              timestamp: new Date().toLocaleTimeString()
            }
          ]
        }
      }
    };

    onUpdateState(updated);
    setActionStatus(`✅ Ticket #${ticket.channel_name} claimed by ModTeam_Alex! Updated state saved to disk.`);
    setTimeout(() => setActionStatus(null), 3000);
  };

  // Handle Send DM & Save Transcript
  const handleSendDmTranscript = async (ticketId: string) => {
    const ticket = state.open_tickets[ticketId];
    if (!ticket) return;

    const dmRecipient = targetDmUser.trim() || ticket.user_id;

    await onSaveTranscript({
      channelName: ticket.channel_name || "ticket-channel",
      openerUser: ticket.user_id,
      category: ticket.category,
      targetDmUser: dmRecipient,
      messages: ticket.messages || []
    });

    onRefreshTranscripts();
    setActionStatus(`📩 Transcript exported to machine folder ./transcripts/ AND sent to ${dmRecipient}'s DM!`);
    setTimeout(() => setActionStatus(null), 5000);
  };

  // Handle Delete Ticket with Transcript
  const handleDeleteWithTranscript = async (ticketId: string) => {
    const ticket = state.open_tickets[ticketId];
    if (!ticket) return;

    await onSaveTranscript({
      channelName: ticket.channel_name || "ticket-channel",
      openerUser: ticket.user_id,
      category: ticket.category,
      targetDmUser: targetDmUser.trim() || ticket.user_id,
      messages: ticket.messages || []
    });

    const updatedOpen = { ...state.open_tickets };
    delete updatedOpen[ticketId];

    onUpdateState({
      ...state,
      open_tickets: updatedOpen
    });

    if (selectedTicketId === ticketId) {
      setSelectedTicketId(null);
    }

    onRefreshTranscripts();
    setActionStatus(`📝 Ticket deleted! Full transcript saved to local machine folder and DM'd.`);
    setTimeout(() => setActionStatus(null), 5000);
  };

  const activeTicket = selectedTicketId ? state.open_tickets[selectedTicketId] : null;

  return (
    <div className="space-y-6">
      
      {/* Alert Notification */}
      {actionStatus && (
        <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs flex items-center gap-2 animate-fade-in shadow-md">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionStatus}</span>
        </div>
      )}

      {/* Feature Bug Fix Explanation Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-cyan-400">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                Persistent Panels & Local Machine Transcript System
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Fixes panel buttons breaking after bot restart & adds automatic transcript DMs + machine disk logging.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-800 text-xs text-slate-300">
          <div className="space-y-1.5 bg-slate-800/40 p-3 rounded-xl border border-slate-700/40">
            <span className="font-semibold text-cyan-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> 1. Restart Persistence Bug Fix
            </span>
            <p className="text-slate-400 leading-relaxed">
              When the bot starts, it reads <code className="text-cyan-300">./data/tickets_data.json</code> and re-registers the persistent view (<code className="text-cyan-300">TicketOpenView</code> & <code className="text-cyan-300">TicketAllView</code>) using <code className="text-cyan-300">bot.add_view()</code> so old buttons never break.
            </p>
          </div>

          <div className="space-y-1.5 bg-slate-800/40 p-3 rounded-xl border border-slate-700/40">
            <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <FolderDown className="w-3.5 h-3.5" /> 2. Machine Upload & DM Delivery
            </span>
            <p className="text-slate-400 leading-relaxed">
              Closing or exporting a ticket generates a formatted transcript, uploads it as a <code className="text-emerald-300">.txt</code> file in <code className="text-emerald-300">./transcripts/</code> on the machine, and delivers it to the target user's DM.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Panel & Ticket Creator */}
        <div className="space-y-6 lg:col-span-1">
          
          {/* Panel Setup Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center gap-2 mb-4">
              <Plus className="w-4 h-4 text-cyan-400" />
              <h3 className="font-semibold text-sm text-slate-100">Setup Persistent Ticket Panel</h3>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Panel Title</label>
                <input
                  type="text"
                  value={panelTitle}
                  onChange={(e) => setPanelTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Channel Name</label>
                <input
                  type="text"
                  value={panelChannel}
                  onChange={(e) => setPanelChannel(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Category</label>
                <input
                  type="text"
                  value={panelCategory}
                  onChange={(e) => setPanelCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <button
                onClick={handleCreatePanel}
                className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-medium py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              >
                <Ticket className="w-3.5 h-3.5" />
                Register & Save Panel to File
              </button>
            </div>
          </div>

          {/* Open Ticket Simulator */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center gap-2 mb-4">
              <Send className="w-4 h-4 text-emerald-400" />
              <h3 className="font-semibold text-sm text-slate-100">Simulate Opening a Ticket</h3>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-medium">User Name / ID</label>
                <input
                  type="text"
                  value={openerName}
                  onChange={(e) => setOpenerUser(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Select Category</label>
                <select
                  value={ticketCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="Store / Purchase">🛒 Store / Purchase</option>
                  <option value="General">📓 General</option>
                  <option value="Billing">💰 Billing</option>
                  <option value="Bug Report">🐛 Bug Report</option>
                  <option value="Appeal">🔨 Appeal</option>
                  <option value="Report">🚨 Report</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Issue Description</label>
                <textarea
                  value={customIssue}
                  onChange={(e) => setCustomIssue(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              <button
                onClick={handleOpenTicket}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-medium py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer mt-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Open Ticket & Store State
              </button>
            </div>
          </div>

          {/* Discord Embeds Live Visualizer */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-semibold text-sm text-slate-100 flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" /> Discord Embed Previews
              </h3>
              <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[11px]">
                <button
                  onClick={() => setEmbedPreviewTab('ticket')}
                  className={`px-2 py-1 rounded-md transition-colors cursor-pointer ${
                    embedPreviewTab === 'ticket' ? 'bg-cyan-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Ticket Panel
                </button>
                <button
                  onClick={() => setEmbedPreviewTab('welcome')}
                  className={`px-2 py-1 rounded-md transition-colors cursor-pointer ${
                    embedPreviewTab === 'welcome' ? 'bg-cyan-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Welcome Msg
                </button>
              </div>
            </div>

            {embedPreviewTab === 'ticket' ? (
              <div className="bg-[#2b2d31] rounded-xl p-4 border-l-4 border-cyan-500 text-slate-200 text-xs space-y-3 shadow-inner">
                <div className="flex items-center gap-2 font-bold text-slate-100">
                  <span>🎫 WonderMc Support Ticket</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  To open a ticket, please click on the category best matching your needs:
                </p>
                <div className="space-y-1 text-[11px] text-slate-300">
                  <div>• 🛒 <strong>Store / Purchase</strong> — Ranks, keys & checkout</div>
                  <div>• 🎫 <strong>General Support</strong> — Server questions & help</div>
                  <div>• 💰 <strong>Billing</strong> — Payment issues & receipts</div>
                  <div>• 🐛 <strong>Bug Report</strong> — In-game glitches or exploits</div>
                  <div>• 🔨 <strong>Appeal</strong> — Ban & mute pardon requests</div>
                </div>

                <div className="bg-[#1e1f22] p-2 rounded-lg border border-slate-700/60 flex items-center justify-between text-slate-400 text-[11px]">
                  <span>Select a category to open ticket...</span>
                  <span>▼</span>
                </div>

                {/* Ticket Panel Footer Image */}
                <div className="pt-1">
                  <img
                    src="https://cdn.discordapp.com/attachments/1517143210667937914/1531959687380074546/Screenshot_2026_0729_151017.png?ex=6aa3cca3&is=6aa27b23&hm=ac46eea2cfb7f3b588d5826c69a41fc19b0645c6a4348e8e44d8b77965f6e62a&"
                    alt="Ticket Panel Footer"
                    className="w-full rounded-lg border border-slate-700/50 object-cover max-h-40"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="text-[10px] text-slate-400 flex items-center justify-between pt-0.5">
                  <span className="flex items-center gap-1.5">
                    <img
                      src="https://cdn.discordapp.com/attachments/1517143210667937914/1531959687380074546/Screenshot_2026_0729_151017.png?ex=6aa3cca3&is=6aa27b23&hm=ac46eea2cfb7f3b588d5826c69a41fc19b0645c6a4348e8e44d8b77965f6e62a&"
                      alt="icon"
                      className="w-3.5 h-3.5 rounded-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    WonderMc Ticket System • Select a category
                  </span>
                  <span className="text-cyan-400 font-semibold">Live in Discord</span>
                </div>
              </div>
            ) : (
              <div className="bg-[#2b2d31] rounded-xl p-4 border-l-4 border-indigo-500 text-slate-200 text-xs space-y-3 shadow-inner">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-100 flex items-center gap-1.5">
                    👋 Welcome to WonderMc Network!
                  </span>
                  <span className="w-8 h-8 rounded-full bg-indigo-500/30 flex items-center justify-center font-bold text-indigo-300 text-[11px]">
                    W
                  </span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Welcome to <strong>WonderMc Network</strong>, <span className="text-indigo-400 font-medium">@Avihaan_PvP</span>! 🎉<br />
                  Connect on <strong>play.wondermc.fun</strong> (Java & Bedrock port 19132).
                </p>

                {/* Welcome Message Bottom Image */}
                <div className="pt-1">
                  <img
                    src="https://media.discordapp.net/attachments/1542583411191980164/1547282120685264906/content.png?ex=6aa38304&is=6aa23184&hm=02b624dbc343189c3c9cce36fa4c6573d5874346fe174d0e27ac636a82fc613b&format=webp&quality=lossless&width=384&height=154&"
                    alt="Welcome Banner Bottom"
                    className="w-full rounded-lg border border-slate-700/50 object-cover max-h-36"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="text-[10px] text-slate-400 flex items-center justify-between pt-0.5">
                  <span className="flex items-center gap-1.5">
                    <img
                      src="https://media.discordapp.net/attachments/1542583411191980164/1547282120685264906/content.png?ex=6aa38304&is=6aa23184&hm=02b624dbc343189c3c9cce36fa4c6573d5874346fe174d0e27ac636a82fc613b&format=webp&quality=lossless&width=384&height=154&"
                      alt="icon"
                      className="w-3.5 h-3.5 rounded object-cover"
                      referrerPolicy="no-referrer"
                    />
                    Member #1428 • WonderMc
                  </span>
                  <span className="text-emerald-400 font-semibold">Active Welcome Embed</span>
                </div>
              </div>
            )}
          </div>

        </div>

        {/* Middle & Right: Active Tickets & Live Interaction Widget */}
        <div className="space-y-6 lg:col-span-2">
          
          {/* Active Tickets List */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Ticket className="w-4 h-4 text-cyan-400" />
                <h3 className="font-semibold text-sm text-slate-100">
                  Open Tickets In State ({Object.keys(state.open_tickets).length})
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                Persisted in <code className="text-cyan-300">./data/tickets_data.json</code>
              </span>
            </div>

            {Object.keys(state.open_tickets).length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs border border-dashed border-slate-800 rounded-xl">
                <AlertCircle className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                No open tickets currently in memory or JSON file. Click "Open Ticket" above to test.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {Object.entries(state.open_tickets).map(([id, ticket]: [string, any]) => (
                  <button
                    key={id}
                    onClick={() => setSelectedTicketId(id)}
                    className={`text-left p-3.5 rounded-xl border text-xs transition-all cursor-pointer ${
                      selectedTicketId === id
                        ? 'bg-cyan-950/40 border-cyan-500/60 ring-1 ring-cyan-500/30'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between font-semibold text-slate-200 mb-1">
                      <span>#{ticket.channel_name || id}</span>
                      <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-[10px]">
                        {ticket.category}
                      </span>
                    </div>
                    <p className="text-slate-400 text-[11px] truncate">Opener: {ticket.user_id}</p>
                    <p className="text-slate-500 text-[10px] mt-1">
                      Claimed: {ticket.claimed_by || 'Unclaimed'}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Ticket Inspection & Interactive Action Controls */}
          {activeTicket && selectedTicketId && (
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                    <span>#{activeTicket.channel_name || selectedTicketId}</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-normal">
                      {activeTicket.category}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Opened by: <strong className="text-slate-200">{activeTicket.user_id}</strong>
                  </p>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  {activeTicket.claimed_by ? (
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 font-medium">
                      <UserCheck className="w-3.5 h-3.5" /> Claimed by {activeTicket.claimed_by}
                    </span>
                  ) : (
                    <button
                      onClick={() => handleClaimTicket(selectedTicketId)}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <UserCheck className="w-3.5 h-3.5" /> Claim Ticket
                    </button>
                  )}
                </div>
              </div>

              {/* DM Target Input */}
              <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
                <label className="block font-medium text-slate-300 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-cyan-400" />
                  Target User for DM Transcript Delivery:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={targetDmUser}
                    onChange={(e) => setTargetDmUser(e.target.value)}
                    placeholder={`Default: ${activeTicket.user_id} (or enter custom user/ID)`}
                    className="flex-1 bg-slate-900 border border-slate-700/70 rounded-lg px-3 py-1.5 text-slate-200 focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    onClick={() => handleSendDmTranscript(selectedTicketId)}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    Send DM & Save File
                  </button>
                </div>
              </div>

              {/* Interactive Panel Action Buttons (Simulating Discord Buttons) */}
              <div>
                <span className="text-xs font-semibold text-slate-400 block mb-2">
                  Simulate Persistent Discord Control Buttons:
                </span>
                <div className="flex flex-wrap gap-2 text-xs">
                  <button
                    onClick={() => setActionStatus(`🔒 Ticket #${activeTicket.channel_name} locked!`)}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600/80 hover:bg-indigo-500 text-white font-medium flex items-center gap-1.5 cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5" /> Lock Ticket
                  </button>

                  <button
                    onClick={() => setActionStatus(`🔓 Ticket #${activeTicket.channel_name} unlocked!`)}
                    className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-medium flex items-center gap-1.5 cursor-pointer"
                  >
                    <Unlock className="w-3.5 h-3.5" /> Unlock Ticket
                  </button>

                  <button
                    onClick={() => handleDeleteWithTranscript(selectedTicketId)}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium flex items-center gap-1.5 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5" /> Delete & Save Transcript
                  </button>

                  <button
                    onClick={() => handleDeleteWithTranscript(selectedTicketId)}
                    className="px-3 py-1.5 rounded-lg bg-red-800 hover:bg-red-700 text-white font-medium flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete Ticket
                  </button>
                </div>
              </div>

              {/* Interactive Store Cart Simulation Drawer */}
              {showCart && (
                <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/40 space-y-3 animate-fade-in text-xs">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                    <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <ShoppingCart className="w-4 h-4" /> WonderMc Store Ticket Cart
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Total: <strong className="text-emerald-300">₹{cart.reduce((s, i) => s + i.price_inr, 0)}</strong> / <strong className="text-cyan-300">${cart.reduce((s, i) => s + i.price_usd, 0)}</strong>
                    </span>
                  </div>

                  {/* Cart Items */}
                  <div className="space-y-1.5 max-h-36 overflow-y-auto">
                    {cart.length === 0 ? (
                      <p className="text-slate-500 italic py-1">Your cart is empty. Select items below to add!</p>
                    ) : (
                      cart.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-800">
                          <span className="text-slate-200">{item.name}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-emerald-400 font-mono">₹{item.price_inr}</span>
                            <button
                              onClick={() => setCart(cart.filter((_, i) => i !== idx))}
                              className="text-rose-400 hover:text-rose-300 px-1 py-0.5 cursor-pointer"
                            >
                              ✕
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Add Quick Items to Cart */}
                  <div className="space-y-1 pt-1">
                    <span className="text-[11px] text-slate-400 font-semibold block">Click to Add Item to Ticket Cart:</span>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-[11px]">
                      {[
                        { id: "rank_immortal", name: "👑 Immortal Rank", price_inr: 899, price_usd: 11 },
                        { id: "rank_elite", name: "⚔️ Elite Rank", price_inr: 499, price_usd: 6 },
                        { id: "rank_vipplus", name: "💎 VIP+ Rank", price_inr: 299, price_usd: 4 },
                        { id: "rank_vip", name: "⭐ VIP Rank", price_inr: 149, price_usd: 2 },
                        { id: "keys_25", name: "🗝️ Mythic Keys x25", price_inr: 299, price_usd: 4 },
                        { id: "coins_1m", name: "💰 1M Coins Voucher", price_inr: 249, price_usd: 3 },
                      ].map((pkg) => (
                        <button
                          key={pkg.id}
                          onClick={() => {
                            setCart([...cart, pkg]);
                            setActionStatus(`🛒 Added "${pkg.name}" to cart!`);
                          }}
                          className="bg-slate-900 hover:bg-slate-800 border border-slate-700/60 p-1.5 rounded text-left transition-colors cursor-pointer truncate"
                        >
                          <div className="font-medium text-slate-200 truncate">{pkg.name}</div>
                          <div className="text-[10px] text-emerald-400">₹{pkg.price_inr} / ${pkg.price_usd}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Cart Action Buttons */}
                  <div className="flex gap-2 pt-2 border-t border-slate-800">
                    <button
                      disabled={cart.length === 0}
                      onClick={() => {
                        const totalInr = cart.reduce((s, i) => s + i.price_inr, 0);
                        const itemNames = cart.map(i => i.name).join(", ");
                        const checkoutMsg = {
                          author: activeTicket.user_id,
                          content: `🛒 **STORE CART CHECKOUT REQUEST:**\nItems: ${itemNames}\nTotal: ₹${totalInr} (Payment: UPI / PayPal). Minecraft IGN: ${activeTicket.user_id}`,
                          timestamp: new Date().toLocaleTimeString()
                        };
                        const updated = {
                          ...state,
                          open_tickets: {
                            ...state.open_tickets,
                            [selectedTicketId]: {
                              ...activeTicket,
                              messages: [...activeTicket.messages, checkoutMsg]
                            }
                          }
                        };
                        onUpdateState(updated);
                        setActionStatus(`🎉 Submitted cart order (${cart.length} items) directly into ticket channel for staff!`);
                        setCart([]);
                        setShowCart(false);
                        setTimeout(() => setActionStatus(null), 4000);
                      }}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold py-1.5 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" /> Submit Order to Staff
                    </button>
                    <button
                      onClick={() => setCart([])}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors cursor-pointer"
                    >
                      Clear
                    </button>
                  </div>
                </div>
              )}

              {/* Channel Message Log */}
              <div className="space-y-2 pt-2">
                <span className="text-xs font-semibold text-slate-400 block">
                  Channel Messages History ({activeTicket.messages?.length || 0}):
                </span>
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 max-h-48 overflow-y-auto space-y-2 text-xs">
                  {activeTicket.messages?.map((msg: any, i: number) => (
                    <div key={i} className="border-b border-slate-900 pb-1.5 last:border-0 last:pb-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-cyan-400">{msg.author}</span>
                        <span className="text-[10px] text-slate-500">{msg.timestamp}</span>
                      </div>
                      <p className="text-slate-300 mt-0.5">{msg.content}</p>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
