import React, { useState, useEffect } from 'react';
import {
  Coins,
  Vault,
  Trophy,
  ShieldCheck,
  Zap,
  RefreshCw,
  ShoppingBag,
  Ticket,
  Sliders,
  CheckCircle2
} from 'lucide-react';

interface RichUser {
  guild_id: string;
  user_id: string;
  username: string;
  cash: number;
  bank: number;
  bank_capacity: number;
  net: number;
  daily_streak: number;
  inventory: Record<string, number>;
}

export const EconomyVaults: React.FC = () => {
  const [leaderboard, setLeaderboard] = useState<RichUser[]>([]);
  const [totalCirculation, setTotalCirculation] = useState(0);
  const [totalCash, setTotalCash] = useState(0);
  const [totalBank, setTotalBank] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  const fetchLeaderboard = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/economy/leaderboard');
      const data = await res.json();
      if (data.success) {
        setLeaderboard(data.leaderboard || []);
        setTotalCirculation(data.totalCirculation || 0);
        setTotalCash(data.totalCash || 0);
        setTotalBank(data.totalBank || 0);
      }
    } catch (e) {
      console.error('Error fetching economy leaderboard:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const storeItems = [
    { emoji: '👑', name: 'VIP Role', price: '50,000', desc: 'Exclusive VIP role with high status and unique server perks.' },
    { emoji: '💎', name: 'Millionaire Role', price: '1,000,000', desc: 'Prestigious Millionaire role for top earners.' },
    { emoji: '💰', name: 'Billionaire Role', price: '1,000,000,000', desc: 'Ultra-wealthy Billionaire server elite role.' },
    { emoji: '🏰', name: 'Royalty Role', price: '5,000,000,000', desc: 'Supreme Royalty status in WonderMc.' },
    { emoji: '🎟️', name: '250k In-Game Cash Voucher', price: '50,000,000', desc: 'Redeemable 250,000 in-game currency code for play.wondermc.fun.' }
  ];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-950/80 via-slate-900 to-amber-950/40 border border-emerald-500/30 p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <img
              src="/cash_logo.png"
              alt="WonderMc Cash Logo"
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-emerald-400/40 shadow-xl shadow-emerald-950/60 flex-shrink-0 bg-slate-900"
              onError={(e) => {
                // fallback to discord cdn if needed
                (e.currentTarget as HTMLImageElement).src = "https://cdn.discordapp.com/attachments/1520403011468263514/1540931830738587648/file_000000001d9082119630e8992adb4ffa.png?ex=6a8bc019&is=6a8a6e99&hm=d1d4a755176c1576c7b4b72275b1b97ae336fb5597a58ee8243006d9b59de44f&";
              }}
            />
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-2">
                <Coins className="w-3.5 h-3.5" />
                Official Server Cash Currency
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
                WonderMc Server Economy & Vaults
              </h2>
              <p className="text-slate-300 text-sm mt-1.5 max-w-2xl leading-relaxed">
                Powered by the server's official cash currency. Synced with Discord SQLite database. Use shorthand quantities (<code className="text-emerald-400">wm dep 250k</code>, <code className="text-emerald-400">wm cf 1m</code>, <code className="text-emerald-400">wm with all</code>) or slash commands.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-shrink-0">
            <button
              onClick={fetchLeaderboard}
              disabled={isLoading}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-sm font-medium border border-slate-700 transition cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
          <div className="bg-slate-900/80 backdrop-blur-sm border border-emerald-500/20 rounded-xl p-5 flex items-center justify-between gap-4">
            <div>
              <div className="text-slate-400 text-xs font-medium">Total Cash in Circulation</div>
              <div className="text-2xl font-bold text-emerald-400 mt-1 font-mono">
                💵 {totalCirculation.toLocaleString()}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">Wallets + Vaults</div>
            </div>
            <img src="/cash_logo.png" alt="Cash" className="w-10 h-10 rounded-xl border border-emerald-500/30 object-cover shadow" />
          </div>

          <div className="bg-slate-900/80 backdrop-blur-sm border border-amber-500/20 rounded-xl p-5">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Total Bank Vault Deposits</span>
              <Vault className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-bold text-amber-400 mt-2">
              🏦 {totalBank.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Bank Vault Storage</div>
          </div>

          <div className="bg-slate-900/80 backdrop-blur-sm border border-cyan-500/20 rounded-xl p-5">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Persistence Engine</span>
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold text-cyan-400 mt-2 flex items-center gap-2">
              <span>SQLite WAL</span>
              <span className="text-xs px-2 py-0.5 bg-cyan-500/20 text-cyan-300 rounded font-normal">Active</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Zero data loss on restart</div>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Store Items & Discord Commands */}
        <div className="lg:col-span-7 space-y-6">
          {/* Store Items Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-emerald-400" />
                Discord Server Store Items (/store & wm store)
              </h4>
              <span className="text-xs text-slate-400">Limited Stock System</span>
            </div>

            <div className="space-y-3">
              {storeItems.map((item, i) => (
                <div key={i} className="flex items-center justify-between p-3.5 bg-slate-950/60 rounded-xl border border-slate-800/80">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{item.emoji}</span>
                    <div>
                      <div className="text-sm font-bold text-white">{item.name}</div>
                      <div className="text-xs text-slate-400 mt-0.5">{item.desc}</div>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0 pl-3">
                    <div className="text-xs text-slate-400 font-medium">Price</div>
                    <div className="text-sm font-black text-emerald-400 font-mono">💵 {item.price}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Commands Reference */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Discord Slash & Prefix (km) Commands
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <div className="font-mono text-emerald-400 font-bold">wm bal / /balance</div>
                <div className="text-slate-400 mt-1">Check Cash, Bank Vault, Net Worth & Rank</div>
              </div>
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <div className="font-mono text-emerald-400 font-bold">wm dep & wm with</div>
                <div className="text-slate-400 mt-1">Supports shorthand e.g. <code>wm dep 250k</code>, <code>wm dep all</code></div>
              </div>
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <div className="font-mono text-amber-400 font-bold">wm cf & wm hl</div>
                <div className="text-slate-400 mt-1">Chicken Fight and Higher Lower game with button controls</div>
              </div>
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <div className="font-mono text-amber-400 font-bold">wm work & wm crime</div>
                <div className="text-slate-400 mt-1">Earn coins through roleplay jobs and heists</div>
              </div>
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <div className="font-mono text-cyan-400 font-bold">wm store & wm stocks</div>
                <div className="text-slate-400 mt-1">Interactive store menu and admin stock restocker</div>
              </div>
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <div className="font-mono text-cyan-400 font-bold">km leaderboard / /rich</div>
                <div className="text-slate-400 mt-1">Rich player leaderboard with pagination buttons</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Top Richest Server Leaderboard */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <Trophy className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-base font-bold text-white">Richest Server Members</h3>
                  <p className="text-xs text-slate-400">Synced with Discord SQLite database</p>
                </div>
              </div>
              <span className="text-xs px-2.5 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-full font-bold">
                TOP 10
              </span>
            </div>

            <div className="divide-y divide-slate-800/80 mt-4">
              {leaderboard.map((user, idx) => {
                const medals = ["🥇", "🥈", "🥉"];
                const medal = idx < 3 ? medals[idx] : `#${idx + 1}`;
                const isTop1 = idx === 0;

                return (
                  <div key={user.user_id} className={`py-3.5 flex items-center justify-between gap-3 ${isTop1 ? 'bg-amber-500/5 -mx-3 px-3 rounded-xl' : ''}`}>
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="text-base font-bold w-6 text-center">{medal}</span>
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-white truncate flex items-center gap-2">
                          <span>{user.username}</span>
                          {user.inventory && user.inventory.vip && (
                            <span className="text-[10px] px-1.5 py-0.2 bg-amber-500/20 text-amber-300 rounded font-semibold">VIP</span>
                          )}
                        </div>
                        <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                          <span>💵 {user.cash.toLocaleString()}</span>
                          <span>•</span>
                          <span>🏦 {user.bank.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <div className="text-xs text-slate-400 font-medium">Net Worth</div>
                      <div className="text-sm font-black text-emerald-400 font-mono">
                        {user.net.toLocaleString()}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
