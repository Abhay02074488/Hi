import React, { useState, useEffect } from 'react';
import { Code, FileText, CheckCircle2, RefreshCw, Copy } from 'lucide-react';

interface CodeExplorerProps {
  cogsList: string[];
}

export const CodeExplorer: React.FC<CodeExplorerProps> = ({ cogsList }) => {
  const [selectedFilePath, setSelectedFilePath] = useState<string>("cogs/ticket.py");
  const [codeContent, setCodeContent] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const fetchCode = async (path: string) => {
    setSelectedFilePath(path);
    setIsLoading(true);
    try {
      const res = await fetch(`/api/code?path=${encodeURIComponent(path)}`);
      const data = await res.json();
      if (data.success) {
        setCodeContent(data.content);
      } else {
        setCodeContent(`# Failed to load file: ${data.error}`);
      }
    } catch (e: any) {
      setCodeContent(`# Error connecting to server: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCode("cogs/ticket.py");
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(codeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-cyan-400">
            <Code className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">
              Bot Code Explorer & Cog Inspector
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Inspect Python bot codebase, persistent view setups, and transcript DM handlers.
            </p>
          </div>
        </div>

        <button
          onClick={handleCopy}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer border border-slate-700 shrink-0 self-start sm:self-auto"
        >
          {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          {copied ? 'Copied!' : 'Copy File Code'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* File Tree Selector */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-2 lg:col-span-1">
          <span className="text-xs font-bold text-slate-300 block px-2 mb-2">
            Python Files ({cogsList.length})
          </span>

          <div className="space-y-1">
            {cogsList.map((filePath) => (
              <button
                key={filePath}
                onClick={() => fetchCode(filePath)}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs transition-all flex items-center gap-2 cursor-pointer ${
                  selectedFilePath === filePath
                    ? 'bg-cyan-950/60 border border-cyan-500/50 text-cyan-300 font-semibold'
                    : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 border border-transparent'
                }`}
              >
                <FileText className="w-3.5 h-3.5 shrink-0 text-cyan-400" />
                <span className="truncate">{filePath}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Code Content Viewer */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl lg:col-span-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="font-mono text-xs font-semibold text-cyan-300">
              {selectedFilePath}
            </span>
            <span className="text-[10px] text-slate-500">
              Python 3.10+ / discord.py
            </span>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto max-h-[550px] whitespace-pre leading-relaxed">
            {isLoading ? (
              <div className="flex items-center justify-center gap-2 text-slate-500 py-12">
                <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
                Reading Python file...
              </div>
            ) : (
              codeContent
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
