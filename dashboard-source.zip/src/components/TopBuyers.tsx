import React from 'react';
import { Trophy, Award, Crown } from 'lucide-react';
import { DEFAULT_TOP_BUYERS } from '../data/storeData';
import { MinecraftSkinImage } from './MinecraftSkinImage';
import { useStoreConfig } from '../context/StoreConfigContext';

export const TopBuyers: React.FC = () => {
  const { config } = useStoreConfig();

  return (
    <div className="mt-12 p-6 sm:p-8 rounded-3xl bg-slate-900/60 border border-slate-800">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h3 className="text-xl font-bold text-white">Top Server Supporters</h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Leaderboard honoring the players who make WonderMc Network's 24/7 hosting possible.
          </p>
        </div>
        <span className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-800 text-amber-400 border border-slate-700 self-start sm:self-auto">
          Updated Weekly
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {DEFAULT_TOP_BUYERS.map((buyer, idx) => (
          <div
            key={buyer.rank}
            className={`p-4 rounded-2xl border transition-all flex items-center gap-3.5 ${
              idx === 0
                ? 'bg-amber-500/10 border-amber-500/30'
                : idx === 1
                ? 'bg-slate-800/80 border-slate-700'
                : idx === 2
                ? 'bg-amber-900/10 border-amber-800/30'
                : 'bg-slate-900/80 border-slate-800'
            }`}
          >
            {/* Rank Trophy Badge */}
            <div className="relative">
              <MinecraftSkinImage username={buyer.skinUsername} size={42} type="bust" />
              <span className={`absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                idx === 0 ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/40' :
                idx === 1 ? 'bg-slate-300 text-slate-950' :
                idx === 2 ? 'bg-amber-700 text-white' :
                'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>
                #{buyer.rank}
              </span>
            </div>

            <div className="min-w-0 flex-1">
              <h4 className="text-xs font-bold text-white truncate">{buyer.username}</h4>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold uppercase">
                  {buyer.tier}
                </span>
                <span className="text-xs font-black text-emerald-400">
                  {config.currencySymbol}{buyer.totalSpent}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
