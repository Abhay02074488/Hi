import React, { useState } from 'react';
import {
  Bot,
  ExternalLink,
  Copy,
  Check,
  Globe,
  Terminal,
  Shield,
  Sparkles,
  Server,
  Zap
} from 'lucide-react';

export const WebPanelEmbed: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [dispatched, setDispatched] = useState(false);

  const websiteUrl = window.location.origin;

  const copyCommand = () => {
    navigator.clipboard.writeText('/web_panel');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTestDispatch = () => {
    setDispatched(true);
    setTimeout(() => setDispatched(false), 3000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
      
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Terminal className="w-5 h-5 text-[#5865f2]" />
            Discord /web_panel Slash Command
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Users & staff can run <code className="text-indigo-400 font-mono">/web_panel</code> in Discord to receive this interactive web portal embed.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={copyCommand}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-xl text-xs font-semibold transition cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Copy /web_panel</span>
          </button>

          <button
            onClick={handleTestDispatch}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#5865f2] hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-indigo-500/20 cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{dispatched ? 'Dispatched to Discord!' : 'Simulate /web_panel'}</span>
          </button>
        </div>
      </div>

      {/* DISCORD MESSAGE EMBED PREVIEW */}
      <div className="bg-[#313338] rounded-2xl p-4 sm:p-6 border border-[#1e1f22] font-sans text-white max-w-2xl shadow-2xl">
        
        {/* Author Line */}
        <div className="flex items-center gap-3 mb-3">
          <img
            src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&auto=format&fit=crop&q=80"
            alt="Bot Avatar"
            className="w-10 h-10 rounded-full object-cover"
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-white">WonderMc • core</span>
              <span className="bg-[#5865f2] text-white text-[10px] font-bold px-1.5 py-0.2 rounded">BOT</span>
              <span className="text-xs text-[#949ba4]">Today at {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            <div className="text-[11px] text-[#949ba4] flex items-center gap-1">
              <span>Command ran: </span>
              <code className="text-indigo-300 bg-[#2b2d31] px-1 rounded">/web_panel</code>
            </div>
          </div>
        </div>

        {/* Discord Rich Embed */}
        <div className="bg-[#2b2d31] border-l-4 border-[#5865f2] rounded-r-xl p-4 sm:p-5 space-y-3.5 text-xs">
          
          <div className="flex items-center justify-between">
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              🌐 WonderMc Network Web Portal
            </h4>
            <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
              ● ONLINE
            </span>
          </div>

          <p className="text-[#dbdee1] leading-relaxed">
            Welcome to the official <strong>WonderMc Web Portal</strong>! Access live server telemetry, transcripts, activity leaderboards, and minigames.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#3f4147]">
            <div>
              <span className="text-[11px] text-[#949ba4] font-bold uppercase block">🎮 Server IP (Crossplay)</span>
              <code className="text-[#5865f2] font-mono text-xs font-semibold">play.wondermc.fun</code>
            </div>
            <div>
              <span className="text-[11px] text-[#949ba4] font-bold uppercase block">📱 Bedrock Port</span>
              <code className="text-emerald-400 font-mono text-xs font-semibold">19132</code>
            </div>
            <div>
              <span className="text-[11px] text-[#949ba4] font-bold uppercase block">📜 Web Transcripts</span>
              <span className="text-slate-200">Local screenshot archive</span>
            </div>
            <div>
              <span className="text-[11px] text-[#949ba4] font-bold uppercase block">🕹️ Playable Minigames</span>
              <span className="text-slate-200">Tic Tac Toe, Chess, Blackjack</span>
            </div>
          </div>

          {/* Interactive Link Buttons */}
          <div className="pt-3 flex flex-wrap gap-2">
            <a
              href={websiteUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#5865f2] hover:bg-indigo-600 text-white rounded-lg font-semibold text-xs transition shadow"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Open Web Panel</span>
              <ExternalLink className="w-3 h-3 opacity-70" />
            </a>

            <a
              href="https://dc.gg/wondermc"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#4e5058] hover:bg-[#6d6f78] text-white rounded-lg font-semibold text-xs transition"
            >
              <span>Join Discord</span>
              <ExternalLink className="w-3 h-3 opacity-70" />
            </a>
          </div>

          <div className="pt-2 text-[10px] text-[#80848e] border-t border-[#3f4147]/60 flex items-center justify-between">
            <span>WonderMc Bot System • All data stored persistently</span>
            <span>play.wondermc.fun</span>
          </div>

        </div>

      </div>

    </div>
  );
};
