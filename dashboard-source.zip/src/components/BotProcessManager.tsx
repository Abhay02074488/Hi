import React, { useState, useEffect, useRef } from 'react';
import {
  Terminal,
  Play,
  Square,
  RefreshCw,
  Copy,
  Check,
  Server,
  AlertTriangle,
  CheckCircle2,
  FileCode2,
  Shield,
  Activity,
  Cpu,
  Trash2,
  Info
} from 'lucide-react';

interface BotLog {
  timestamp: string;
  type: 'stdout' | 'stderr' | 'system';
  text: string;
}

interface ProcessStatus {
  status: 'STOPPED' | 'STARTING' | 'RUNNING' | 'CRASHED' | 'RESTARTING';
  pid: number | null;
  startedAt: string | null;
  restartsCount: number;
  autoStart: boolean;
  envConfig: {
    RUN_DISCORD_BOT: string;
    BOT_PYTHON_CMD: string;
    BOT_ENTRY_FILE: string;
    hasToken: boolean;
  };
}

export const BotProcessManager: React.FC = () => {
  const [statusData, setStatusData] = useState<ProcessStatus | null>(null);
  const [logs, setLogs] = useState<BotLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);
  const [logFilter, setLogFilter] = useState<'all' | 'stderr' | 'system'>('all');
  const logTerminalRef = useRef<HTMLDivElement>(null);

  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/bot/process/status');
      const data = await res.json();
      if (data.success) {
        setStatusData(data);
      }
    } catch (e) {
      console.error('Error fetching bot process status:', e);
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/bot/process/logs');
      const data = await res.json();
      if (data.success && Array.isArray(data.logs)) {
        setLogs(data.logs);
      }
    } catch (e) {
      console.error('Error fetching bot logs:', e);
    }
  };

  useEffect(() => {
    fetchStatus();
    fetchLogs();

    const interval = setInterval(() => {
      fetchStatus();
      fetchLogs();
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (autoScroll && logTerminalRef.current) {
      logTerminalRef.current.scrollTop = logTerminalRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const handleStart = async () => {
    setLoading(true);
    setActionMessage(null);
    try {
      const res = await fetch('/api/bot/process/start', { method: 'POST' });
      const data = await res.json();
      setActionMessage(data.message || (data.success ? 'Bot process started.' : data.error));
      fetchStatus();
      fetchLogs();
    } catch (err: any) {
      setActionMessage(err.message || 'Failed to start bot');
    } finally {
      setLoading(false);
    }
  };

  const handleStop = async () => {
    setLoading(true);
    setActionMessage(null);
    try {
      const res = await fetch('/api/bot/process/stop', { method: 'POST' });
      const data = await res.json();
      setActionMessage(data.message || 'Bot process stopped.');
      fetchStatus();
      fetchLogs();
    } catch (err: any) {
      setActionMessage(err.message || 'Failed to stop bot');
    } finally {
      setLoading(false);
    }
  };

  const handleRestart = async () => {
    setLoading(true);
    setActionMessage(null);
    try {
      const res = await fetch('/api/bot/process/restart', { method: 'POST' });
      const data = await res.json();
      setActionMessage(data.message || 'Bot process restarted.');
      fetchStatus();
      fetchLogs();
    } catch (err: any) {
      setActionMessage(err.message || 'Failed to restart bot');
    } finally {
      setLoading(false);
    }
  };

  const handleClearLogs = async () => {
    try {
      await fetch('/api/bot/process/clear-logs', { method: 'POST' });
      setLogs([]);
    } catch (_) {}
  };

  const handleCopyLogs = () => {
    const text = logs.map(l => `[${l.timestamp.slice(11, 19)}] [${l.type.toUpperCase()}] ${l.text}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const filteredLogs = logs.filter(l => {
    if (logFilter === 'all') return true;
    return l.type === logFilter;
  });

  const getStatusBadge = () => {
    const s = statusData?.status || 'STOPPED';
    switch (s) {
      case 'RUNNING':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            RUNNING (PID {statusData?.pid})
          </span>
        );
      case 'STARTING':
      case 'RESTARTING':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
            <RefreshCw className="w-3 h-3 animate-spin" />
            {s}
          </span>
        );
      case 'CRASHED':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
            <AlertTriangle className="w-3 h-3" />
            CRASHED (Exit / Dependency)
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-800 text-slate-400 border border-slate-700">
            <span className="w-2 h-2 rounded-full bg-slate-500" />
            STOPPED
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Same-Server Architecture */}
      <div className="bg-gradient-to-r from-indigo-950/60 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <Server className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg font-bold text-white tracking-tight">
                Discord Bot & Website Unified Server
              </h2>
              {getStatusBadge()}
            </div>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Both the <strong className="text-white">WonderMc Staff Portal</strong> (Express/Node.js) and the <strong className="text-white">Discord Bot</strong> (<code className="text-indigo-300 font-mono">main.py</code>) execute simultaneously on this exact same server. Manage bot execution, crash recoveries, and live terminal output below.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5 shrink-0">
            {statusData?.status === 'RUNNING' ? (
              <>
                <button
                  onClick={handleRestart}
                  disabled={loading}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-sm transition cursor-pointer disabled:opacity-50"
                  title="Restart Bot Process"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>Restart Bot</span>
                </button>
                <button
                  onClick={handleStop}
                  disabled={loading}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-600/80 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-sm transition cursor-pointer disabled:opacity-50"
                  title="Stop Bot Process"
                >
                  <Square className="w-3.5 h-3.5 fill-white" />
                  <span>Stop</span>
                </button>
              </>
            ) : (
              <button
                onClick={handleStart}
                disabled={loading}
                className="flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/20 transition cursor-pointer disabled:opacity-50"
                title="Launch Python Discord Bot"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Start Discord Bot</span>
              </button>
            )}
          </div>
        </div>

        {actionMessage && (
          <div className="mt-4 p-3 rounded-xl bg-slate-900/90 border border-slate-700/80 text-xs text-indigo-300 flex items-center gap-2">
            <Info className="w-4 h-4 text-indigo-400 shrink-0" />
            <span>{actionMessage}</span>
          </div>
        )}
      </div>

      {/* Grid: Process Telemetry & .env Configuration */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Card 1: Process Telemetry */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-emerald-400" />
              Runtime Process Status
            </span>
            <span className="text-[10px] font-mono text-slate-500">Node ChildProcess</span>
          </div>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Process Status:</span>
              <span className="font-bold text-white">{statusData?.status || 'STOPPED'}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">PID:</span>
              <span className="font-mono text-emerald-400">{statusData?.pid || 'None (Inactive)'}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Crash Restarts:</span>
              <span className="font-mono text-amber-400">{statusData?.restartsCount || 0} times</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Started At:</span>
              <span className="font-mono text-slate-300 text-[11px]">
                {statusData?.startedAt ? new Date(statusData.startedAt).toLocaleTimeString() : 'N/A'}
              </span>
            </div>
          </div>
        </div>

        {/* Card 2: Environment Settings from .env */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
              <FileCode2 className="w-4 h-4 text-indigo-400" />
              Detected .env Settings
            </span>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              Active Server
            </span>
          </div>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">RUN_DISCORD_BOT:</span>
              <code className="font-mono text-indigo-300 font-bold">{statusData?.envConfig.RUN_DISCORD_BOT || 'false'}</code>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">BOT_PYTHON_CMD:</span>
              <code className="font-mono text-slate-300">{statusData?.envConfig.BOT_PYTHON_CMD || 'python3'}</code>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">BOT_ENTRY_FILE:</span>
              <code className="font-mono text-slate-300">{statusData?.envConfig.BOT_ENTRY_FILE || 'main.py'}</code>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">DISCORD_TOKEN:</span>
              <span className={`text-[11px] font-bold ${statusData?.envConfig.hasToken ? 'text-emerald-400' : 'text-amber-400'}`}>
                {statusData?.envConfig.hasToken ? 'Configured ✓' : 'Placeholder / Missing'}
              </span>
            </div>
          </div>
        </div>

        {/* Card 3: How to Run in .env */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-2.5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-amber-400" />
              Run on Same Server Guide
            </span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            In your <code className="text-indigo-400 font-mono">.env</code> file, ensure:
          </p>
          <pre className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono text-[10px] text-emerald-400 overflow-x-auto">
{`RUN_DISCORD_BOT=true
BOT_PYTHON_CMD=python3
BOT_ENTRY_FILE=main.py
DISCORD_TOKEN=your_token_here`}
          </pre>
          <p className="text-[10px] text-slate-400">
            Whenever the web server starts with <code className="text-slate-200">npm start</code>, it automatically boots the Discord bot too!
          </p>
        </div>
      </div>

      {/* Live Terminal Logs */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Terminal Header */}
        <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
            </div>
            <span className="text-xs font-mono font-bold text-slate-300 ml-2 flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-indigo-400" />
              Discord Bot Console Output (Live Stream)
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter buttons */}
            <div className="flex bg-slate-950 rounded-lg p-0.5 border border-slate-800 text-[10px]">
              <button
                onClick={() => setLogFilter('all')}
                className={`px-2 py-1 rounded cursor-pointer transition ${logFilter === 'all' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
              >
                All Logs ({logs.length})
              </button>
              <button
                onClick={() => setLogFilter('stderr')}
                className={`px-2 py-1 rounded cursor-pointer transition ${logFilter === 'stderr' ? 'bg-rose-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
              >
                Errors
              </button>
              <button
                onClick={() => setLogFilter('system')}
                className={`px-2 py-1 rounded cursor-pointer transition ${logFilter === 'system' ? 'bg-amber-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
              >
                System
              </button>
            </div>

            {/* Auto-scroll */}
            <button
              onClick={() => setAutoScroll(!autoScroll)}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition cursor-pointer ${
                autoScroll
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
              title="Toggle Auto-scroll"
            >
              Auto-scroll {autoScroll ? 'ON' : 'OFF'}
            </button>

            {/* Copy Logs */}
            <button
              onClick={handleCopyLogs}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs transition cursor-pointer"
              title="Copy Output"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>

            {/* Clear Logs */}
            <button
              onClick={handleClearLogs}
              className="p-1.5 bg-slate-800 hover:bg-rose-900/40 text-slate-400 hover:text-rose-400 rounded-lg text-xs transition cursor-pointer"
              title="Clear Console"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Terminal Body */}
        <div
          ref={logTerminalRef}
          className="p-4 font-mono text-xs text-slate-200 h-96 overflow-y-auto space-y-1 leading-relaxed selection:bg-indigo-500 selection:text-white bg-slate-950"
        >
          {filteredLogs.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-600 text-xs space-y-2">
              <Terminal className="w-8 h-8 opacity-40" />
              <p>No console output yet.</p>
              <p className="text-[11px] text-slate-500">
                Click &quot;Start Discord Bot&quot; above to run <code className="text-slate-400">main.py</code> or configure <code className="text-slate-400">RUN_DISCORD_BOT=true</code> in your .env.
              </p>
            </div>
          ) : (
            filteredLogs.map((log, idx) => {
              const time = log.timestamp ? log.timestamp.slice(11, 19) : '--:--:--';
              let colorClass = 'text-slate-300';
              if (log.type === 'stderr') colorClass = 'text-rose-400 font-semibold';
              if (log.type === 'system') colorClass = 'text-amber-400 font-semibold';
              if (log.text.includes('Logged in as') || log.text.includes('Bot is ready') || log.text.includes('Connected')) {
                colorClass = 'text-emerald-400 font-bold';
              }

              return (
                <div key={idx} className="flex items-start gap-2.5 hover:bg-slate-900/60 px-1.5 py-0.5 rounded">
                  <span className="text-slate-600 select-none text-[10px]">{time}</span>
                  <span className={`text-[10px] px-1 rounded uppercase select-none font-bold ${
                    log.type === 'stderr' ? 'bg-rose-500/20 text-rose-400' :
                    log.type === 'system' ? 'bg-amber-500/20 text-amber-300' :
                    'bg-slate-800 text-slate-400'
                  }`}>
                    {log.type}
                  </span>
                  <span className={`flex-1 break-all whitespace-pre-wrap ${colorClass}`}>
                    {log.text}
                  </span>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
