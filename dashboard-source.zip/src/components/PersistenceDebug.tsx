import React, { useState, useEffect } from 'react';
import {
  HardDrive, RefreshCw, CheckCircle2, FileCode, Shield, Layers,
  Smartphone, Moon, EyeOff, Zap, AlertTriangle, Trash2, ArrowRight
} from 'lucide-react';
import { TicketSystemState } from '../types';

interface PersistenceDebugProps {
  state: TicketSystemState;
  onSimulateRestart: () => Promise<void>;
}

interface PresenceStatus {
  currentState: 'online' | 'idle' | 'offline';
  device: string;
  deviceIcon: string;
  elapsedSeconds: number;
  lastTriggerTime: string;
  lastTriggerSource: string;
  timeUntilIdle: number;
  timeUntilOffline: number;
  config: {
    enabled: boolean;
    idle_timeout: number;
    offline_timeout: number;
    activity_name: string;
  };
}

interface PanelHealthItem {
  key: string;
  name: string;
  fileName: string;
  exists: boolean;
  status: string;
  itemsCount: number;
  sizeBytes: number;
  lastModified: string | null;
  selfHealingReady: boolean;
}

export const PersistenceDebug: React.FC<PersistenceDebugProps> = ({
  state,
  onSimulateRestart
}) => {
  const [isRestarting, setIsRestarting] = useState(false);
  const [restartResult, setRestartResult] = useState<string | null>(null);

  // Presence loophole state
  const [presence, setPresence] = useState<PresenceStatus | null>(null);
  const [isWaking, setIsWaking] = useState(false);
  const [wakeFeedback, setWakeFeedback] = useState<string | null>(null);

  // Panels health state
  const [panelsHealth, setPanelsHealth] = useState<PanelHealthItem[]>([]);
  const [isHealing, setIsHealing] = useState<string | null>(null);
  const [healingFeedback, setHealingFeedback] = useState<string | null>(null);

  // Fetch presence & health
  const fetchPresence = async () => {
    try {
      const res = await fetch('/api/presence/status');
      if (res.ok) {
        const data = await res.json();
        if (data.success) setPresence(data);
      }
    } catch (_) {}
  };

  const fetchPanelsHealth = async () => {
    try {
      const res = await fetch('/api/panels/health');
      if (res.ok) {
        const data = await res.json();
        if (data.success) setPanelsHealth(data.health || []);
      }
    } catch (_) {}
  };

  useEffect(() => {
    fetchPresence();
    fetchPanelsHealth();
    const interval = setInterval(() => {
      fetchPresence();
      fetchPanelsHealth();
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleRestart = async () => {
    setIsRestarting(true);
    setRestartResult(null);
    try {
      await onSimulateRestart();
      setRestartResult("✅ Restart check completed! All views (Tickets, Giveaways, Roles, Suggestions, Help) re-registered with timeout=None.");
      fetchPanelsHealth();
    } catch (e: any) {
      setRestartResult(`❌ Restart failed: ${e.message}`);
    } finally {
      setIsRestarting(false);
    }
  };

  const handleWakeUp = async (source = "Web Trigger Simulator") => {
    setIsWaking(true);
    setWakeFeedback(null);
    try {
      const res = await fetch('/api/presence/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source, user: 'Dashboard Admin' })
      });
      const data = await res.json();
      if (data.success) {
        setWakeFeedback(`⚡ Awakened! ${data.message}`);
        fetchPresence();
      }
    } catch (e: any) {
      setWakeFeedback(`❌ Trigger error: ${e.message}`);
    } finally {
      setIsWaking(false);
      setTimeout(() => setWakeFeedback(null), 4000);
    }
  };

  const handleSimulateDeleteAndHeal = async (key: string) => {
    setIsHealing(key);
    setHealingFeedback(null);
    try {
      const res = await fetch('/api/panels/simulate-heal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key })
      });
      const data = await res.json();
      if (data.success) {
        setHealingFeedback(`🛡️ ${data.message}`);
        fetchPanelsHealth();
      }
    } catch (e: any) {
      setHealingFeedback(`❌ Recovery test error: ${e.message}`);
    } finally {
      setIsHealing(null);
    }
  };

  return (
    <div className="space-y-6">

      {/* ─────────────────────────────────────────────
          1. IDLE / ACTIVE MOBILE STATUS LOOPHOLE SECTION
         ───────────────────────────────────────────── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-cyan-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-100">
                  Mobile Inactivity & Wake-Up Loophole Engine
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-500/10 border border-cyan-500/30 text-cyan-300">
                  Discord Android
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Dynamic status switching: stays idle/offline during inactivity, wakes to <strong>Mobile Online</strong> when triggered.
              </p>
            </div>
          </div>

          <button
            onClick={() => handleWakeUp("Manual Button Trigger")}
            disabled={isWaking}
            className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-lg text-xs font-semibold shadow-lg shadow-emerald-950/30 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
          >
            <Zap className={`w-4 h-4 ${isWaking ? 'animate-bounce text-yellow-300' : ''}`} />
            {isWaking ? 'Awakening Bot...' : 'Simulate Trigger / Wake Up 📱'}
          </button>
        </div>

        {wakeFeedback && (
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{wakeFeedback}</span>
          </div>
        )}

        {/* Live Status Indicators */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Current State */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 text-[11px] block">Current Bot Presence</span>
            <div className="flex items-center gap-2 mt-1">
              {presence?.currentState === 'online' ? (
                <>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span className="font-bold text-emerald-400 text-sm flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4" /> Online (Mobile)
                  </span>
                </>
              ) : presence?.currentState === 'idle' ? (
                <>
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                  <span className="font-bold text-amber-400 text-sm flex items-center gap-1.5">
                    <Moon className="w-4 h-4" /> Idle (Mobile)
                  </span>
                </>
              ) : (
                <>
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span>
                  <span className="font-bold text-slate-400 text-sm flex items-center gap-1.5">
                    <EyeOff className="w-4 h-4" /> Offline (Stealth)
                  </span>
                </>
              )}
            </div>
            <span className="text-[10px] text-slate-500 block">
              Device: {presence?.device || 'Discord Android'}
            </span>
          </div>

          {/* Time Inactive */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 text-[11px] block">Inactivity Counter</span>
            <span className="text-base font-mono font-bold text-slate-100 block">
              {presence?.elapsedSeconds ?? 0}s elapsed
            </span>
            <span className="text-[10px] text-slate-500 block truncate">
              Last: {presence?.lastTriggerSource || 'System startup'}
            </span>
          </div>

          {/* Time Until Idle */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 text-[11px] block">Time Until Idle</span>
            <span className="text-base font-mono font-bold text-amber-400 block">
              {presence?.timeUntilIdle && presence.timeUntilIdle > 0
                ? `${presence.timeUntilIdle}s`
                : '🌙 Active/Passed'}
            </span>
            <span className="text-[10px] text-slate-500 block">
              Timeout: {presence?.config.idle_timeout || 180}s (3 min)
            </span>
          </div>

          {/* Time Until Offline */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 text-[11px] block">Time Until Invisible (Off)</span>
            <span className="text-base font-mono font-bold text-cyan-400 block">
              {presence?.timeUntilOffline && presence.timeUntilOffline > 0
                ? `${presence.timeUntilOffline}s`
                : '💤 Offline stealth'}
            </span>
            <span className="text-[10px] text-slate-500 block">
              Timeout: {presence?.config.offline_timeout || 600}s (10 min)
            </span>
          </div>
        </div>

        <div className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800">
          <strong>How the Mobile Loophole Works in Discord:</strong>
          <ul className="list-disc list-inside mt-1 space-y-0.5 text-slate-400 text-[11px]">
            <li><strong>Stealth Listening:</strong> While idle or offline (invisible), the bot's gateway socket remains connected and continues listening for mentions, prefix commands (<code className="text-cyan-300">wm</code>), slash commands, or any panel button clicks.</li>
            <li><strong>Instant Mobile Awakening:</strong> The instant any user interacts with the bot, it transitions to <code className="text-emerald-300">Status.online</code> with the Discord Mobile Phone icon.</li>
            <li><strong>Silence Auto-Sleep:</strong> If no one interacts with the bot for 3 minutes, it transitions to Idle. After 10 minutes of silence, it goes completely Offline/Invisible.</li>
          </ul>
        </div>
      </div>

      {/* ─────────────────────────────────────────────
          2. MULTI-PANEL RESILIENCE & SELF-HEALING ARCHITECTURE
         ───────────────────────────────────────────── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                Self-Healing Data Persistence & Restart Survivability
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Guaranteed panel operation: each panel saves its data to disk and automatically recovers if the file is deleted.
              </p>
            </div>
          </div>

          <button
            onClick={handleRestart}
            disabled={isRestarting}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${isRestarting ? 'animate-spin' : ''}`} />
            {isRestarting ? 'Checking Persistence...' : 'Test Bot Restart & Re-register Views'}
          </button>
        </div>

        {restartResult && (
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{restartResult}</span>
          </div>
        )}

        {healingFeedback && (
          <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-xl text-cyan-300 text-xs flex items-center gap-2">
            <Shield className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{healingFeedback}</span>
          </div>
        )}

        {/* Panel Files Resilience Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-semibold">
              <tr>
                <th className="py-2.5 px-3">System / Panel</th>
                <th className="py-2.5 px-3">Disk Storage File</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Entries</th>
                <th className="py-2.5 px-3 text-right">Self-Healing Test</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-slate-950/40">
              {panelsHealth.map((item) => (
                <tr key={item.key} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-3 font-semibold text-slate-200">
                    {item.name}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-cyan-300 text-[11px]">
                    ./data/{item.fileName}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 border border-emerald-500/20 text-emerald-300">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      {item.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 font-mono">
                    {item.itemsCount} records ({item.sizeBytes} B)
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={() => handleSimulateDeleteAndHeal(item.key)}
                      disabled={isHealing === item.key}
                      title="Simulates file deletion and verifies that the system instantly auto-heals without crashing"
                      className="px-2.5 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded text-[11px] font-semibold transition-all inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                    >
                      <Trash2 className={`w-3 h-3 ${isHealing === item.key ? 'animate-pulse' : ''}`} />
                      {isHealing === item.key ? 'Healing...' : 'Simulate Deletion & Recovery'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ─────────────────────────────────────────────
          3. RAW JSON DISK INSPECTION
         ───────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Ticket Panels Log */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            Registered Ticket Panels Log
          </h3>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block mb-1">Registered Panels</span>
              <strong className="text-lg text-cyan-400 font-mono">
                {Object.keys(state.ticket_db || {}).length || state.panels_log?.length || 0}
              </strong>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block mb-1">Active Open Tickets</span>
              <strong className="text-lg text-emerald-400 font-mono">
                {Object.keys(state.open_tickets || {}).length}
              </strong>
            </div>
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-2">Persistent View Log:</span>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 max-h-56 overflow-y-auto space-y-2 text-xs">
              {state.panels_log?.length === 0 ? (
                <p className="text-slate-500 text-center py-4">No panels registered in file log yet.</p>
              ) : (
                state.panels_log?.map((panel, i) => (
                  <div key={i} className="p-2.5 bg-slate-900/60 rounded-lg border border-slate-800/60 space-y-0.5">
                    <div className="flex items-center justify-between font-semibold text-slate-200">
                      <span>{panel.title}</span>
                      <span className="text-[10px] text-slate-500">Guild ID: {panel.guild_id}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 flex justify-between">
                      <span>Message ID: <code className="text-cyan-300">{panel.message_id}</code></span>
                      <span className="text-slate-500 text-[10px]">
                        {new Date(panel.created_at).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Live Raw JSON Viewer */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <FileCode className="w-4 h-4 text-emerald-400" />
              Raw Disk File (<code className="text-emerald-300">./data/tickets_data.json</code>)
            </h3>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 max-h-[380px] overflow-y-auto leading-relaxed whitespace-pre">
            {JSON.stringify(state, null, 2)}
          </div>
        </div>
      </div>

    </div>
  );
};
