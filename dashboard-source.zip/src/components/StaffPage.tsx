import React from 'react';
import { Shield, ShieldAlert, Sparkles, MessageSquare, ArrowRight, CheckCircle } from 'lucide-react';
import { DEFAULT_STAFF_MEMBERS } from '../data/storeData';
import { MinecraftSkinImage } from './MinecraftSkinImage';

interface StaffPageProps {
  onOpenApplications: () => void;
}

export const StaffPage: React.FC<StaffPageProps> = ({ onOpenApplications }) => {
  return (
    <div className="space-y-10">
      {/* Staff Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-slate-900/80 border border-slate-800 p-8 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl">
        <div className="space-y-2 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Shield className="w-3.5 h-3.5" /> Leadership & Moderation
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">WonderMc Staff Team</h2>
          <p className="text-sm text-slate-400 leading-relaxed">
            Meet the dedicated management, dev team, and moderators who keep WonderMc Network safe, lag-free, and fun 24/7.
          </p>
        </div>

        <div className="shrink-0">
          <button
            onClick={onOpenApplications}
            className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-sm flex items-center gap-2 shadow-xl shadow-amber-500/20 active:scale-95 transition-all"
          >
            <span>Apply for Staff Team</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Staff Members Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {DEFAULT_STAFF_MEMBERS.map(member => (
          <div
            key={member.id}
            className="relative group bg-slate-900/60 hover:bg-slate-900 rounded-3xl border border-slate-800 hover:border-slate-700 p-6 flex flex-col items-center text-center transition-all duration-300 hover:-translate-y-1 shadow-xl"
          >
            {/* Skin Display */}
            <div className="relative mb-4">
              <div
                className="w-20 h-20 rounded-2xl p-1.5 flex items-center justify-center shadow-lg border"
                style={{
                  backgroundColor: `${member.rankColor}15`,
                  borderColor: `${member.rankColor}40`
                }}
              >
                <MinecraftSkinImage username={member.skinUsername} size={68} type="bust" />
              </div>
              {member.isOwner && (
                <span className="absolute -bottom-2 -right-1 px-2 py-0.5 rounded-full bg-red-500 text-white text-[10px] font-black uppercase tracking-wider shadow-md shadow-red-500/30">
                  Owner
                </span>
              )}
            </div>

            {/* In-Game Name & Role */}
            <h3 className="text-lg font-bold text-white mb-1 group-hover:text-amber-400 transition-colors">
              {member.name}
            </h3>

            <div
              className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3 inline-block"
              style={{
                backgroundColor: `${member.rankColor}20`,
                color: member.rankColor,
                border: `1px solid ${member.rankColor}40`
              }}
            >
              {member.role}
            </div>

            {/* Bio / Description */}
            <p className="text-xs text-slate-400 leading-relaxed mb-4 flex-1">
              {member.about}
            </p>

            {/* Discord Tag */}
            <div className="w-full pt-3 border-t border-slate-800 flex items-center justify-center gap-1.5 text-xs text-slate-400 font-mono">
              <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
              <span>{member.discordTag}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Recruitment Callout */}
      <div className="p-8 rounded-3xl bg-slate-900/40 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center md:text-left">
          <h3 className="text-lg font-bold text-white">Think you have what it takes to join our team?</h3>
          <p className="text-xs text-slate-400">
            We are actively recruiting passionate BoxPvP and Lifesteal helpers. Applications take under 5 minutes to complete.
          </p>
        </div>
        <button
          onClick={onOpenApplications}
          className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-amber-500/40 text-white text-xs font-bold transition-all shrink-0"
        >
          Open Application Form
        </button>
      </div>
    </div>
  );
};
