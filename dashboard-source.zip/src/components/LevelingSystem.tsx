import React, { useState, useEffect, useRef } from 'react';
import {
  Trophy,
  Mic,
  MessageSquare,
  Sparkles,
  Zap,
  TrendingUp,
  Shield,
  Search,
  CheckCircle2,
  Crown,
  Flame,
  Volume2,
  VolumeX,
  Play,
  Square,
  Award
} from 'lucide-react';
import { LevelUser } from '../types';

export const LevelingSystem: React.FC = () => {
  const [leaderboard, setLeaderboard] = useState<LevelUser[]>([]);
  const [currentUser, setCurrentUser] = useState<LevelUser | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [isInVc, setIsInVc] = useState(false);
  const [vcSeconds, setVcSeconds] = useState(0);
  const vcTimerRef = useRef<any>(null);

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  // VC Active Timer
  useEffect(() => {
    if (isInVc) {
      vcTimerRef.current = setInterval(() => {
        setVcSeconds(prev => {
          const nextSec = prev + 1;
          // Every 10 seconds in simulator gives 1 min VC worth (for demo speed) or exact
          if (nextSec % 10 === 0 && currentUser) {
            recordActivity(currentUser.id, 'vc', 1);
          }
          return nextSec;
        });
      }, 1000);
    } else {
      if (vcTimerRef.current) clearInterval(vcTimerRef.current);
    }
    return () => {
      if (vcTimerRef.current) clearInterval(vcTimerRef.current);
    };
  }, [isInVc, currentUser]);

  const fetchLeaderboard = async () => {
    try {
      const res = await fetch('/api/levels/leaderboard');
      const data = await res.json();
      if (data.success && data.leaderboard) {
        setLeaderboard(data.leaderboard);
        if (!currentUser && data.leaderboard.length > 0) {
          setCurrentUser(data.leaderboard[0]);
        }
      }
    } catch (_) {}
  };

  const recordActivity = async (userId: string, type: 'message' | 'vc', amount: number) => {
    try {
      const res = await fetch('/api/levels/add-activity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          username: currentUser?.username,
          type,
          amount,
          avatar: currentUser?.avatar
        })
      });
      const data = await res.json();
      if (data.success && data.user) {
        setCurrentUser(data.user);
        fetchLeaderboard();
      }
    } catch (_) {}
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !currentUser) return;
    recordActivity(currentUser.id, 'message', 1);
    setChatInput('');
  };

  const toggleVc = () => {
    if (!isInVc) {
      setIsInVc(true);
      setVcSeconds(0);
    } else {
      setIsInVc(false);
    }
  };

  // XP calculations
  const getNextLevelXp = (lvl: number) => {
    return Math.pow((lvl + 1) / 0.1, 2);
  };
  const getCurrentLevelBaseXp = (lvl: number) => {
    return Math.pow(lvl / 0.1, 2);
  };

  const activeUser = currentUser || leaderboard[0] || {
    id: "987654321012",
    username: "Avihaan_PvP",
    discriminator: "0001",
    avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80",
    xp: 8450,
    level: 29,
    messages: 412,
    vc_minutes: 185,
    role: "Netherite Legend",
    badge: "👑 Owner",
    last_active: new Date().toISOString()
  };

  const currentLevelBase = getCurrentLevelBaseXp(activeUser.level);
  const nextLevelBase = getNextLevelXp(activeUser.level);
  const currentProgress = Math.max(0, activeUser.xp - currentLevelBase);
  const neededProgress = Math.max(1, nextLevelBase - currentLevelBase);
  const progressPercent = Math.min(100, Math.round((currentProgress / neededProgress) * 100));

  const filteredLeaderboard = leaderboard.filter(u =>
    u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shadow-lg shadow-indigo-500/10 text-2xl">
              ⭐
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                WonderMc Activity Leveling System
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  PERSISTENT XP & VC TRACKING
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Gain <strong>+15 XP</strong> per Discord message and <strong>+20 XP</strong> per minute in Voice Channels (VC). Never lose your level progress!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-300">
              💬 1 Msg = <strong>15 XP</strong>
            </span>
            <span className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-300">
              🎙️ 1 Min VC = <strong>20 XP</strong>
            </span>
          </div>
        </div>
      </div>

      {/* DISCORD RANK CARD (WonderMc style) */}
      <div className="bg-[#1e1f22] border border-[#2b2d31] rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden text-white font-sans">
        
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Avatar & Identifiers */}
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                src={activeUser.avatar}
                alt={activeUser.username}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover border-4 border-[#5865f2] shadow-xl"
              />
              <div className="absolute bottom-1 right-1 w-6 h-6 rounded-full bg-[#23a55a] border-2 border-[#1e1f22] flex items-center justify-center">
                <span className="text-[10px]">✓</span>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl sm:text-2xl font-black text-white">{activeUser.username}</h3>
                <span className="text-xs text-[#949ba4]">#{activeUser.discriminator}</span>
                <span className="px-2 py-0.5 bg-[#5865f2]/20 text-[#5865f2] text-[10px] font-bold rounded">
                  {activeUser.badge}
                </span>
              </div>

              <div className="text-xs text-[#949ba4] mt-1 flex items-center gap-2">
                <span>Role: <strong className="text-emerald-400">{activeUser.role}</strong></span>
                <span>•</span>
                <span>Messages: <strong className="text-white">{activeUser.messages}</strong></span>
                <span>•</span>
                <span>VC: <strong className="text-cyan-400">{activeUser.vc_minutes} mins</strong></span>
              </div>
            </div>
          </div>

          {/* Level & Rank Numbers */}
          <div className="flex items-center gap-8 text-right">
            <div>
              <span className="text-[11px] text-[#949ba4] uppercase tracking-wider block font-bold">RANK</span>
              <span className="text-2xl sm:text-3xl font-black text-[#5865f2]">
                #{leaderboard.findIndex(u => u.id === activeUser.id) + 1 || 1}
              </span>
            </div>
            <div>
              <span className="text-[11px] text-[#949ba4] uppercase tracking-wider block font-bold">LEVEL</span>
              <span className="text-3xl sm:text-4xl font-black text-emerald-400">{activeUser.level}</span>
            </div>
          </div>

        </div>

        {/* XP Progress Bar */}
        <div className="mt-6 space-y-2">
          <div className="flex justify-between text-xs text-[#949ba4] font-medium">
            <span>Progress to Level {activeUser.level + 1}</span>
            <span>
              <strong className="text-white">{activeUser.xp.toLocaleString()} XP</strong> / {Math.round(nextLevelBase).toLocaleString()} XP ({progressPercent}%)
            </span>
          </div>

          <div className="w-full h-4 bg-[#2b2d31] rounded-full overflow-hidden p-0.5">
            <div
              className="h-full bg-gradient-to-r from-[#5865f2] via-indigo-500 to-emerald-400 rounded-full transition-all duration-500 shadow-md"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

      </div>

      {/* INTERACTIVE ACTIVITY SIMULATOR (Test VC & Chat Leveling) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* 1. Voice Channel (VC) Simulator */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <Mic className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Voice Channel (VC) Tracker</h4>
                <p className="text-[11px] text-slate-400">Earns +20 XP per minute in Voice</p>
              </div>
            </div>

            <button
              onClick={toggleVc}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                isInVc
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse'
                  : 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20'
              }`}
            >
              {isInVc ? (
                <>
                  <Square className="w-3.5 h-3.5" />
                  <span>Leave Voice Channel</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" />
                  <span>Join Voice Channel</span>
                </>
              )}
            </button>
          </div>

          <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${isInVc ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'}`} />
              <span className="text-slate-300">
                {isInVc ? `Connected to "🔊 General Voice" (${vcSeconds}s)` : 'Not in any voice channel'}
              </span>
            </div>
            {isInVc && (
              <span className="text-emerald-400 font-mono font-bold">+20 XP ticking...</span>
            )}
          </div>
        </div>

        {/* 2. Chat Message Simulator */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Chat Message XP Simulator</h4>
              <p className="text-[11px] text-slate-400">Type a message to simulate Discord chat (+15 XP)</p>
            </div>
          </div>

          <form onSubmit={handleSendMessage} className="flex gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Type a message (e.g. GG play.wondermc.fun!)"
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition cursor-pointer"
            >
              Send (+15 XP)
            </button>
          </form>
        </div>

      </div>

      {/* COMMUNITY LEADERBOARD TABLE */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              WonderMc Activity Leaderboard
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Rankings updated in real-time from Discord text and voice channels.
            </p>
          </div>

          {/* Search */}
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search player or role..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider">
                <th className="pb-3 px-3">Rank</th>
                <th className="pb-3 px-3">Player</th>
                <th className="pb-3 px-3">Level & Role</th>
                <th className="pb-3 px-3">XP</th>
                <th className="pb-3 px-3">Messages</th>
                <th className="pb-3 px-3">VC Time</th>
                <th className="pb-3 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLeaderboard.map((user, idx) => {
                const isSelected = activeUser.id === user.id;
                return (
                  <tr
                    key={user.id}
                    className={`hover:bg-slate-800/40 transition ${isSelected ? 'bg-indigo-950/20' : ''}`}
                  >
                    <td className="py-3.5 px-3 font-mono font-bold">
                      {idx === 0 ? '🥇 #1' : idx === 1 ? '🥈 #2' : idx === 2 ? '🥉 #3' : `#${idx + 1}`}
                    </td>
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={user.avatar}
                          alt={user.username}
                          className="w-8 h-8 rounded-full object-cover border border-slate-700"
                        />
                        <div>
                          <div className="font-bold text-white flex items-center gap-1.5">
                            {user.username}
                            <span className="text-[10px] text-slate-500">#{user.discriminator}</span>
                          </div>
                          <span className="text-[10px] text-slate-400">{user.badge}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded font-mono font-bold">
                          Lvl {user.level}
                        </span>
                        <span className="text-slate-300 font-semibold">{user.role}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-3 font-mono text-cyan-400 font-bold">
                      {user.xp.toLocaleString()} XP
                    </td>
                    <td className="py-3.5 px-3 text-slate-300">
                      {user.messages} msgs
                    </td>
                    <td className="py-3.5 px-3 text-indigo-300">
                      {user.vc_minutes} mins
                    </td>
                    <td className="py-3.5 px-3 text-right">
                      <button
                        onClick={() => setCurrentUser(user)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[11px] font-semibold transition cursor-pointer"
                      >
                        View Card
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
};
