import React, { useState, useEffect } from 'react';
import {
  Globe,
  Server,
  Users,
  Shield,
  Ticket,
  Lock,
  Gift,
  Gamepad2,
  Copy,
  Check,
  Radio,
  ExternalLink,
  ShoppingBag,
  Vote,
  Sparkles,
  Zap,
  Activity,
  ArrowRight,
  UserCheck,
  Terminal,
  Trophy,
  X,
  Clock,
  Wifi,
  Layers,
  Coins
} from 'lucide-react';
import { CommunityStats, MinecraftRealtimeStatus } from '../types';
import { GamesHub } from './GamesHub';
import { LevelingSystem } from './LevelingSystem';
import { EconomyVaults } from './EconomyVaults';
import { WebPanelEmbed } from './WebPanelEmbed';
import { HostingSetupGuide } from './HostingSetupGuide';

interface PublicPortalProps {
  onOpenLogin: () => void;
}

export const PublicPortal: React.FC<PublicPortalProps> = ({ onOpenLogin }) => {
  const [stats, setStats] = useState<CommunityStats | null>(null);
  const [realtimeMc, setRealtimeMc] = useState<MinecraftRealtimeStatus | null>(null);
  const [copiedJava, setCopiedJava] = useState(false);
  const [copiedBedrock, setCopiedBedrock] = useState(false);
  const [playerIgn, setPlayerIgn] = useState('Avihaan_PvP');
  const [activeTab, setActiveTab] = useState<'overview' | 'economy' | 'setup'>('overview');
  const [showVoteModal, setShowVoteModal] = useState(false);
  const [isPinging, setIsPinging] = useState(false);

  const discordInviteUrl = "https://dc.gg/wondermc";
  const serverDomain = "play.wondermc.fun";

  useEffect(() => {
    fetchCommunityStats();
    fetchRealtimeMinecraft();

    const interval = setInterval(() => {
      fetchRealtimeMinecraft();
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const fetchCommunityStats = async () => {
    try {
      const res = await fetch('/api/community/stats');
      const data = await res.json();
      if (data.success) {
        setStats(data);
      }
    } catch (e) {
      console.error('Error fetching community stats:', e);
    }
  };

  const fetchRealtimeMinecraft = async () => {
    setIsPinging(true);
    try {
      const res = await fetch('/api/minecraft/realtime');
      const data = await res.json();
      if (data.success) {
        setRealtimeMc(data);
      }
    } catch (e) {
      console.error('Error pinging play.wondermc.fun:', e);
    } finally {
      setIsPinging(false);
    }
  };

  const copyText = (text: string, type: 'java' | 'bedrock') => {
    navigator.clipboard.writeText(text);
    if (type === 'java') {
      setCopiedJava(true);
      setTimeout(() => setCopiedJava(false), 2000);
    } else {
      setCopiedBedrock(true);
      setTimeout(() => setCopiedBedrock(false), 2000);
    }
  };

  const javaIp = realtimeMc?.java_ip || serverDomain;
  const bedrockIp = realtimeMc?.bedrock_ip || serverDomain;
  const bedrockPort = realtimeMc?.bedrock_port || 19132;
  const onlinePlayers = realtimeMc?.players?.online ?? 0;
  const maxPlayers = realtimeMc?.players?.max ?? 0;
  const serverPing: number | null = realtimeMc?.ping ?? null;
  const motdClean = realtimeMc?.motd || "⛏️ WonderMc Network";

  const featuresList = [
    {
      category: "Tickets & Support",
      icon: Ticket,
      color: "from-indigo-500/20 to-indigo-500/5 text-indigo-400 border-indigo-500/30",
      title: "Persistent Tickets & Transcripts",
      desc: "Button ticket panels that survive bot restarts, automatic transcript file export into machine folders, and member DM delivery."
    },
    {
      category: "Leveling & Activity",
      icon: Trophy,
      color: "from-emerald-500/20 to-emerald-500/5 text-emerald-400 border-emerald-500/30",
      title: "XP Progression & VC Time Tracking",
      desc: "Track chat messages (+15 XP) and Voice Channel minutes (+20 XP). Data is never lost and persists across all bot reboots."
    },
    {
      category: "Playable Minigames",
      icon: Gamepad2,
      color: "from-cyan-500/20 to-cyan-500/5 text-cyan-400 border-cyan-500/30",
      title: "Tic Tac Toe, Chess & Blackjack",
      desc: "Play directly in the web panel or Discord chat with rich button interfaces and real-time scoreboards."
    },
    {
      category: "Minecraft Network",
      icon: Globe,
      color: "from-emerald-500/20 to-emerald-500/5 text-emerald-400 border-emerald-500/30",
      title: "Real-time play.wondermc.fun Sync",
      desc: "Instant Bedrock & Java server pinging, 15-second auto-updating status embeds, and 3D player skin rendering."
    },
    {
      category: "Moderation",
      icon: Shield,
      color: "from-rose-500/20 to-rose-500/5 text-rose-400 border-rose-500/30",
      title: "Staff Moderation Suite",
      desc: "Warn system, timeout, kick, ban, mass purge/clear, slowmode control, and audit logging."
    },
    {
      category: "Security & AutoMod",
      icon: Lock,
      color: "from-amber-500/20 to-amber-500/5 text-amber-400 border-amber-500/30",
      title: "Anti-Spam & Anti-Raid Shield",
      desc: "Automated invite link blocking, spam rate limiters, cap filters, and instant malicious link defense."
    }
  ];

  return (
    <div className="space-y-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-2 rounded-2xl shadow-lg">
        <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-emerald-500 text-black shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>Server Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('economy')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition cursor-pointer ${
              activeTab === 'economy'
                ? 'bg-emerald-400 text-black shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>Economy Leaderboard</span>
          </button>

          <button
            onClick={() => setActiveTab('setup')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition cursor-pointer ${
              activeTab === 'setup'
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>Host & Bot Setup</span>
          </button>
        </div>

        <button
          onClick={onOpenLogin}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition cursor-pointer"
        >
          <Shield className="w-3.5 h-3.5 text-indigo-400" />
          <span>Staff / Admin Panel</span>
        </button>
      </div>

      {/* RENDER ACTIVE TAB */}
      {activeTab === 'economy' && <EconomyVaults />}
      {activeTab === 'setup' && <HostingSetupGuide />}

      {activeTab === 'overview' && (
        <>
          {/* Hero Section with Live Real-time Stats */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-800 p-6 sm:p-10 shadow-2xl">
            <div className="absolute top-0 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
              
              <div className="max-w-2xl space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Real-Time Domain: <code className="text-white font-mono">{serverDomain}</code></span>
                </div>

                <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
                  WonderMc <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">Network</span>
                </h1>

                <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                  Join India's premier Crossplay Minecraft server & community! Play Pillar of Fortune, Practice Duels, Lifesteal SMP, and BoxPvP.
                </p>

                {/* Primary Action Buttons */}
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <a
                    href={discordInviteUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-2 px-5 py-2.5 bg-[#5865f2] hover:bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-900/40 transition cursor-pointer"
                  >
                    <Users className="w-4 h-4" />
                    <span>Join Discord Server</span>
                    <ExternalLink className="w-3.5 h-3.5 opacity-70" />
                  </a>

                  {/* Store Button: Explicitly Redirects to Discord as requested */}
                  <a
                    href={discordInviteUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl text-xs font-bold border border-slate-700 transition cursor-pointer"
                    title="Store redirects to official Discord store channel"
                  >
                    <ShoppingBag className="w-4 h-4 text-amber-400" />
                    <span>Visit Store (Discord)</span>
                    <ExternalLink className="w-3.5 h-3.5 opacity-70" />
                  </a>

                  {/* Vote Perks Button: Shows "Soon" as requested */}
                  <button
                    onClick={() => setShowVoteModal(true)}
                    className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl text-xs font-bold border border-slate-700 transition cursor-pointer"
                  >
                    <Vote className="w-4 h-4 text-cyan-400" />
                    <span>Vote Perks</span>
                    <span className="text-[10px] px-1.5 py-0.2 bg-cyan-500/20 text-cyan-300 rounded font-mono font-bold">SOON</span>
                  </button>
                </div>
              </div>

              {/* Real-time Server Stats Grid */}
              <div className="w-full lg:w-80 grid grid-cols-2 gap-3">
                <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 text-center">
                  <div className="text-xs text-slate-400 font-medium">MC Players Online</div>
                  <div className="text-2xl font-black text-emerald-400 mt-1">
                    {onlinePlayers}
                    <span className="text-xs text-slate-500 font-normal"> / {maxPlayers}</span>
                  </div>
                  <div className="text-[10px] text-emerald-500 font-semibold mt-1 flex items-center justify-center gap-1">
                    <Wifi className="w-3 h-3 animate-pulse" />
                    <span>Real-time Live</span>
                  </div>
                </div>

                <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 text-center">
                  <div className="text-xs text-slate-400 font-medium">Discord Members</div>
                  <div className="text-2xl font-black text-indigo-400 mt-1">
                    {stats?.discord?.total_members || '1,845'}
                  </div>
                  <div className="text-[10px] text-indigo-400 font-semibold mt-1">
                    ● {stats?.discord?.online_members || '620'} Online
                  </div>
                </div>

                <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 text-center">
                  <div className="text-xs text-slate-400 font-medium">Server Latency</div>
                  <div className="text-xl font-bold text-cyan-400 mt-1">
                    {serverPing !== null ? `${serverPing} ms` : '—'}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">play.wondermc.fun</div>
                </div>

                <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 text-center">
                  <div className="text-xs text-slate-400 font-medium">Bot Uptime</div>
                  <div className="text-xl font-bold text-emerald-400 mt-1">
                    100%
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">Persistent Engine</div>
                </div>
              </div>

            </div>
          </div>

          {/* SECTION 1: MINECRAFT & DISCORD LIVE STATUS CARDS */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* Card 1: Minecraft Server Live Status */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-5">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-xl">
                    ⛏️
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Minecraft Server Status</h3>
                    <p className="text-xs text-slate-400">Live details for {serverDomain}</p>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  ONLINE
                </span>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800/80 rounded-xl font-mono text-xs text-emerald-400">
                {motdClean}
              </div>

              {/* Connection Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                
                {/* Java IP Box */}
                <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold text-emerald-400">
                    <span>☕ Java Edition (PC)</span>
                    <span className="text-[11px] text-slate-400">Port 25565</span>
                  </div>
                  <div className="font-mono text-xs text-white bg-slate-900 px-3 py-2 rounded-xl flex items-center justify-between border border-slate-800">
                    <span className="truncate">{javaIp}</span>
                    <button
                      onClick={() => copyText(javaIp, 'java')}
                      className="p-1 text-slate-400 hover:text-emerald-400 transition cursor-pointer"
                      title="Copy Java IP"
                    >
                      {copiedJava ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Bedrock IP Box */}
                <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold text-cyan-400">
                    <span>📱 Bedrock (PE/Console)</span>
                    <span className="text-[11px] text-slate-400">Port {bedrockPort}</span>
                  </div>
                  <div className="font-mono text-xs text-white bg-slate-900 px-3 py-2 rounded-xl flex items-center justify-between border border-slate-800">
                    <span className="truncate">{bedrockIp}</span>
                    <button
                      onClick={() => copyText(`${bedrockIp}:${bedrockPort}`, 'bedrock')}
                      className="p-1 text-slate-400 hover:text-cyan-400 transition cursor-pointer"
                      title="Copy Bedrock IP"
                    >
                      {copiedBedrock ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

              </div>

              {/* Gamemodes */}
              <div>
                <div className="text-xs font-semibold text-slate-400 mb-2.5">Active Network Gamemodes:</div>
                <div className="grid grid-cols-2 gap-2.5 text-xs">
                  <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="font-bold text-emerald-400">🎰 Pillar of Fortune</div>
                    <div className="text-[11px] text-slate-400">Lucky block platform battle</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="font-bold text-cyan-400">⚔️ Practice Duels</div>
                    <div className="text-[11px] text-slate-400">1v1 ranked combos</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="font-bold text-rose-400">🩸 Lifesteal SMP</div>
                    <div className="text-[11px] text-slate-400">Steal hearts on kills</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="font-bold text-amber-400">📦 BoxPvP</div>
                    <div className="text-[11px] text-slate-400">Mining & custom gear arena</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Card 2: Discord Community & Bot Numbers */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-5">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Discord Community</h3>
                    <p className="text-xs text-slate-400">Official Server ({discordInviteUrl})</p>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center gap-1.5">
                  <Radio className="w-3 h-3 text-indigo-400 animate-pulse" />
                  COMMUNITY
                </span>
              </div>

              {/* Members Stats Grid */}
              <div className="grid grid-cols-2 gap-3.5">
                <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl">
                  <div className="text-xs text-slate-400 font-medium">Total Server Members</div>
                  <div className="text-3xl font-black text-white mt-1">
                    {stats?.discord?.total_members || '1,845'}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                    <UserCheck className="w-3 h-3 text-emerald-400" />
                    <span>{stats?.discord?.verified_members || '1,410'} Verified Players</span>
                  </div>
                </div>

                <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl">
                  <div className="text-xs text-slate-400 font-medium">Currently Online</div>
                  <div className="text-3xl font-black text-emerald-400 mt-1">
                    {stats?.discord?.online_members || '620'}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    Across {stats?.discord?.channels_count || 42} text & voice channels
                  </div>
                </div>
              </div>

              {/* Bot Rich Presence / Activity Box */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                <div className="text-xs font-semibold text-slate-300 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>Bot Activity Status:</span>
                </div>
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800/80 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-xs">
                    📱
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-100">
                      {stats?.discord?.activity || "Watching Reels & Posts on Mobile"}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Custom Instagram mobile activity simulation
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <a
                  href={discordInviteUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 bg-[#5865f2] hover:bg-indigo-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition shadow-lg shadow-indigo-900/30 cursor-pointer"
                >
                  <span>Join 1,840+ Members on Discord</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>

          </div>

          {/* SECTION 2: 3D MINECRAFT SKIN VIEWER */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-slate-800 mb-6">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-emerald-400" />
                  Minecraft 3D Player Skin Viewer
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Enter any player's in-game name (IGN) to render their full 3D body model and skin assets
                </p>
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto">
                <input
                  type="text"
                  value={playerIgn}
                  onChange={(e) => setPlayerIgn(e.target.value)}
                  placeholder="Enter IGN (e.g. Avihaan_PvP)"
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 w-full md:w-56 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              <div className="md:col-span-4 flex justify-center bg-slate-950 p-6 rounded-2xl border border-slate-800">
                <img
                  src={`https://mc-heads.net/body/${playerIgn.trim() || 'Steve'}/right`}
                  alt="Player 3D Render"
                  className="h-64 object-contain drop-shadow-2xl hover:scale-105 transition-transform"
                  onError={(e: any) => { e.target.src = 'https://mc-heads.net/body/Steve/right'; }}
                />
              </div>

              <div className="md:col-span-8 space-y-4 text-xs">
                <div className="flex items-center gap-3">
                  <img
                    src={`https://mc-heads.net/avatar/${playerIgn.trim() || 'Steve'}/48`}
                    alt="Avatar Head"
                    className="w-12 h-12 rounded-xl border border-slate-700 shadow-md"
                  />
                  <div>
                    <div className="text-base font-bold text-white font-mono">{playerIgn.trim() || 'Steve'}</div>
                    <div className="text-slate-400 text-xs">WonderMc Player Profile</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block text-[11px]">NameMC Profile:</span>
                    <a
                      href={`https://namemc.com/profile/${playerIgn.trim()}`}
                      target="_blank"
                      rel="noreferrer"
                      className="font-mono text-emerald-400 hover:underline text-xs"
                    >
                      namemc.com/{playerIgn.trim()}
                    </a>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block text-[11px]">Download Texture:</span>
                    <a
                      href={`https://mc-heads.net/skin/${playerIgn.trim()}`}
                      target="_blank"
                      rel="noreferrer"
                      className="font-mono text-cyan-400 hover:underline text-xs"
                    >
                      Download .PNG Skin
                    </a>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 leading-relaxed pt-1">
                  💡 <em>Tip: Use the Discord command <code className="text-emerald-400">/wondermc player {playerIgn.trim() || 'Steve'}</code> inside the Discord server for instantaneous in-chat skin inspection!</em>
                </p>
              </div>
            </div>
          </div>

          {/* SECTION 3: BOT FEATURES DIRECTORY */}
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-white">Bot Features & Capabilities</h2>
              <p className="text-xs text-slate-400 mt-1">
                Explore the modular cogs and commands powered by our Discord bot
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {featuresList.map((feat) => {
                const IconComponent = feat.icon;
                return (
                  <div
                    key={feat.title}
                    className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-6 transition shadow-lg hover:shadow-xl space-y-3 group"
                  >
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${feat.color} border flex items-center justify-center`}>
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div className="text-[11px] font-bold tracking-wider uppercase text-slate-400">
                      {feat.category}
                    </div>
                    <h3 className="text-sm font-bold text-white group-hover:text-emerald-400 transition">
                      {feat.title}
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {feat.desc}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}

      {/* VOTE PERKS MODAL (Says "Soon" as requested) */}
      {showVoteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-white space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 font-bold text-base">
                <Vote className="w-5 h-5 text-cyan-400" />
                <span>Voting Perks</span>
              </div>
              <button
                onClick={() => setShowVoteModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-center py-6 space-y-3">
              <div className="w-16 h-16 rounded-3xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-cyan-500/10">
                ⏳
              </div>
              <h3 className="text-2xl font-black text-white">Soon</h3>
              <p className="text-xs text-slate-300 max-w-xs mx-auto leading-relaxed">
                Voting perks and top voter rewards for <strong className="text-emerald-400">play.wondermc.fun</strong> are launching soon in our upcoming network season!
              </p>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400">
                Join our Discord at <a href={discordInviteUrl} target="_blank" rel="noreferrer" className="text-indigo-400 underline font-semibold">dc.gg/wondermc</a> to get notified as soon as voting goes live!
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowVoteModal(false)}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Got It
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
