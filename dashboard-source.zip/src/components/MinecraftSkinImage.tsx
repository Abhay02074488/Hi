import React, { useState } from 'react';

interface MinecraftSkinImageProps {
  username: string;
  size?: number;
  type?: 'bust' | 'avatar' | 'body' | 'head';
  className?: string;
}

export const MinecraftSkinImage: React.FC<MinecraftSkinImageProps> = ({
  username,
  size = 64,
  type = 'bust',
  className = ''
}) => {
  const [errorIndex, setErrorIndex] = useState(0);

  const cleanName = username.trim() || 'Steve';

  // Fallback sources list
  const sources = [
    type === 'bust'
      ? `https://minotar.net/armor/bust/${cleanName}/${size}`
      : type === 'body'
      ? `https://minotar.net/armor/body/${cleanName}/${size}`
      : `https://minotar.net/avatar/${cleanName}/${size}`,
    `https://mc-heads.net/avatar/${cleanName}/${size}`,
    `https://crafatar.com/avatars/${cleanName}?size=${size}&overlay`,
    '/public/wondermc_logo.png'
  ];

  const currentSrc = sources[Math.min(errorIndex, sources.length - 1)];

  return (
    <img
      src={currentSrc}
      alt={`${cleanName}'s Minecraft Skin`}
      width={size}
      height={size}
      className={`rounded-lg object-contain ${className}`}
      onError={() => {
        if (errorIndex < sources.length - 1) {
          setErrorIndex(prev => prev + 1);
        }
      }}
      loading="lazy"
    />
  );
};
