import sys
if sys.version_info < (3, 8):
    sys.stderr.write(
        "\n" + "=" * 60 + "\n"
        "[FATAL ERROR] INCOMPATIBLE PYTHON VERSION DETECTED: Python " + sys.version.split()[0] + "\n"
        "discord.py v2.x requires Python 3.8+ (Recommended: Python 3.10 or 3.11).\n"
        "TO FIX IN YOUR HOSTING PANEL:\n"
        "  1. Go to 'Startup' tab in the left sidebar\n"
        "  2. Find 'Docker Image' / 'Container Image'\n"
        "  3. Change it from Python 2.7 to Python 3.10 or Python 3.11\n"
        "  4. Restart the server in the Console tab!\n"
        + "=" * 60 + "\n\n"
    )
    sys.exit(1)

import discord
from discord import app_commands
from discord.ext import commands, tasks
from discord.gateway import DiscordWebSocket
import os
import asyncio
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

raw_token = os.getenv("DISCORD_TOKEN") or os.getenv("DISCORD_BOT_TOKEN") or "PUT_YOUR_NEW_TOKEN_HERE"
TOKEN = raw_token.strip("\"' \t\n\r")
DEFAULT_PREFIXES = ["wm ", "wm", "WM ", "WM", "!", "r!", "R!", "$", ".", "?"]
APPLICATION_ID = int(os.getenv("APPLICATION_ID", os.getenv("DISCORD_CLIENT_ID", "0")))

intents = discord.Intents.all()

def get_prefix(bot_instance, message):
    """Dynamic prefix resolver that supports custom server prefixes as well as standard prefixes (km, !, r!, $, .)."""
    prefixes = list(DEFAULT_PREFIXES)
    if message.guild:
        try:
            from cogs.config import CONFIG_DB
            custom = CONFIG_DB.get(str(message.guild.id), {}).get("prefix")
            if custom and custom not in prefixes:
                prefixes.insert(0, custom)
                if not custom.endswith(" "):
                    prefixes.insert(1, f"{custom} ")
        except Exception:
            pass
    try:                       # people with "no prefix" can type commands directly (see cogs/noprefix.py)
        from cogs.noprefix import allows
        if allows(message):
            prefixes.append("")
    except Exception:
        pass
    return commands.when_mentioned_or(*prefixes)(bot_instance, message)

bot = commands.Bot(command_prefix=get_prefix, intents=intents, help_command=None)


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    """Global slash-command error handler: always answer the user instead of 'application did not respond'."""
    original = getattr(error, "original", error)
    if isinstance(error, app_commands.MissingPermissions):
        msg = "❌ You are missing permission: " + ", ".join(f"`{p}`" for p in error.missing_permissions)
    elif isinstance(error, app_commands.BotMissingPermissions):
        msg = "❌ I'm missing permission: " + ", ".join(f"`{p}`" for p in error.missing_permissions)
    elif isinstance(error, app_commands.CommandOnCooldown):
        msg = f"⏳ Slow down! Try again in {error.retry_after:.1f}s."
    elif isinstance(error, app_commands.CheckFailure):
        msg = "❌ You can't use this command here."
    elif isinstance(original, (discord.Forbidden, discord.NotFound, discord.HTTPException)):
        from cogs.security import friendly_error
        msg = "❌ " + friendly_error(original)
    else:
        import traceback
        print(f"[SlashError] /{getattr(interaction.command, 'qualified_name', '?')}: {original!r}")
        traceback.print_exception(type(original), original, original.__traceback__)
        msg = "⚠️ Something went wrong running that command. The error was logged."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    except discord.HTTPException:
        pass
bot.start_time = datetime.utcnow()


class MobileWebSocket(DiscordWebSocket):
    async def send_as_json(self, data):
        if data.get("op") == self.IDENTIFY:
            properties = data.get("d", {}).get("properties")
            if properties:
                for key in ("os", "browser", "device"):
                    if key in properties:
                        properties[key] = "Discord Android"
                    dollar_key = f"${key}"
                    if dollar_key in properties:
                        properties[dollar_key] = "Discord Android"
        return await super().send_as_json(data)

DiscordWebSocket.from_client = MobileWebSocket.from_client

COGS = [
    "cogs.core",
    "cogs.moderation",
    "cogs.fun",
    "cogs.utility",
    "cogs.misc",
    "cogs.giveaway",
    "cogs.ticket",
    "cogs.suggestion",
    "cogs.roles",
    "cogs.reaction_roles",
    "cogs.automod",
    "cogs.automod_panel",
    "cogs.highlight",
    "cogs.minigames",
    "cogs.blackjack",
    "cogs.leveling",
    "cogs.economy",
    "cogs.config",
    "cogs.security",
    "cogs.welcome",
    "cogs.autoresponder",
    "cogs.music",
    "cogs.tags",
    "cogs.extras",
    "cogs.boardgames",
    "cogs.social",
    "cogs.noprefix",
    "cogs.ai_assistant",
    "cogs.botadmin",
    "cogs.vouchers",
    "cogs.modplus",
    "cogs.eventlog",
    "cogs.host",
    "cogs.minecraft",
    "cogs.discord_srv",
    "cogs.emoji_manager",
    "cogs.applications",
]

CURRENT_ACTIVITY_NAME = os.getenv("BOT_ACTIVITY_NAME", "Instagram")
CURRENT_ACTIVITY_DETAILS = os.getenv("BOT_ACTIVITY_DETAILS", "Watching Reels & Posts")
CURRENT_ACTIVITY_STATE = os.getenv("BOT_ACTIVITY_STATE", "On Mobile")

def build_activity(name=None, details=None, state=None, activity_type=discord.ActivityType.watching):
    act_name = name or CURRENT_ACTIVITY_NAME
    act_details = details or CURRENT_ACTIVITY_DETAILS
    act_state = state or CURRENT_ACTIVITY_STATE
    
    return discord.Activity(
        type=activity_type,
        name=act_name,
        details=act_details,
        state=act_state,
        timestamps={"start": int(bot.start_time.timestamp())},
    )

# Mobile Presence Loop alternating between Online and Idle
mobile_status_state = {"is_online": True}

@tasks.loop(minutes=2)
async def mobile_presence_loop():
    try:
        mobile_status_state["is_online"] = not mobile_status_state["is_online"]
        status = discord.Status.online if mobile_status_state["is_online"] else discord.Status.idle
        state_text = "On Mobile" if mobile_status_state["is_online"] else "Away (Mobile)"
        await bot.change_presence(
            activity=build_activity(state=state_text),
            status=status
        )
        print(f"📱 Mobile presence updated: status={status.value}")
    except Exception as e:
        print(f"⚠️ Error updating mobile presence: {e}")

@bot.event
async def on_ready():
    app_id = APPLICATION_ID or (bot.user.id if bot.user else 0)
    await bot.change_presence(
        activity=build_activity(state="On Mobile"),
        status=discord.Status.online
    )
    if not mobile_presence_loop.is_running():
        mobile_presence_loop.start()
    print(f"🎮 Sent presence with application_id={app_id}")
    print(f"✅ Logged in as {bot.user} ({bot.user.id if bot.user else 0})")
    print(f"📡 Connected to {len(bot.guilds)} guilds")
    if not getattr(bot, "_slash_synced", False):   # on_ready fires on every reconnect - sync only once
        try:
            synced = await bot.tree.sync()
            bot._slash_synced = True
            print(f"🔄 Synced {len(synced)} slash commands")
        except Exception as e:
            print(f"❌ Sync failed: {e}")

@bot.event
async def on_guild_join(guild):
    for channel in guild.text_channels:
        if channel.permissions_for(guild.me).send_messages:
            embed = discord.Embed(
                title="👋 Thanks for adding WonderMc!",
                description=(
                    "**WonderMc Network** — *The Ultimate Minecraft Discord Bot*\n\n"
                    "I'm a powerful multipurpose Discord bot! Here's how to get started:\n"
                    "• Use `/help` or `/ecohelp` to see all commands\n"
                    "• Default economy & bot prefix: `wm ` (e.g. `wm bal`, `wm store`, `wm daily`)\n"
                    "• Full Economy System: `/balance`, `/daily`, `/work`, `/store`, `/stocks`, `/chicken-fight`, `/leaderboard`\n\n"
                    "**Categories:** Economy · Minecraft · Moderation · Fun · Utility · Giveaway · Ticket · Roles · AutoMod"
                ),
                color=0x5865F2
            )
            embed.set_thumbnail(url=bot.user.display_avatar.url if bot.user else "")
            embed.set_footer(text="WonderMc Network • play.wondermc.fun")
            try:
                await channel.send(embed=embed)
            except discord.HTTPException:
                continue
            break

@bot.event
async def on_command_error(ctx, error):
    # If the cog already handled the error, ignore
    if hasattr(ctx.command, 'on_error'):
        return

    ignored = (commands.CommandNotFound,)
    if isinstance(error, ignored):
        return

    if isinstance(error, commands.CommandOnCooldown):
        seconds = int(error.retry_after)
        minutes, sec = divmod(seconds, 60)
        hours, minutes = divmod(minutes, 60)
        time_str = f"{hours}h {minutes}m {sec}s" if hours > 0 else (f"{minutes}m {sec}s" if minutes > 0 else f"{sec}s")
        embed = discord.Embed(
            title="⏳ Command on Cooldown",
            description=f"You must wait **{time_str}** before using this command again.",
            color=0xF1C40F
        )
        return await ctx.send(embed=embed)

    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(
            title="🚫 Permission Denied",
            description="You do not have the required permissions to execute this command.",
            color=0xE74C3C
        )
        return await ctx.send(embed=embed)

    if isinstance(error, commands.MissingRequiredArgument):
        embed = discord.Embed(
            title="⚠️ Missing Argument",
            description=f"Missing required parameter: `{error.param.name}`\nUse `/help` or `/ecohelp` for command usage examples.",
            color=0xE74C3C
        )
        return await ctx.send(embed=embed)

    if isinstance(error, commands.BadArgument):
        embed = discord.Embed(
            title="⚠️ Invalid Parameter",
            description=f"Invalid argument provided: {error}\nPlease check your inputs and try again.",
            color=0xE74C3C
        )
        return await ctx.send(embed=embed)

    original = getattr(error, "original", error)

    if isinstance(error, commands.NoPrivateMessage):
        return await ctx.send("❌ This command only works inside a server.")

    if isinstance(error, commands.BotMissingPermissions):
        perms = ", ".join(f"`{p}`" for p in error.missing_permissions)
        return await ctx.send(f"❌ I'm missing permission: {perms}. Give it to my role.")

    if isinstance(error, commands.CheckFailure):
        return await ctx.send("❌ You can't use this command here.")

    if isinstance(error, (discord.Forbidden, discord.NotFound, discord.HTTPException)) or \
            isinstance(original, (discord.Forbidden, discord.NotFound, discord.HTTPException)):
        from cogs.security import friendly_error
        try:
            return await ctx.send("❌ " + friendly_error(original))
        except discord.HTTPException:
            return

    # Anything else: tell the user something happened and print the full traceback to the console
    import traceback
    print(f"[CommandError] {ctx.command}: {original!r}")
    traceback.print_exception(type(original), original, original.__traceback__)
    try:
        await ctx.send("⚠️ Something went wrong running that command. The error was logged for the bot owner.")
    except discord.HTTPException:
        pass

async def main():
    # Optional: DISABLED_COGS=music,eventlog,extras in .env switches heavy features off (saves RAM on small hosts)
    disabled = {x.strip().lower().replace("cogs.", "") for x in os.getenv("DISABLED_COGS", "").split(",") if x.strip()}
    async with bot:
        for cog in COGS:
            if cog.split(".")[-1] in disabled:
                print(f"  ⏭️  Skipped {cog} (DISABLED_COGS)")
                continue
            try:
                await bot.load_extension(cog)
                print(f"  ✅ Loaded {cog}")
            except Exception as e:
                import traceback
                print(f"  ❌ Failed to load {cog}: {e}")
                traceback.print_exc()
        try:
            await bot.start(TOKEN)
        except discord.LoginFailure:
            print("\n❌ Discord rejected the bot token. Copy a fresh token from "
                  "https://discord.com/developers/applications -> your bot -> Bot -> Reset Token, and put it in .env")
        except discord.PrivilegedIntentsRequired:
            print("\n❌ Privileged intents are OFF in the Developer Portal.\n"
                  "   Open https://discord.com/developers/applications -> your bot -> Bot -> turn ON:\n"
                  "   PRESENCE INTENT, SERVER MEMBERS INTENT and MESSAGE CONTENT INTENT, save, then restart.")

if __name__ == "__main__":
    if not TOKEN or TOKEN == "PUT_YOUR_NEW_TOKEN_HERE":
        print(
            "\n❌ No Discord bot token found.\n"
            "   Open the .env file in this folder and set:\n"
            "       DISCORD_TOKEN=your_actual_bot_token\n"
            "   OR:\n"
            "       DISCORD_BOT_TOKEN=your_actual_bot_token\n"
        )
    else:
        asyncio.run(main())
