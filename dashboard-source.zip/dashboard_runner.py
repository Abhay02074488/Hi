"""
Runs the WonderMc DASHBOARD (Node) on a PYTHON-only server (Pterodactyl / Skillora ...).
Started automatically by app.py when .env contains   RUN_DASHBOARD=true
What it does (first start takes a few minutes, later starts take seconds):
  1. finds Node.js, or downloads a portable copy into ./.node  (no root needed)
  2. npm install                      (first time only)
  3. builds the website; if the host has too little RAM it uses the pre-built public/website_dist.zip instead
  4. starts the dashboard server and restarts it if it crashes
The bot itself is started by app.py - the dashboard is told NOT to start a second copy.
Required .env:  DASHBOARD_PORT=<another port of your server>   (the main port is used by the bot's Minecraft bridge)
Optional .env:  NODE_VERSION=22.12.0
"""
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import time
import urllib.request
import zipfile

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
NODE_DIR = os.path.join(BASE, ".node")
DRY = "--dry-run" in sys.argv


def log(msg):
    print(f"[dashboard] {msg}", flush=True)


def load_env():
    try:
        from dotenv import load_dotenv
        load_dotenv(os.path.join(BASE, ".env"))
    except Exception:
        pass


def node_bin_dir():
    """Directory that contains node + npm (system Node or the portable one)."""
    if os.path.exists(os.path.join(NODE_DIR, "bin", "node")):
        return os.path.join(NODE_DIR, "bin")
    found = shutil.which("node")
    return os.path.dirname(found) if found else None


def ensure_node():
    d = node_bin_dir()
    if d:
        log(f"Node found: {d}")
        return d
    arch = {"x86_64": "x64", "amd64": "x64", "aarch64": "arm64", "arm64": "arm64"}.get(platform.machine().lower())
    if not arch:
        raise SystemExit(f"[dashboard] unsupported CPU: {platform.machine()}")
    versions = [os.getenv("NODE_VERSION", "22.12.0"), "20.18.1"]
    for v in versions:
        url = f"https://nodejs.org/dist/v{v}/node-v{v}-linux-{arch}.tar.xz"
        log(f"Downloading portable Node {v} ({arch}) ...")
        if DRY:
            log(f"(dry run) would download {url}")
            return None
        try:
            tmp = os.path.join(BASE, "node.tar.xz")
            urllib.request.urlretrieve(url, tmp)
            with tarfile.open(tmp, "r:xz") as tf:
                tf.extractall(BASE)
            os.remove(tmp)
            shutil.rmtree(NODE_DIR, ignore_errors=True)
            os.rename(os.path.join(BASE, f"node-v{v}-linux-{arch}"), NODE_DIR)
            log("Node installed.")
            return os.path.join(NODE_DIR, "bin")
        except Exception as ex:
            log(f"download failed ({ex}); trying next version")
    raise SystemExit("[dashboard] could not get Node.js (does this server allow outbound downloads?)")


def run(cmd, env, desc, check=True):
    log(f"{desc} ...")
    if DRY:
        log(f"(dry run) {' '.join(cmd)}")
        return 0
    rc = subprocess.call(cmd, env=env, cwd=BASE)
    if rc != 0 and check:
        raise RuntimeError(f"{desc} failed (exit {rc})")
    return rc


def use_prebuilt_site():
    z = os.path.join(BASE, "public", "website_dist.zip")
    if not os.path.exists(z):
        return False
    log("Using the pre-built website from public/website_dist.zip")
    shutil.rmtree(os.path.join(BASE, "dist"), ignore_errors=True)
    os.makedirs(os.path.join(BASE, "dist"), exist_ok=True)
    with zipfile.ZipFile(z) as zf:
        zf.extractall(os.path.join(BASE, "dist"))
    return os.path.exists(os.path.join(BASE, "dist", "index.html"))


def prepare(env):
    npm = os.path.join(env["NODE_BIN"], "npm")
    modules = os.path.join(BASE, "node_modules")
    bin_dir = os.path.join(modules, ".bin")

    # Do not use Express as the only dependency check: the previous check
    # skipped installation when Express existed but Vite was missing.
    required_bins = ("vite", "esbuild", "tsx")
    missing_bins = [
        name for name in required_bins
        if not os.path.exists(os.path.join(bin_dir, name))
    ]
    required_packages = ("express", "vite")
    missing_packages = [
        name for name in required_packages
        if not os.path.isdir(os.path.join(modules, name))
    ]

    if missing_bins or missing_packages:
        log(
            "Dashboard dependencies are incomplete "
            f"(missing executables: {', '.join(missing_bins) or 'none'}; "
            f"missing packages: {', '.join(missing_packages) or 'none'})."
        )
        run(
            [npm, "install", "--include=dev", "--no-audit", "--no-fund", "--loglevel=error"],
            env,
            "Installing/fixing dashboard packages",
        )

    vite = os.path.join(bin_dir, "vite")
    if not DRY and not os.path.exists(vite):
        raise RuntimeError(
            "Vite is still missing after npm install. Check that package.json "
            "contains Vite and that the host allows npm package downloads."
        )

    stamp = os.path.join(BASE, "dist", ".built")
    newest_src = max(
        (
            os.path.getmtime(os.path.join(r, f))
            for r, _, fs in os.walk(os.path.join(BASE, "src"))
            for f in fs
        ),
        default=0,
    )
    if not (
        os.path.exists(os.path.join(BASE, "dist", "index.html"))
        and os.path.exists(stamp)
        and os.path.getmtime(stamp) >= newest_src
    ):
        e2 = dict(env, NODE_OPTIONS=env.get("NODE_OPTIONS_BUILD", "--max-old-space-size=900"))
        built = False
        try:
            run(
                [os.path.join(env["NODE_BIN"], "node"), vite, "build"],
                e2,
                "Building the website",
            )
            built = os.path.exists(os.path.join(BASE, "dist", "index.html")) or DRY
        except Exception as ex:
            log(f"build failed: {ex}")
        if not built:
            raise RuntimeError(
                "Website build failed. See the Vite error above. This may be a "
                "dependency, source-code, network, or memory issue; it is not "
                "necessarily an insufficient-RAM problem."
            )
        if not DRY:
            with open(stamp, "w") as stamp_file:
                stamp_file.write(str(time.time()))

    # Bundle the dashboard server; if esbuild is unavailable, use tsx.
    out = os.path.join(BASE, "dist", "server.cjs")
    esb = os.path.join(bin_dir, "esbuild")
    if os.path.exists(esb) or DRY:
        run(
            [esb, "server.ts", "--bundle", "--platform=node", "--format=cjs",
             "--packages=external", f"--outfile={out}"],
            env,
            "Bundling the dashboard server",
            check=False,
        )
    if os.path.exists(out):
        return [os.path.join(env["NODE_BIN"], "node"), out]

    tsx = os.path.join(bin_dir, "tsx")
    if not DRY and not os.path.exists(tsx):
        raise RuntimeError(
            "Neither a bundled dist/server.cjs nor node_modules/.bin/tsx is available."
        )
    return [os.path.join(env["NODE_BIN"], "node"), tsx, "server.ts"]


def main():
    load_env()
    node_dir = ensure_node()
    env = dict(os.environ)
    if node_dir:
        env["PATH"] = node_dir + os.pathsep + env.get("PATH", "")
    env["NODE_BIN"] = node_dir or ""
    # The Python bot's built-in bridge server already uses SERVER_PORT (BRIDGE_PORT overrides it), so the dashboard
    # needs ANOTHER port. Pterodactyl hands you several - put one of the others in .env as DASHBOARD_PORT.
    bridge = os.getenv("BRIDGE_PORT") or os.getenv("SERVER_PORT") or os.getenv("PORT") or ""
    port = os.getenv("DASHBOARD_PORT") or "25645"
    if not port and os.getenv("BRIDGE_PORT") and os.getenv("SERVER_PORT") and os.getenv("BRIDGE_PORT") != os.getenv("SERVER_PORT"):
        port = os.getenv("SERVER_PORT")       # bridge was moved away, so the main port is free for the dashboard
    if not port or port == bridge:
        log("❌ DASHBOARD_PORT is not set (or equals the bot's bridge port).")
        log("   Add this line to .env using ANOTHER port from your server's Network tab, e.g.:  DASHBOARD_PORT=25590")
        log("   The Discord bot keeps running normally.")
        return 1
    env.update(NODE_ENV="production", PORT=str(port), RUN_DISCORD_BOT="false", AUTO_START_BOT="false")
    env["NODE_BIN"] = node_dir or "/usr/bin"
    try:
        cmd = prepare(env)
    except Exception as ex:
        log(f"❌ setup failed: {ex}")
        log("The Discord bot keeps running normally. Fix the problem above and restart the server.")
        return 1
    if DRY:
        log(f"(dry run) would start: {' '.join(cmd)} on port {port}")
        return 0
    delay = 5
    while True:
        log(f"Starting dashboard on port {port} -> open http://<your-server-address>:{port}")
        started = time.time()
        rc = subprocess.call(cmd, env=env, cwd=BASE)
        log(f"dashboard stopped (exit {rc})")
        delay = 5 if time.time() - started > 120 else min(delay * 2, 120)
        log(f"restarting in {delay}s")
        time.sleep(delay)


if __name__ == "__main__":
    sys.exit(main())
